#pragma once
// 节拍器（v39）
//
// 一拍音频由 N32 音效通道合成（type=2 的短促"嗒"声，见 n32_audio.cc），
// 这里只负责时间网格：用绝对时间累加，不用「上一次 + 间隔」的相对写法，
// 否则 UI 循环每轮 20ms 的调度抖动会一路累积，跑几分钟就明显拖慢。
#include "desktop_gfx.h"
#include "desktop_home.h"
#include "settings.h"
#include "st7789.h"
#include <algorithm>
#include <cstdint>
#include <cstdio>

namespace desktop_metro {
inline uint16_t C(int r, int g, int b) { return ((r >> 3) << 11) | ((g >> 2) << 5) | (b >> 3); }

struct Metro {
    static constexpr int kMinBpm = 40;
    static constexpr int kMaxBpm = 240;
    static constexpr int kBpmStep = 5;
    static constexpr int kMinBeats = 2;
    static constexpr int kMaxBeats = 6;

    int bpm = 120;
    int beats = 4;      // 每小节拍数，也就是屏幕上的拍点个数
    int field = 0;      // 0 = 编辑 BPM，1 = 编辑拍号
    bool running = false;
    int beat = 0;       // 当前拍（1..beats），0 = 还没起拍
    int64_t next_us = 0;
    int64_t last_us = 0;

    void Load() {
        Settings s("desk_metro", true);
        bpm = std::clamp(static_cast<int>(s.GetInt("bpm", 120)), kMinBpm, kMaxBpm);
        beats = std::clamp(static_cast<int>(s.GetInt("beats", 4)), kMinBeats, kMaxBeats);
    }
    void Save() {
        Settings s("desk_metro", true);
        s.SetInt("bpm", bpm);
        s.SetInt("beats", beats);
    }
    int IntervalUs() const { return 60000000 / std::max(1, bpm); }

    void Start(int64_t now_us) {
        running = true;
        beat = 0;
        next_us = now_us + 30000;  // 30ms 起拍余量，按键那一下不会被吃掉
        last_us = 0;
    }
    void Stop() {
        running = false;
        beat = 0;
        next_us = 0;
        last_us = 0;
    }
    void Toggle(int64_t now_us) {
        if (running) Stop();
        else Start(now_us);
    }
    void Reset() {
        Stop();
        bpm = 120;
        beats = 4;
        field = 0;
        Save();
    }
    void NextField() { field = (field + 1) % 2; }
    void Step(int delta) {
        if (field == 0) {
            bpm = std::clamp(bpm + delta * kBpmStep, kMinBpm, kMaxBpm);
        } else {
            beats = std::clamp(beats + delta, kMinBeats, kMaxBeats);
            // 运行中缩拍：拍号变小后不能把 beat 留在已经不存在的拍上
            if (beat > beats) beat = 1;
        }
        Save();
    }

    // 返回本轮要响的拍号（1..beats），0 表示这一轮不响。
    // 落后（UI 被占、刚从别的页面切回来）不补打，但 next_us 保持在原来的
    // 时间网格上，所以长时间运行不会越拖越慢。
    int Tick(int64_t now_us) {
        if (!running) return 0;
        if (next_us == 0) next_us = now_us;
        if (now_us < next_us) return 0;
        const int64_t step = IntervalUs();
        next_us += step;
        while (next_us <= now_us) next_us += step;
        beat = (beat % std::max(1, beats)) + 1;
        last_us = now_us;
        return beat;
    }
    // 拍点亮起 140ms，够看清又不至于连成一串（240 BPM 时拍间隔 250ms）
    bool Lit(int64_t now_us) const { return running && last_us > 0 && now_us - last_us < 140000; }
    int LitBeat(int64_t now_us) const { return Lit(now_us) ? beat : 0; }
    int Progress(int64_t now_us) const {
        if (!running || last_us <= 0) return 0;
        const int64_t step = IntervalUs();
        if (step <= 0 || now_us < last_us) return 0;
        return std::clamp(static_cast<int>((now_us - last_us) * 100 / step), 0, 100);
    }

    // 兜底自绘（LVGL 分配失败时的老路径），布局与 desktop_ui.h 的 LVGL 版对齐
    void Draw(radio::Display& lcd, int64_t now_us, bool blink) {
        (void)blink;
        const auto bg = C(14, 20, 32), cyan = C(143, 227, 240), warm = C(255, 210, 122),
                   ink = C(147, 170, 198), dim = C(113, 134, 160), line = C(39, 57, 90);
        char buf[16];
        desktop_home::Text(lcd, 9, 2, "节拍器", cyan, 96);
        std::snprintf(buf, sizeof(buf), "%d/4", beats);
        desktop_home::Text(lcd, 100, 2, buf, field == 1 ? warm : dim, 155);
        lcd.FillRect(7, 20, 146, 1, line);
        std::snprintf(buf, sizeof(buf), "%d", bpm);
        // 暖黄是这一页的主色；编辑拍号时数字退成灰白，注意力让给右上角
        const uint16_t num = (field == 1) ? ink : warm;
        // 0.9 倍字高下每个数字约 22px 宽，按位数水平居中
        const int digits = bpm >= 100 ? 3 : (bpm >= 10 ? 2 : 1);
        gfx::Digits(lcd, (160 - digits * 22) / 2, 22, buf, num, 0.9f, 0, bg);
        desktop_home::Text(lcd, 62, 60, "BPM", dim, 100);
        const int lit = LitBeat(now_us);
        const int dotw = beats * 10 + (beats - 1) * 10;
        int x = (160 - dotw) / 2;
        for (int i = 1; i <= beats; ++i) {
            const bool on = (i == lit);
            gfx::Disc(lcd, static_cast<float>(x + 5), 84.0f, 5.0f,
                      on ? (i == 1 ? warm : cyan) : (i == 1 ? C(74, 63, 46) : line), bg);
            x += 20;
        }
        gfx::RoundRect(lcd, 30, 98, 100, 3, 1.5f, C(27, 39, 64));
        const int p = Progress(now_us);
        if (p > 0) gfx::RoundRect(lcd, 30, 98, std::max(1, p), 3, 1.5f, running ? warm : line);
        desktop_home::Text(lcd, 20, 110, running ? "A停 B切换 C减 D增" : "A开始 B切换 C减 D增", dim, 158);
    }
};
}  // namespace desktop_metro
