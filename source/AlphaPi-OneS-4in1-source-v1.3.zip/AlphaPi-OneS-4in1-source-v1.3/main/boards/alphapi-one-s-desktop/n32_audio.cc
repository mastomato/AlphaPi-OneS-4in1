#include "n32_audio.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstring>
#include <mutex>

#include "esp_log.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "freertos/task.h"
#include "driver/uart.h"

#include "radio_config.h"

namespace radio {
namespace {

constexpr char kTag[] = "N32Audio";
static bool g_recording = false;
static bool g_uart_initialized = false;
static std::atomic<uint8_t> g_keys{0xFF};
static std::atomic<int64_t> g_keys_at{0};
static std::atomic<uint32_t> g_key_polls{0};
static int64_t g_key_attempt_at=0; // Access only while holding UartMutex.
// 写寄存器等待应答超时。v45：400ms -> 200ms。一帧 204B@460800 只要 4.4ms，
// 且 SendCommand 现在会先 uart_wait_tx_done 保证整帧物理发完再读 ACK，
// 应答时序是确定的。旧值 400ms 一旦超时（还带 2 次重试）就会占着 UART
// 互斥锁 0.4~0.8s，把 UI、小智输出、节拍器一起拖住 —— 那是「跑一阵就卡」
// 的放大环节，不是解决办法。
// v48：200ms -> 120ms，直接取 known-good 驱动 audio_uart.cc::kCommandTimeoutMs。
// 应答时序已经由 uart_wait_tx_done 保证是确定的，120ms 足够；
// 真丢一次 ACK 时占锁时间从 200ms 降到 120ms，少一次可闻的断音。
constexpr int kCommandTimeoutMs = 120;

// v48：流间隙阈值，直接取 known-good 驱动 audio_uart.cc::kStreamGapUs（500ms，
// 实机结论）。N32 把超过这个长度的写入间隙判为「上一段播放会话已结束」，
// 之后必须重发 44B WAV 头，否则进来的 PCM 会被静默吞掉。
constexpr int64_t kStreamGapUs = 500 * 1000;

// v41：重开播放会话时，音效前面先垫这么多毫秒静音。
// N32 每开一次会话都会吞掉开头约 100~150ms（实测：95ms 的碰撞音、42ms 的读秒声
// 全被吞掉，172ms 的结束音能听到 → 吞音窗口落在 95~172ms 之间）。垫 240ms
// 留足余量。只在"会话确实要重开"时才垫，常开底流跑着的时候不垫。
constexpr int kStreamLeadInMs = 240;

// v37：音效的时长/包络全部在 PlayBeep() 里按采样数现算，不再需要固定
// 的 160ms + 120ms 常量（旧值只够把一声短促的"嘀"写出去，N32 还没开播
// 流就断了）。

// 与 N32 协处理器通信时统一持有的互斥锁。
// 音频写入、按键查询两方共用，防止抢总线导致音频卡顿。
std::mutex& UartMutex() {
    static std::mutex mutex;
    return mutex;
}

}  // namespace

uint8_t N32Audio::Checksum(const uint8_t* data, size_t length) {
    uint8_t sum = 0;
    for (size_t i = 0; i < length; ++i) {
        sum = static_cast<uint8_t>(sum + data[i]);
    }
    return sum;
}

bool N32Audio::ReadExact(uint8_t* data, size_t length, int timeout_ms) {
    // v37：改成**总预算**。原来每次 uart_read_bytes 都重新给 timeout_ms，
    // 只要字节断断续续地来，一次"50ms 超时"的事务实际能拖到几百毫秒，
    // 全程还握着 UART 锁——这就是小智页偶发卡死的直接来源。
    size_t offset = 0;
    const int64_t deadline =
        esp_timer_get_time() + static_cast<int64_t>(timeout_ms) * 1000;
    while (offset < length) {
        const int64_t left_us = deadline - esp_timer_get_time();
        if (left_us <= 0) {
            return false;
        }
        TickType_t ticks = pdMS_TO_TICKS((left_us + 999) / 1000);
        if (ticks == 0) {
            ticks = 1;
        }
        const int received = uart_read_bytes(kUartPort, data + offset,
                                             length - offset, ticks);
        if (received <= 0) {
            return false;
        }
        offset += static_cast<size_t>(received);
    }
    return true;
}

bool N32Audio::SendCommand(uint8_t reg, const uint8_t* payload,
                           size_t payload_size, uint8_t* accepted) {
    if (payload_size > kMaxPayloadSize) {
        return false;
    }
    std::array<uint8_t, kMaxPayloadSize + 4> frame = {};
    frame[0] = kWritePrefix;
    frame[1] = reg;
    frame[2] = static_cast<uint8_t>(payload_size);
    if (payload_size > 0) {
        std::memcpy(frame.data() + 3, payload, payload_size);
    }
    frame[payload_size + 3] = Checksum(frame.data(), payload_size + 3);

    const size_t frame_size = payload_size + 4;

    // v45：事务时序对齐出厂 / known-good 驱动（audio_uart.cc::SendLocked，
    // 以及从 controlBoardOneS.mpy 逆向出的 uart_write）。v40~v44 在这里
    // 每帧都 uart_flush_input()、写完不等物理发完就读 ACK、失败还重发整帧
    // PCM、超时 400ms。连续流每秒约 120 帧，跑十来秒后 ACK 与帧逐渐错位：
    // 一旦 ReadExact 失败就持锁 400ms x2，并把同一段 PCM 发两遍 —— 节拍器
    // 听到「退化成偶尔一声」，小智音乐「跑一阵卡住」，UI 被 UART 锁一起拖住。
    // 正常路径零 flush；只有会话重开（StartLocked/Stop）或本次事务真出错
    // 时才清 RX，避免把上一帧迟到的应答冲掉。
    if (uart_write_bytes(kUartPort, frame.data(), frame_size) !=
        static_cast<int>(frame_size)) {
        uart_flush_input(kUartPort);
        ack_failures_.fetch_add(1);
        return false;
    }
    // 204 字节 @460800 约 4.4ms；uart_write_bytes 只保证数据进了发送缓冲，
    // 不保证已发完。不等 TX done 就开始读 ACK，会把上一帧迟到的应答当成
    // 这一帧的、或读到半帧 —— known-good 驱动显式 uart_wait_tx_done(20ms)。
    if (uart_wait_tx_done(kUartPort, pdMS_TO_TICKS(20)) != ESP_OK) {
        uart_flush_input(kUartPort);
        ack_failures_.fetch_add(1);
        return false;
    }
    std::array<uint8_t, 3> ack = {};
    if (!ReadExact(ack.data(), ack.size(), kCommandTimeoutMs) ||
        ack[0] != kWriteAck || ack[1] != reg) {
        // 绝不重发整帧：N32 可能已经收下数据、只是 ACK 丢了，重发会把同一段
        // PCM 播两遍，并把接收缓冲越灌越满。
        uart_flush_input(kUartPort);
        ack_failures_.fetch_add(1);
        return false;
    }
    if (accepted != nullptr) {
        *accepted = ack[2];
    }
    return true;
}

bool N32Audio::Init() {
    std::lock_guard<std::mutex> lock(UartMutex());
    if (initialized_) {
        return true;
    }

    if(g_uart_initialized){initialized_=true;return true;}
    const uart_config_t config = {
        .baud_rate = kUartBaudRate,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .rx_flow_ctrl_thresh = 0,
        .source_clk = UART_SCLK_APB,
        .flags = {},
    };
    if (uart_driver_install(kUartPort, 8192, 8192, 0, nullptr, 0) != ESP_OK) {
        ESP_LOGE(kTag, "UART 驱动安装失败");
        return false;
    }
    if (uart_param_config(kUartPort, &config) != ESP_OK) {
        ESP_LOGE(kTag, "UART 参数配置失败");
        return false;
    }
    if (uart_set_pin(kUartPort, kUartTx, kUartRx, UART_PIN_NO_CHANGE,
                     UART_PIN_NO_CHANGE) != ESP_OK) {
        ESP_LOGE(kTag, "UART 引脚设置失败");
        return false;
    }
    uart_flush_input(kUartPort);

    gpio_config_t keys={};keys.pin_bit_mask=(1ULL<<10)|(1ULL<<11)|(1ULL<<12)|(1ULL<<13);
    keys.mode=GPIO_MODE_INPUT;keys.pull_down_en=GPIO_PULLDOWN_ENABLE;gpio_config(&keys);
    vTaskDelay(pdMS_TO_TICKS(2000));
    initialized_ = true;
    g_uart_initialized = true;
    ESP_LOGI(kTag, "UART1 初始化完成 (TX=%d RX=%d baud=%d)",
             kUartTx, kUartRx, kUartBaudRate);
    return true;
}

bool N32Audio::SetHardwareVolumeLocked(int volume) {
    // Verified against the supplied original XiaoZhi firmware, function
    // 0x4202b084: level = (clamp(percent, 0, 100) * 6 + 50) / 100.
    // N32 expects an internal level, never a raw percentage such as 100.
    const uint8_t level = static_cast<uint8_t>(
        (std::clamp(volume, kVolumeMin, kVolumeMax) * 6 + 50) / 100);
    uint8_t accepted = 0;
    return SendCommand(kRegVolume, &level, 1, &accepted);
}

bool N32Audio::Start() {
    std::lock_guard<std::mutex> lock(UartMutex());
    return StartLocked();
}

bool N32Audio::StartLocked() {
    // 调用方必须已持有 UART 互斥锁

    // v45：重开会话前统一清一次 RX（旧实现是每帧 SendCommand 都 flush，
    // 见那里的注释）。这里清掉上一段流残留的应答，保证下面三条命令的
    // ACK 不会串位。
    uart_flush_input(kUartPort);

    // v37：顺序对齐已被实机验证的原版驱动（audio_uart.cc）：
    //   音量 -> 停录音 -> 44 字节 WAV 头。
    // v36 是「停录音 -> 音量 -> 头」，在 N32 上 0x10 写 0 会让音频通路
    // 复位一次，紧随其后的音量设置偶尔被吞掉，播放链路就停在「已应答但
    // 不出声」的半开状态。
    if (!SetHardwareVolumeLocked(100)) {
        ESP_LOGW(kTag, "设置音量失败（不影响播放，继续）");
    }

    // 半双工：播放前必须先停掉麦克风流
    const uint8_t stop_record = 0;
    if (!SendCommand(kRegAudioControl, &stop_record, 1)) {
        ESP_LOGW(kTag, "停止录音失败（不影响播放，继续）");
    }

    // 44 字节标准 WAV 头，向 N32 声明 24000Hz / 8bit / 单声道。
    constexpr uint32_t rate = kOutputSampleRate;
    const std::array<uint8_t, 44> wav_header = {
        'R', 'I', 'F', 'F', 0xff, 0xff, 0xff, 0xff,
        'W', 'A', 'V', 'E', 'f', 'm', 't', ' ',
        0x10, 0x00, 0x00, 0x00,        // fmt chunk size = 16
        0x01, 0x00,                    // PCM
        0x01, 0x00,                    // mono
        static_cast<uint8_t>(rate), static_cast<uint8_t>(rate >> 8),
        static_cast<uint8_t>(rate >> 16), static_cast<uint8_t>(rate >> 24),
        static_cast<uint8_t>(rate), static_cast<uint8_t>(rate >> 8),
        static_cast<uint8_t>(rate >> 16), static_cast<uint8_t>(rate >> 24),
        0x01, 0x00,                    // block align = 1
        0x08, 0x00,                    // 8 bits per sample
        'd', 'a', 't', 'a', 0xff, 0xff, 0xff, 0xff,
    };
    if (!SendCommand(kRegStream, wav_header.data(), wav_header.size())) {
        ESP_LOGE(kTag, "发送 WAV 头失败");
        return false;
    }

    g_recording = false;
    configured_ = true;
    last_write_us_ = esp_timer_get_time();
    ESP_LOGI(kTag, "播放已就绪：%u Hz / 8-bit unsigned / mono", kOutputSampleRate);
    return true;
}

void N32Audio::Stop() {
    std::lock_guard<std::mutex> lock(UartMutex());
    if (!configured_ && !g_recording) {
        return;
    }
    const uint8_t stop_record = 0;
    SendCommand(kRegAudioControl, &stop_record, 1);
    g_recording = false;
    configured_ = false;
    last_write_us_ = 0;
}

void N32Audio::SetVolume(int volume) {
    volume_ = std::clamp(volume, kVolumeMin, kVolumeMax);
    // 音量一律走软件缩放（Write() 内按 volume_ 对 PCM 缩放，真实生效）。
    // 不再每次按键写 N32 硬件寄存器 0x14 —— 高频写硬件音量曾触发链路异常导致重启。
}

int N32Audio::Level() {
    // Fast attack, slow release: fold in the loudest block seen since the last
    // UI frame, otherwise decay by roughly a quarter. Same curve as the local
    // standalone radio firmware, so the meter reads the same on both builds.
    const int peak = peak_.exchange(0);
    const int decayed = level_ - (level_ + 3) / 4;
    level_ = peak > decayed ? peak : decayed;
    return level_;
}

void N32Audio::BeepTaskThunk(void* arg) {
    static_cast<N32Audio*>(arg)->BeepWorker();
}

void N32Audio::BeepWorker() {
    // v41：三种工作状态按优先级串在一个循环里，不再靠层层 continue 跳转：
    //   1) 有新的单次音效（sfx_seq_ 变了）→ 播它
    //   2) 节拍器连续流开着 → ClickLoop
    //   3) 常开底流开着 → IdleLoop（写静音，边写边看有没有新请求）
    //   4) 都不满足 → 等通知，空闲 3 秒自行退出
    for (;;) {
        if (beep_stop_.load()) {
            // 退出功能页：先收流再清句柄，最后删自己。KeepAlive 必须一起关，
            // 否则重新进页面时任务会带着旧状态继续写静音。
            click_on_.store(false);
            keep_on_.store(false);
            beep_stop_.store(false);
            beep_busy_.store(false);
            auto mux = static_cast<SemaphoreHandle_t>(beep_mux_);
            if (mux) xSemaphoreTake(mux, portMAX_DELAY);
            beep_task_.store(nullptr);
            if (mux) xSemaphoreGive(mux);
            vTaskDelete(nullptr);
            return;
        }

        const uint32_t seq = sfx_seq_.load(std::memory_order_acquire);
        if (seq != sfx_done_.load()) {
            // 先记已播再播：播放期间来的新请求（seq 又变了）下一轮还能看到，
            // 不会因为"播完再记"把它吞掉。
            sfx_done_.store(seq);
            beep_busy_.store(true);
            if (beep_kind_.load(std::memory_order_acquire) == 1) {
                // 音频文件：指针和长度在 kind=1 之前就已写好，这里读到的一定是
                // 同一份请求（覆盖式队列，和 Beep() 的语义一致）。
                PlayPcmBlock(pcm_src_.load(), pcm_bytes_.load(), pcm_tail_ms_.load());
            } else {
                PlayBeep(beep_req_.load(std::memory_order_relaxed));
            }
            beep_busy_.store(false);
            continue;
        }

        // v41：节拍器连续流优先。只要 click_on_ 为真就一直按拍写 PCM，
        // 写完一拍接下一拍，不重开播放会话；直到 UI 那边把它关掉才返回。
        if (click_on_.load()) {
            ClickLoop();
            // 流期间攒下的通知和那一次单音效请求都作废，否则收流之后
            // 会突然把上一次的音效（甚至很早以前的）补播一遍。
            (void)ulTaskNotifyTake(pdTRUE, 0);
            sfx_done_.store(sfx_seq_.load());
            continue;
        }

        if (keep_on_.load()) {
            IdleLoop();
            continue;
        }

        // 空闲 3 秒 or 页面退出 -> 任务自行结束并清掉句柄，不留后台常驻任务
        const uint32_t got = ulTaskNotifyTake(pdTRUE, pdMS_TO_TICKS(3000));
        if (got == 0) {
            beep_stop_.store(true);  // 走上面统一的收尾分支
        }
    }
}

// v41：把"毫秒静音"作为一段流写出去。会自己分块，块大小与 PlayPcmBlock 一致。
bool N32Audio::WriteSilence(int ms) {
    if (ms <= 0) return true;
    constexpr int kBlockSamples = 200;
    int16_t quiet[kBlockSamples] = {};
    size_t left = static_cast<size_t>(ms) * kOutputSampleRate / 1000;
    while (left > 0) {
        const size_t n = std::min<size_t>(kBlockSamples, left);
        if (Write(quiet, static_cast<int>(n)) <= 0) {
            beep_fail_.fetch_add(1);
            configured_ = false;
            return false;
        }
        left -= n;
    }
    return true;
}

bool N32Audio::NeedsFreshSession() const {
    const int64_t now_us = esp_timer_get_time();
    return !configured_ || g_recording || last_write_us_ == 0 ||
           (now_us - last_write_us_) > 400 * 1000;
}

// v41：常开底流的写循环，直到有新的单次音效、停流或页面退出才返回。
// 每块 200 样本（8.3ms），按墙上时钟配速，和 ClickLoop 相同的节奏算法。
void N32Audio::IdleLoop() {
    constexpr int kBlockSamples = 200;
    int16_t quiet[kBlockSamples] = {};
    const int sr = static_cast<int>(kOutputSampleRate);
    // v42：底流启动时先看会话状态。凉的（换页超过 500ms / 从未开过）必须
    // 完整握手并垫上吞音窗口的静音。以前直接 Write()：Write() 只看
    // configured_ 不看流间隙，会把静音写进一个 N32 早已判结束的会话，
    // 白写；而且冷会话直接开写，头一段数据落在 N32 的预缓冲丢弃窗口里。
    if (NeedsFreshSession()) {
        if (!EnsureStream() || !WriteSilence(kStreamLeadInMs)) {
            keep_on_.store(false);
            vTaskDelay(pdMS_TO_TICKS(150));
            return;
        }
    }
    int64_t start_us = esp_timer_get_time();
    int64_t written = 0;
    beep_busy_.store(true);
    while (keep_on_.load() && !beep_stop_.load() &&
           sfx_seq_.load() == sfx_done_.load() && !click_on_.load()) {
        const int64_t now_us = esp_timer_get_time();
        const int64_t due = (now_us - start_us) * sr / 1000000;
        int64_t behind = due - written;
        if (behind > sr / 12) {
            // v44：和 ClickLoop 一样重新锚定时钟基准，不追补、不跳相位。
            // 静音底流一口气补半秒会把 N32 接收缓冲灌满，节拍器起流时
            // 立刻撞上背压 / 重预缓冲（Write() 现在把背压当正常流控，不再
            // 误重置链路，但水位仍应尽量保持浅）。
            start_us = now_us - written * 1000000 / sr;
            behind = 0;
        }
        if (behind < kBlockSamples) {
            vTaskDelay(1);  // CONFIG_FREERTOS_HZ=1000：1ms；缓冲吸收这点抖动
            continue;
        }
        // 一次最多 2 块，避免长时间追赶灌缓冲。
        int blocks = static_cast<int>(std::min<int64_t>(behind / kBlockSamples, 2));
        while (blocks-- > 0) {
            if (Write(quiet, kBlockSamples) <= 0) {
                beep_fail_.fetch_add(1);
                configured_ = false;
                keep_on_.store(false);
                vTaskDelay(pdMS_TO_TICKS(150));
                beep_busy_.store(false);
                return;
            }
            written += kBlockSamples;
        }
    }
    beep_busy_.store(false);
}

void N32Audio::KeepAlive(bool on) {
    if (keep_on_.exchange(on) == on) return;  // 状态没变，省掉每 20ms 一次的通知开销
    void* task = EnsureBeepTask();
    if (task == nullptr) {
        keep_on_.store(false);
        return;
    }
    xTaskNotifyGive(static_cast<TaskHandle_t>(task));
}

void N32Audio::StopBeepTask() {
    // v35：置标志与取句柄必须在同一把锁里。原来先 store(true) 再 load 句柄，
    // 中间任务可能正好自删并把 beep_task_ 清空——这里的 load 还是能读到旧值，
    // 于是 xTaskNotifyGive 打在一个已经释放的 TCB 上（退出功能页时死机）。
    auto mux = static_cast<SemaphoreHandle_t>(beep_mux_);
    if (mux) xSemaphoreTake(mux, portMAX_DELAY);
    beep_stop_.store(true);
    void* t = beep_task_.load();
    if (mux) xSemaphoreGive(mux);
    if (t) xTaskNotifyGive(static_cast<TaskHandle_t>(t));
}

void N32Audio::Beep(int freq, int ms, int type) {
    if (freq <= 0 || ms <= 0) return;
    // v35：不再「上一个音效还没发完就丢弃这一次」。游戏里吃豆/击砖/过关都是
    // 连续触发，按旧逻辑会被丢得只剩零星一声。这里改成覆盖成最新的请求，
    // 任务处理完手上这份就会看到最新的一份，至少最后一次一定响。
    const uint32_t req = (static_cast<uint32_t>(freq & 0x3FFF) << 18) |
                         (static_cast<uint32_t>(ms & 0x3FF) << 8) |
                         static_cast<uint32_t>(type & 0xFF);
    beep_req_.store(req, std::memory_order_relaxed);
    beep_kind_.store(0, std::memory_order_release);
    (void)sfx_seq_.fetch_add(1, std::memory_order_release);
    void* task = EnsureBeepTask();
    if (task == nullptr) return;
    xTaskNotifyGive(static_cast<TaskHandle_t>(task));
}

void N32Audio::PlayPcm(const uint8_t* pcm, size_t bytes, int tail_ms) {
    if (pcm == nullptr || bytes == 0) return;
    // 与 Beep() 完全相同的覆盖式投递：后来的请求顶掉前一个，任务处理完手上
    // 这份就会看到最新那份，至少最后一次一定响。
    pcm_src_.store(pcm, std::memory_order_relaxed);
    pcm_bytes_.store(bytes, std::memory_order_relaxed);
    pcm_tail_ms_.store(tail_ms >= 0 ? tail_ms : 60, std::memory_order_relaxed);
    beep_kind_.store(1, std::memory_order_release);
    (void)sfx_seq_.fetch_add(1, std::memory_order_release);
    void* task = EnsureBeepTask();
    if (task == nullptr) return;
    xTaskNotifyGive(static_cast<TaskHandle_t>(task));
}

void N32Audio::SetClickPcm(const uint8_t* accent, size_t accent_bytes,
                           const uint8_t* weak, size_t weak_bytes) {
    click_accent_pcm_.store(accent, std::memory_order_relaxed);
    click_accent_bytes_.store(accent_bytes, std::memory_order_relaxed);
    click_weak_pcm_.store(weak, std::memory_order_relaxed);
    click_weak_bytes_.store(weak_bytes, std::memory_order_relaxed);
}

void* N32Audio::EnsureBeepTask() {
    if (!beep_mux_) beep_mux_ = xSemaphoreCreateMutex();
    auto mux = static_cast<SemaphoreHandle_t>(beep_mux_);
    if (mux) xSemaphoreTake(mux, portMAX_DELAY);
    void* task = beep_task_.load();
    if (task == nullptr) {
        TaskHandle_t handle = nullptr;
        // v34：这里必须把 beep_stop_ 复位。StopBeepTask() 会把它置 true，
        // 以前新建任务时没有清回来，导致「第一次退出功能页之后，后面所有
        // 音效都被新任务当成退出指令，一声都不响」。
        beep_stop_.store(false);
        beep_busy_.store(false);
        // v42：优先级 6，**高于 UI 的 5**。这是 v41 四个症状（打砖块全无
        // 声、蛇/方块时有时无、节拍器 3 秒丢一拍、倒计时末尾丢音）的共同
        // 根因：每个 200B PCM 帧是「写→等应答」的同步事务，应答到达后任务
        // 唤醒要排在 UI 后面。一帧音频只有 8.3ms，而打砖块每 12ms 全画布
        // 重绘、LvglPump 每 3 秒一次全屏强制重绘时，应答唤醒平均多等
        // 5~12ms，喂流速度跌破 24kHz —— N32 约 150ms 的接收缓冲一旦耗尽，
        // 重新预缓冲会丢弃随后约 150ms 的数据（丢的就是那一拍/那一声短音）。
        // 提到 6 以后写流可抢占渲染：每块 CPU 占用不到 1ms，其余时间阻塞在
        // 等 UART 应答上（阻塞即让出 CPU），不会拖慢 UI；仍低于收音机任务
        // 的 7/8，收音机收尾时音效让路（那两页本来就不该有音效）。
        if (xTaskCreate(&N32Audio::BeepTaskThunk, "game_beep", 3072, this, 6,
                        &handle) != pdPASS) {
            if (mux) xSemaphoreGive(mux);
            beep_fail_.fetch_add(1);
            ESP_LOGW(kTag, "音效任务创建失败（内存不足）");
            return nullptr;
        }
        beep_task_.store(handle);
        task = handle;
    }
    if (mux) xSemaphoreGive(mux);
    return task;
}

void N32Audio::ClickStream(bool on, int accent_freq, int weak_freq, int tone_ms,
                           int period_ms, int beats_per_bar) {
    // 参数先落地：不管这次是起流、改参数还是停流，下一轮循环都读最新的。
    click_accent_.store(accent_freq > 0 ? accent_freq : 1568);
    click_weak_.store(weak_freq > 0 ? weak_freq : 1047);
    click_tone_ms_.store(tone_ms > 0 ? tone_ms : 90);
    click_period_ms_.store(period_ms > 0 ? period_ms : 500);
    click_bar_.store(beats_per_bar > 0 ? beats_per_bar : 4);
    if (!on) {
        // 只有真的从"开"变成"关"才需要叫醒任务，避免 UI 每 20ms 一次空通知。
        if (click_on_.exchange(false)) {
            void* t = beep_task_.load();
            if (t != nullptr) xTaskNotifyGive(static_cast<TaskHandle_t>(t));
        }
        return;
    }
    if (click_on_.exchange(true)) return;  // 已经在跑：只更新了参数
    // 起流前把那一次单音效请求清掉：节拍器运行期间它不该被补播。
    beep_req_.store(0, std::memory_order_relaxed);
    void* task = EnsureBeepTask();
    if (task == nullptr) {
        click_on_.store(false);
        return;
    }
    xTaskNotifyGive(static_cast<TaskHandle_t>(task));
}

void N32Audio::ClickLoop() {
    const int sr = static_cast<int>(kOutputSampleRate);
    constexpr int kBlockSamples = 200;  // 一个 UART 帧 = 200 样本 = 8.3ms 音频
    int16_t block[kBlockSamples];
    const int fade = sr / 200;  // 5ms 淡入淡出，去掉每拍的"咔"
    // v42：起流前先看会话状态。凉会话（刚开机 / 换页回来）必须完整握手并
    // 垫上吞音窗口的静音，否则第一拍落在 N32 预缓冲的丢弃窗口里，
    // 实机听感就是"节拍器起拍头一两声没有"。温热会话（底流刚跑过）不垫。
    if (NeedsFreshSession()) {
        if (!EnsureStream() || !WriteSilence(kStreamLeadInMs)) {
            click_on_.store(false);
            vTaskDelay(pdMS_TO_TICKS(150));
            return;
        }
    }
    // v45：**纯 ACK 驱动**，照出厂播放器 player.cc::Feed() 的模型 ——
    // 全速按块写、由 N32 的 ACK 往返定速，host 侧不再用 esp_timer 追赶。
    // v42~v44 全都保留墙上时钟驱动：音频时间轴按 (now-start)*sr 算「应该
    // 写到哪」，而 ESP32 晶振与 N32 DAC 晶振必有 ppm 级偏差，连续流跑十来秒
    // 后接收缓冲不是被灌满就是被排空，随后背压与重握手交替 —— 这就是五版
    // 都没修掉的「开始正常、过一阵只剩偶尔一声」。现在时间轴只由 written
    // （实际写进 N32 的样本数）决定，物理播放速率由 N32 自己锁定；墙上时钟
    // 只留一个 1 秒的「防止无限预生成」看门狗，完全不参与配速。
    int64_t start_us = esp_timer_get_time();
    const int64_t loop_start_us = start_us;
    int64_t written = 0;
    const uint32_t stalls_at_start = stream_stalls_.load();
    const uint32_t resets_at_start = stream_resets_.load();
    const uint32_t acks_at_start = ack_failures_.load();
    const uint32_t gaps_at_start = stream_gaps_.load();
    int heal_failures = 0;
    beep_busy_.store(true);
    while (click_on_.load() && !beep_stop_.load()) {
        const int64_t now_us = esp_timer_get_time();
        const int64_t due = (now_us - start_us) * sr / 1000000;
        // 只看门狗：领先超过 0.5 秒就等一会儿，避免 ACK 意外立即返回时把
        // 整条流预生成进去（那样按停止后还会响很久）。正常情况由 Write()
        // 里的 accepted 背压锁定速率，这一条不会触发；即便触发，0.5 秒水位
        // 对 ppm 级晶振偏差也有上千秒的余量，不会像 v44 的 40ms 那样十来秒
        // 就被灌满/排空。
        if (written > due + sr / 2) {
            vTaskDelay(1);
            continue;
        }
        // host 被长时间阻塞过：只重新锚定内部时钟，不动 written、不补数据、
        // 不跳拍。这不是配速，只是让上面的看门狗基准跟上现实。
        if (due > written + 2 * sr) {
            start_us = now_us -
                       static_cast<int64_t>(written) * 1000000 / sr;
        }
        // 每轮固定只写一块。v42/v43 的「一次补 2~4 块」和 v44 的「重锚定后
        // 补 40ms 浅水位」本质上都在向 N32 灌缓冲，长跑必然单向漂移。
        int blocks = 1;
        while (blocks-- > 0 && click_on_.load() && !beep_stop_.load()) {
            const int period_ms = std::max(60, click_period_ms_.load());
            const int bar = std::max(1, click_bar_.load());
            const int period = std::max(sr / 10, sr * period_ms / 1000);
            int tone = sr * std::max(10, click_tone_ms_.load()) / 1000;
            const int min_gap = sr / 50;  // 每拍留 20ms 静音，否则听不出拍与拍
            if (tone > period - min_gap) tone = std::max(sr / 50, period - min_gap);
            const uint8_t* apcm = click_accent_pcm_.load();
            const size_t alen = click_accent_bytes_.load();
            const uint8_t* wpcm = click_weak_pcm_.load();
            const size_t wlen = click_weak_bytes_.load();
            for (int i = 0; i < kBlockSamples; ++i) {
                const int64_t p = written + i;
                const int pos = static_cast<int>(p % period);
                float v = 0.0f;
                if (pos < tone) {
                    const int beat = static_cast<int>((p / period) % bar);
                    const uint8_t* src = (beat == 0) ? apcm : wpcm;
                    const size_t slen = (beat == 0) ? alen : wlen;
                    if (src != nullptr && slen > 0) {
                        // v40：有音频文件就直接从文件取样（mmap 指针，不占 RAM）。
                        // 文件自带包络，所以不再叠淡入淡出；文件比一拍短，后面补静音。
                        if (static_cast<size_t>(pos) < slen) {
                            block[i] = static_cast<int16_t>(
                                (static_cast<int>(src[pos]) - 128) * 256);
                        } else {
                            block[i] = 0;
                        }
                        continue;
                    }
                    // 没有文件就退回合成音，保证只有 app 没有新资源包时也有声。
                    // 每小节第一拍高八度：不看屏幕也能听出小节头。
                    const int freq = (beat == 0) ? click_accent_.load() : click_weak_.load();
                    const float t = static_cast<float>(pos) / static_cast<float>(sr);
                    const float ph = std::fmod(t * static_cast<float>(freq), 1.0f);
                    v = ph < 0.5f ? 0.92f : -0.92f;
                    if (pos < fade) {
                        v *= static_cast<float>(pos) / static_cast<float>(fade);
                    } else if (pos > tone - fade) {
                        v *= static_cast<float>(tone - pos) / static_cast<float>(fade);
                    }
                }
                block[i] = static_cast<int16_t>(v * 20000.0f);
            }
            const int wrote = Write(block, kBlockSamples);
            if (wrote != kBlockSamples) {
                // v44：单次写失败不再把整条流停掉。v40~v43 在这里清
                // click_on_ 退出 ClickLoop，靠 UI 每 20ms 一次的
                // ClickStream(true) 重新起流——每次都要重握手 + 垫 240ms
                // 吞音窗口，长跑时失败一多就是「偶尔一声」。这里就地自愈：
                // 重握手、垫窗口，然后按原相位接着写。
                beep_fail_.fetch_add(1);
                configured_ = false;
                if (!EnsureStream() || !WriteSilence(kStreamLeadInMs)) {
                    if (++heal_failures >= 10) {
                        ESP_LOGW(kTag, "节拍器链路连续 10 次重建失败，停流");
                        click_on_.store(false);
                    }
                    vTaskDelay(pdMS_TO_TICKS(150));
                } else {
                    heal_failures = 0;
                }
                break;  // 回到外层重新配速，不重复写这一块
            }
            heal_failures = 0;
            written += kBlockSamples;
            // 让出 CPU 给低优先级 UI：game_beep 是优先级 6，ACK 若恰好已在
            // FIFO 里，整个循环可能一次都不阻塞，LVGL 会被饿死。这不是配速
            // —— 实际速率仍由 N32 的 accepted 背压决定。
            vTaskDelay(1);
        }
    }
    // v45：只在收流时打一条汇总，不再每 10 秒周期性打日志。v44 那条
    // ESP_LOGI 要同步输出约 10ms（还含 %.1f 浮点格式化），比一帧音频
    // 8.3ms 还长，恰好在用户反馈的「10 秒左右出问题」周期上制造抖动。
    // 诊断改为事件计数（ack_failures_ / stream_stalls_ / stream_resets_）
    // + 收流汇总，零周期性抖动。
    ESP_LOGI(kTag,
             "metro stop t=%.1fs written=%lld stalls=%u resets=%u ackfail=%u gaps=%u "
             "fails=%d",
             static_cast<double>(esp_timer_get_time() - loop_start_us) / 1000000.0,
             static_cast<long long>(written),
             static_cast<unsigned>(stream_stalls_.load() - stalls_at_start),
             static_cast<unsigned>(stream_resets_.load() - resets_at_start),
             static_cast<unsigned>(ack_failures_.load() - acks_at_start),
             static_cast<unsigned>(stream_gaps_.load() - gaps_at_start),
             beep_fail_.load());
    beep_busy_.store(false);
}

bool N32Audio::EnsureStream() {
    // v37：**只在链路真的断开时重握手**。
    // v36 每次 Beep 都发一遍 44 字节 WAV 头：连续音效（倒计时三声、游戏连击）
    // 时上一段流还没结束，新头会被 N32 当成 PCM 数据播出去——用户听到的
    // 「结束时有疑似声音、但像喇叭异响」正是这 44 个 RIFF 字节。
    // 反过来，流间隙超过约 500ms 后芯片会把这一段播放会话判为结束（原版
    // 驱动 audio_uart.cc 的 kStreamGapUs 是实机结论），这时必须重发头，
    // 否则后面的 PCM 会被静默吞掉。
    const int64_t now_us = esp_timer_get_time();
    const bool stream_gap =
        last_write_us_ == 0 || (now_us - last_write_us_) > 400 * 1000;
    if (!configured_ || g_recording || stream_gap) {
        if (!Start()) {
            // 链路可能停在半开状态（上一路流没退净），完整复位一次再重来
            Stop();
            if (!Start()) {
                beep_fail_.fetch_add(1);
                return false;
            }
        }
    }
    return true;
}

void N32Audio::PlayPcmBlock(const uint8_t* pcm, size_t bytes, int tail_ms) {
    if (pcm == nullptr || bytes == 0) return;
    // v41：**先判断这次会不会重开播放会话**，再握手——N32 每重开一次会话，
    // 开头约 100~150ms 的数据会被吞掉（它要先把接收缓冲填起来才推 DAC）。
    // 这条结论是四轮实机结果对齐出来的：55ms 的节拍器弱拍在连续流里听得见，
    // 单独的 45ms 移动音、42ms 读秒声、95ms 碰撞音全都听不见，而 172ms 的
    // 结束音、362ms 的失败音听得见。
    // 会重开会话时先在音效前面垫一段静音，把这 150ms 的窗口喂掉，音效本体
    // 才落在真正会发声的位置上。会话温热（常开底流在跑）时不需要垫。
    const bool fresh = NeedsFreshSession();
    if (!EnsureStream()) {
        ESP_LOGW(kTag, "音效握手失败（文件音效 %u B）", (unsigned)bytes);
        return;
    }
    if (fresh && !WriteSilence(kStreamLeadInMs)) return;
    // 8-bit unsigned -> 16-bit signed：Write() 内部会再转回 8-bit unsigned
    // （(s + 32768) >> 8），所以这里 (u8 - 128) * 256 是精确往返，不损失量化。
    int16_t block[200];
    constexpr int kBlockSamples = 200;
    size_t done = 0;
    while (done < bytes) {
        const size_t n = std::min<size_t>(kBlockSamples, bytes - done);
        for (size_t i = 0; i < n; ++i) {
            block[i] = static_cast<int16_t>((static_cast<int>(pcm[done + i]) - 128) * 256);
        }
        if (Write(block, static_cast<int>(n)) <= 0) {
            beep_fail_.fetch_add(1);
            ESP_LOGW(kTag, "音效写入失败（文件音效，已写 %u/%u B）", (unsigned)done,
                     (unsigned)bytes);
            configured_ = false;
            return;
        }
        done += n;
    }
    // 尾巴补一点静音，别让流断在波形中间（默认 60ms）。
    (void)WriteSilence(tail_ms > 0 ? tail_ms : 60);
}

void N32Audio::PlayBeep(uint32_t req) {
    const int freq = static_cast<int>(req >> 18);
    const int ms = static_cast<int>((req >> 8) & 0x3FF);
    const int type = static_cast<int>(req & 0xFF);
    if (freq <= 0 || ms <= 0) return;

    const int sr = 24000;
    // v37：音调最短 83ms、最长 500ms。18~30ms 的短音在 N32 的接收/播放
    // 缓冲里根本来不及开播，这就是「游戏一声都不响」最直接的原因——
    // 数据全都写出去了（beep_fail 为 0），但芯片还没开始播，流就断了。
    int tone = (sr * ms) / 1000;
    if (tone < sr / 12) tone = sr / 12;   // 83 ms
    if (tone > sr / 2) tone = sr / 2;     // 500 ms
    // v39：type=2 是节拍器的"嗒"。它每拍都要发一次，240 BPM 时拍间隔只有
    // 250ms，而普通音效的 20ms 预热 + 150ms 静音尾就要 253ms，会跟下一拍
    // 叠在一起（Beep 是覆盖式队列，结果就是丢拍）。这里把首尾都收短。
    const bool click = (type == 2);
    const int pre = click ? sr / 100 : sr / 50;      // 10ms / 20ms 预热
    const int tail = click ? sr / 25 : sr * 3 / 20;  // 40ms / 150ms 尾巴
    const int total = pre + tone + tail;

    // v41：这是资源包缺失时的兜底路径。同样要在重开会话时先垫静音——
    // 以前补在**尾部**的 340ms 静音完全没用：被吞掉的是开头那一段。
    const bool fresh = NeedsFreshSession();
    if (!EnsureStream()) {
        ESP_LOGW(kTag, "音效握手失败 freq=%d ms=%d", freq, ms);
        return;
    }
    if (fresh && !WriteSilence(kStreamLeadInMs)) return;

    // 分块合成并写出：每块最多 200 样本（400 B，即 2 个 200 B 的 UART 帧）。
    // 不再一次性分配整段 1.5s 的缓冲（那要 72 KB），也不再依赖 PSRAM 大块分配。
    int16_t block[200];
    constexpr int kBlockSamples = sizeof(block) / sizeof(block[0]);
    const int fade = sr / 200;  // 5ms 淡入淡出，去掉起振/收尾的"咔"声
    for (int off = 0; off < total; off += kBlockSamples) {
        const int n = std::min(kBlockSamples, total - off);
        for (int i = 0; i < n; ++i) {
            const int k = off + i;
            float v = 0.0f;
            if (k >= pre && k < pre + tone) {
                const int j = k - pre;
                const float t = static_cast<float>(j) / static_cast<float>(sr);
                if (click) {
                    // v40：满幅方波，不再套指数衰减。v39 用 exp(-38t) 让音在
                    // 60ms 内落到底，实机测试（游戏碰撞音、节拍器、读秒声）
                    // 全都听不到——衰减把能量收掉之后这一下就只剩个毛刺。
                    // 这台小喇叭上唯一确定听得见的就是满幅方波，短音要响就得
                    // 跟长音一样的幅度，只靠"时长短"来区分听感。
                    const float ph = std::fmod(t * static_cast<float>(freq), 1.0f);
                    v = ph < 0.5f ? 0.92f : -0.92f;
                } else if (type == 1) {
                    v = std::sin(2.0f * 3.14159265f * static_cast<float>(freq) * t);
                } else {
                    const float ph = std::fmod(t * static_cast<float>(freq), 1.0f);
                    v = ph < 0.5f ? 0.92f : -0.92f;  // 方波更"街机"
                }
                if (j < fade) {
                    v *= static_cast<float>(j) / static_cast<float>(fade);
                } else if (j > tone - fade) {
                    v *= static_cast<float>(tone - j) / static_cast<float>(fade);
                }
            }
            // v37：幅度 9000 -> 20000。旧值转成 8-bit 后只有 ±35/128（约
            // -11 dBFS），几十毫秒的短音在小喇叭上几乎听不见。
            block[i] = static_cast<int16_t>(v * 20000.0f);
        }
        if (Write(block, n) <= 0) {
            beep_fail_.fetch_add(1);
            ESP_LOGW(kTag, "音效写入失败 freq=%d ms=%d fail=%d", freq, ms,
                     beep_fail_.load());
            configured_ = false;
            return;
        }
    }
}

int N32Audio::Write(const int16_t* samples, int sample_count) {
    if (samples == nullptr || sample_count <= 0) {
        return 0;
    }

    std::unique_lock<std::mutex> lock(UartMutex());

    // v51：**撤销 v48 在这里加的「流间隙自愈」**。
    // v48 曾在这里判断「距上次写入 >500ms」就置 configured_=false，进而调
    // StartLocked() 做一次完整冷启动握手（音量 → 停录音 0x10=0 → 44B WAV 头）。
    // 实机证明这个方向是错的，两个功能都被它伤到：
    //   1) 收音机：PlaybackTask 在预缓冲 / 重缓冲 / 暂停后恢复时，间隙本来就
    //      远超 500ms（kInitialPrebufferBytes、kRebufferBytes、kBuffering 的
    //      50ms 步进循环，暂停时更是直接 audio_->Stop()）。于是每次缓冲恢复
    //      都多做一次冷启动：中间那条 0x10 停录音让 N32 音频通路复位一次，
    //      再吞掉开头 100~150ms → 现场就是「收音机不正常」。
    //   2) 小智：/api/status 的 io_gaps 实测在播放中触发了 2 次，每次同样吞
    //      100~150ms → 正是「偶尔卡一下」。
    //   3) 而且它并没有修好 v48 想修的问题（v48 实机仍卡），说明「N32 已经
    //      把会话结账了」这个推断本身缺乏证据。
    // 会话重开现在统一由上层负责，各条路径本来就有：音效走
    // NeedsFreshSession() + EnsureStream()，收音机走 Stop()/Pause()/generation，
    // 小智靠播放队列排空后的新会话。这里只统计间隙，不做任何动作。
    const int64_t now_us = esp_timer_get_time();
    if (last_write_us_ != 0 && (now_us - last_write_us_) > kStreamGapUs) {
        stream_gaps_.fetch_add(1);
    }

    // 此处已持有互斥锁，必须调用无锁版本，否则 std::mutex 不可重入会死锁
    if ((!configured_ || g_recording) && !StartLocked()) {
        ESP_LOGE(kTag, "播放未就绪，丢弃 %d 样本", sample_count);
        return 0;
    }

    const size_t total = static_cast<size_t>(sample_count);
    size_t written = 0;
    std::array<uint8_t, kMaxPayloadSize> chunk = {};
    // Measure every other block. The RMS uses the SCALED samples (after the
    // software volume below), so volume/mute is reflected in the meter exactly
    // as it is in the speaker - no independent fake animation.
    const bool measure = (++level_tick_ >= 2);
    if (measure) level_tick_ = 0;
    uint64_t sum_sq = 0;
    uint64_t measured = 0;

    while (written < total) {
        if (!lock.owns_lock()) lock.lock();
        if (!configured_ || g_recording) return static_cast<int>(written);
        const size_t n = std::min(total - written, kMaxPayloadSize);

        // 软件音量：直接对 PCM 样本缩放（N32 寄存器 0x14 在播放流中
        // 可能不响应，软件缩放保证真实音量一定变化；100 时旁路不缩）。
        const int vol = volume_.load();
        for (size_t i = 0; i < n; ++i) {
            int32_t s = samples[written + i];
            if (vol != kVolumeMax) {
                s = (s * vol) / 100;
            }
            if (measure) {
                sum_sq += static_cast<uint64_t>(static_cast<int64_t>(s) * s);
                ++measured;
            }
            // 16-bit signed -> 8-bit unsigned：静音(0) 映射到 128。
            // v48：对齐 known-good audio_uart.cc 的**四舍五入**而不是截断
            // （+128 后右移）。截断等于给 DAC 常驻 -0.5 LSB 的直流偏置，
            // 8bit 输出下这就是一层固定的量化失真 + 可能的直流嗡声。
            // 必须 clamp：s=32767 时 (32767+32768+128)>>8 = 256 会溢出成 0，
            // 满幅峰值直接翻成静音，就是一声爆音。
            const int rounded = (s + 32768 + 128) >> 8;
            chunk[i] = static_cast<uint8_t>(
                rounded < 0 ? 0 : (rounded > 255 ? 255 : rounded));
        }

        size_t sent = 0;
        // v44：accepted==0 是 N32「接收缓冲满」的**正常背压**，不是链路故障。
        // v40~v43 把它当故障：连续 20 次(约 100ms)收不下就 configured_=false
        // 重置链路。连续流(节拍器)长跑时，ESP32 的 esp_timer 与 N32 的播放
        // 时钟必然有 ppm 级失配，host 稍微快一点，接收缓冲迟早会顶满；一旦
        // 100ms 消化不完就重置，下一次 Write() 又在**流中间**重发 44B WAV 头
        // （被 N32 当成 PCM 播出 / 触发重新预缓冲吞掉 150ms），之后缓冲再满、
        // 再重置……听感正是「开始正常，跑一阵只剩偶尔一声」。
        // 现在按时间预算耐心等背压消化，只有真正的通信失败才重置。
        const int64_t stall_deadline =
            esp_timer_get_time() + 1500 * 1000;  // 1.5s 都收不下才是真卡死
        while (sent < n) {
            PollKeysLocked();
            uint8_t accepted = 0;
            if (!SendCommand(kRegStream, chunk.data() + sent, n - sent,
                             &accepted)) {
                ESP_LOGW(kTag, "PCM 通信失败，重置播放链路");
                configured_ = false;
                stream_resets_.fetch_add(1);
                return static_cast<int>(written + sent);
            }
            if (accepted == 0) {
                if (esp_timer_get_time() > stall_deadline) {
                    ESP_LOGW(kTag, "N32 背压超时 1.5s，重置播放链路");
                    configured_ = false;
                    stream_resets_.fetch_add(1);
                    return static_cast<int>(written + sent);
                }
                stream_stalls_.fetch_add(1);
                // v45：对齐出厂 uart_write_buf 的 10ms / known-good 驱动的 5ms。
                // 2ms 会在缓冲满时每秒多打 500 次无效 200B 帧，反而拖慢 N32
                // 消化背压；5ms 让芯片有时间把已收的数据推给 DAC。
                vTaskDelay(std::max<TickType_t>(1, pdMS_TO_TICKS(5)));
                continue;
            }
            sent += std::min<size_t>(accepted, n - sent);
        }
        written += n;
        last_write_us_ = esp_timer_get_time();
        // v46：**整次 Write 期间保持持有 UART 锁**，不再每 200 字节就 unlock。
        // 旧注释说「让 key polling 用总线」，但 PollKeysLocked() 现在只是
        // ReadKeys() 直接读 GPIO（按键根本不走 UART），这个让步早已没有意义，
        // 只剩下副作用：小智一帧 60ms TTS 有 1440 样本 = 8 个 UART 事务，
        // 每发一块就放锁 + yield，等于把一帧切成 8 段，每一段都可能被
        // game_beep(6) / audio_input(8) 插进来抢走总线（N32 是半双工，
        // 录音事务还会把播放会话整个拆掉）。这是「小智播放卡顿」而节拍器
        // 正常的关键差异：节拍器每次只 Write 200 样本 = 1 块，不受影响。
        // 现在 8 个事务原子发完，中途只 taskYIELD() 让同优先级 UI 轮转；
        // 每个事务里的 uart_wait_tx_done / ReadExact 本身就会阻塞让出 CPU，
        // 不会饿死其他任务。整次写完由 unique_lock 析构释放锁。
        taskYIELD();
    }
    if (measure && measured > 0) {
        const double rms = std::sqrt(static_cast<double>(sum_sq) / measured) / 32768.0;
        int percent = static_cast<int>(rms * 330.0);
        if (percent > 100) percent = 100;
        int seen = peak_.load();
        while (percent > seen && !peak_.compare_exchange_weak(seen, percent)) {
        }
    }
    return sample_count;
}

uint8_t N32Audio::ReadKeys() {
    uint8_t keys=(gpio_get_level(GPIO_NUM_13)?4:0)|(gpio_get_level(GPIO_NUM_12)?8:0)|
        (gpio_get_level(GPIO_NUM_11)?2:0)|(gpio_get_level(GPIO_NUM_10)?1:0);
    g_keys=keys;g_keys_at=esp_timer_get_time();g_key_polls++;return keys;
}

uint32_t N32Audio::key_polls() const { return g_key_polls.load(); }
uint8_t N32Audio::cached_keys() const { return g_keys.load(); }

void N32Audio::PollKeysLocked() { ReadKeys(); }

uint8_t N32Audio::ReadKeysLocked() {

    // 读键事务：0x80 <reg> <len> -> 应答 0x81 <reg> <len> <value> <sum>
    const std::array<uint8_t, 3> query = {kReadPrefix, kRegKey, 1};
    std::array<uint8_t, 5> response = {};

    uart_flush_input(kUartPort);
    if (uart_write_bytes(kUartPort, query.data(), query.size()) !=
        static_cast<int>(query.size())) {
        return 0xFF;
    }
    if (!ReadExact(response.data(), response.size(), 20)) {
        return 0xFF;
    }

    const uint8_t checksum = static_cast<uint8_t>(
        response[0] + response[1] + response[2] + response[3]);
    if (response[0] != kReadAck || response[1] != kRegKey ||
        response[2] != 1 || response[4] != checksum) {
        return 0xFF;
    }
    return response[3];
}


int N32Audio::ReadMic(int16_t* samples, int count) {
    if (!samples || count <= 0) return 0;
    std::lock_guard<std::mutex> lock(UartMutex());
    PollKeysLocked();

    // 从播放切到录音：N32 是半双工，切换需要一点时间；顺便把播放残留的
    // 应答字节丢掉，否则第一次读麦克风会拿错帧。
    if (!g_recording) {
        uint8_t enable = 1;
        if (!SendCommand(kRegAudioControl, &enable, 1)) {
            uart_flush_input(kUartPort);
            return 0;
        }
        configured_ = false;
        last_write_us_ = 0;
        g_recording = true;
        vTaskDelay(1);
    }

    // v37：一次取满 200 字节（原版驱动 audio_uart.cc 的上限）。以前固定
    // 160，AudioService 一帧要拆成 2~4 次 UART 往返，任何一次超时都会整帧
    // 丢掉——用户感知就是"小智识别不灵敏"。
    const int n = std::min(count, static_cast<int>(kMaxPayloadSize));
    const std::array<uint8_t, 3> query = {kReadPrefix, kRegAudioRead,
                                          static_cast<uint8_t>(n)};
    std::array<uint8_t, kMaxPayloadSize + 4> response = {};

    // 失败统一走这里：半帧残留会让之后每一次读事务整体错位（校验一直失败），
    // 必须清空接收缓冲并重新发 0x10=1 开录音，而不是一路失败下去。
    auto fail = [&]() -> int {
        uart_flush_input(kUartPort);
        g_recording = false;
        last_write_us_ = 0;
        return -1;
    };

    uart_flush_input(kUartPort);
    if (uart_write_bytes(kUartPort, query.data(), query.size()) !=
        static_cast<int>(query.size())) {
        return fail();
    }
    if (!ReadExact(response.data(), 3, 30)) return fail();
    const int received = response[2];
    if (response[0] != kReadAck || response[1] != kRegAudioRead ||
        received <= 0 || received > n) {
        return fail();
    }
    if (!ReadExact(response.data() + 3, received + 1, 40)) return fail();
    if (Checksum(response.data(), received + 3) != response[received + 3]) {
        return fail();
    }
    for (int i = 0; i < received; ++i) {
        samples[i] =
            static_cast<int16_t>((static_cast<int>(response[3 + i]) - 128) * 256);
    }
    return received;
}

}  // namespace radio
