#pragma once
// v53：开机自愈（BootGuard）+ 屏幕诊断
//
// 背景：这块板没有串口日志通路（console 走 UART0，而 UART0 没引到 USB），
// 「同型号有的机器刷完无法开机 / 无限重启」查了三轮都只能靠推断。这里做两件事，
// 都是为了让「别人机器上的那一次失败」变成看得见、拿得到的信息：
//
// 1) 每次开机把最可能有批次差异的硬件事实直接画在屏幕上并停留约 1.2 秒：
//    复位原因、本次是第几次未确认成功的启动、PSRAM 是否可用及大小、Flash 容量、
//    assets 分区、内部堆余量。UI 起不来也照样能看见——用户拍张照就行，
//    不需要串口、不需要联网。
// 2) 启动计数：连续 3 次都没活过 20 秒，下一次直接进「安全模式」——
//    不初始化 LVGL、不起 WiFi、不碰音频与收音机，只把上面那张诊断页停在那里。
//    设备从此不会再无限重启（这是把「变砖」变成「可诊断」的关键），
//    长按任意键 3 秒可清零计数并重启重试；直接断电再上电也会清零。
//
// 计数放在 RTC 不掉电区：panic / 看门狗 / 软件复位都不会丢，只有真正断电才清空，
// 所以上电后要用 magic 校验一次，避免把掉电后的随机值当成计数。

#include <cstdarg>
#include <cstdint>
#include <cstdio>

#include <esp_attr.h>
#include <esp_err.h>
#include <esp_flash.h>
#include <esp_heap_caps.h>
#include <esp_partition.h>
#include <esp_psram.h>
#include <esp_system.h>
#include <esp_timer.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>

#include "st7789.h"

namespace bootguard {

// ---- RTC 掉电保持区 -------------------------------------------------------
static constexpr uint32_t kMagic = 0xB0076001u;
static constexpr uint32_t kSafeAfter = 3;                   // 第 3 次未成功启动 → 安全模式
static constexpr int64_t kHealthyUptimeUs = 20 * 1000 * 1000;  // 活过 20s 才算这次启动成功

RTC_NOINIT_ATTR static uint32_t rtc_magic;
RTC_NOINIT_ATTR static uint32_t rtc_attempts;
RTC_NOINIT_ATTR static uint32_t rtc_last_reason;

inline const char* ReasonName(esp_reset_reason_t r) {
    switch (r) {
        case ESP_RST_POWERON:   return "POWERON";
        case ESP_RST_EXT:       return "EXT_PIN";
        case ESP_RST_SW:        return "SW";
        case ESP_RST_PANIC:     return "PANIC";
        case ESP_RST_INT_WDT:   return "INTWDT";
        case ESP_RST_TASK_WDT:  return "TASKWDT";
        case ESP_RST_WDT:       return "WDT";
        case ESP_RST_DEEPSLEEP: return "SLEEP";
        case ESP_RST_BROWNOUT:  return "BROWNOUT";
        case ESP_RST_SDIO:      return "SDIO";
        default:                return "UNKNOWN";
    }
}

inline constexpr uint16_t Rgb(int r, int g, int b) {
    return static_cast<uint16_t>(((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3));
}

// 本次启动记一次。返回「连续第几次未确认成功」，1 表示干净的一次。
inline uint32_t Begin() {
    const esp_reset_reason_t rr = esp_reset_reason();
    if (rtc_magic != kMagic) {
        rtc_magic = kMagic;
        rtc_attempts = 0;
    }
    // 手动断电重来：给一次干净的机会，避免用户「拔一下再插」也进不了正常模式。
    if (rr == ESP_RST_POWERON || rr == ESP_RST_EXT) {
        rtc_attempts = 0;
    }
    ++rtc_attempts;
    rtc_last_reason = static_cast<uint32_t>(rr);
    return rtc_attempts;
}

inline bool SafeMode(uint32_t attempts) { return attempts >= kSafeAfter; }

// 活过 20 秒才调用：清零计数，代表这台机器这次真的起来了。
inline void MarkHealthy() {
    rtc_magic = kMagic;
    rtc_attempts = 0;
}

inline void Clear() {
    rtc_magic = kMagic;
    rtc_attempts = 0;
}

// ---- 诊断页 ---------------------------------------------------------------
struct Facts {
    const char* reason;
    uint32_t attempts;
    bool psram;
    uint32_t psram_kb;
    uint32_t flash_kb;
    bool assets;
    uint32_t assets_kb;
    uint32_t heap_free_kb;
    uint32_t heap_max_kb;
};

inline Facts Collect(uint32_t attempts) {
    Facts f{};
    f.reason = ReasonName(esp_reset_reason());
    f.attempts = attempts;
    f.psram = esp_psram_is_initialized();
    f.psram_kb = f.psram ? static_cast<uint32_t>(esp_psram_get_size() / 1024) : 0;
    uint32_t flash_bytes = 0;
    if (esp_flash_get_size(nullptr, &flash_bytes) == ESP_OK) {
        f.flash_kb = flash_bytes / 1024;
    }
    const esp_partition_t* assets = esp_partition_find_first(
        ESP_PARTITION_TYPE_ANY, ESP_PARTITION_SUBTYPE_ANY, "assets");
    f.assets = assets != nullptr;
    f.assets_kb = assets ? static_cast<uint32_t>(assets->size / 1024) : 0;
    f.heap_free_kb = heap_caps_get_free_size(MALLOC_CAP_INTERNAL) / 1024;
    f.heap_max_kb = heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL) / 1024;
    return f;
}

// 一行 8x16 ASCII（最多 20 字符，超长截断，绝不溢出屏幕宽度）
inline void Row(radio::Display& lcd, int row, uint16_t fg, uint16_t bg, const char* fmt, ...) {
    char buf[24];
    va_list ap;
    va_start(ap, fmt);
    std::vsnprintf(buf, 21, fmt, ap);
    va_end(ap);
    lcd.DrawText(0, row * 16, buf, fg, bg);
}

struct Palette {
    uint16_t bg = Rgb(14, 20, 32);
    uint16_t fg = Rgb(232, 238, 248);
    uint16_t dim = Rgb(118, 138, 168);
    uint16_t accent = Rgb(143, 227, 240);
    uint16_t bad = Rgb(255, 120, 110);
    uint16_t good = Rgb(140, 226, 160);
};

// 第 2~6 行是硬件事实，正常页与安全页共用
inline void DrawFacts(radio::Display& lcd, const Facts& f, const Palette& p, int first_row) {
    Row(lcd, first_row + 0, p.fg, p.bg, "rst %s #%lu", f.reason, (unsigned long)f.attempts);
    if (f.psram) {
        Row(lcd, first_row + 1, p.good, p.bg, "psram OK %luK", (unsigned long)f.psram_kb);
    } else {
        Row(lcd, first_row + 1, p.bad, p.bg, "psram NONE!");
    }
    Row(lcd, first_row + 2, p.fg, p.bg, "flash %luK", (unsigned long)f.flash_kb);
    if (f.assets) {
        Row(lcd, first_row + 3, p.good, p.bg, "assets OK %luK", (unsigned long)f.assets_kb);
    } else {
        Row(lcd, first_row + 3, p.bad, p.bg, "assets NONE!");
    }
    Row(lcd, first_row + 4, p.fg, p.bg, "heap %luK max%luK", (unsigned long)f.heap_free_kb,
        (unsigned long)f.heap_max_kb);
}

inline void DrawBoot(radio::Display& lcd, const Facts& f) {
    const Palette p;
    lcd.FillRect(0, 0, 160, 128, p.bg);
    Row(lcd, 0, p.accent, p.bg, "ONES BOOT v53");
    DrawFacts(lcd, f, p, 1);
    Row(lcd, 6, p.dim, p.bg, "1.2s then boot");
    Row(lcd, 7, p.dim, p.bg, "key=skip");
    lcd.InvalidateAll();
    lcd.Flush();
}

inline void DrawSafe(radio::Display& lcd, const Facts& f) {
    const Palette p;
    lcd.FillRect(0, 0, 160, 128, p.bg);
    Row(lcd, 0, p.bad, p.bg, "SAFE MODE #%lu", (unsigned long)f.attempts);
    DrawFacts(lcd, f, p, 1);
    Row(lcd, 6, p.dim, p.bg, "ui/audio/net OFF");
    Row(lcd, 7, p.accent, p.bg, "HOLD KEY 3s RETRY");
    lcd.InvalidateAll();
    lcd.Flush();
}

// 开机页停留一会儿，任意按键可跳过
template <typename KeyFn>
inline void Stall(radio::Display& lcd, const Facts& f, KeyFn read_keys, int64_t hold_us) {
    DrawBoot(lcd, f);
    const int64_t t0 = esp_timer_get_time();
    while (esp_timer_get_time() - t0 < hold_us) {
        if (read_keys() != 0) break;
        vTaskDelay(pdMS_TO_TICKS(40));
    }
}

// 安全模式：只在屏幕上待着。长按任意键 3 秒 → 清零计数并重启重试。
template <typename KeyFn>
[[noreturn]] inline void SafeLoop(radio::Display& lcd, const Facts& f, KeyFn read_keys) {
    DrawSafe(lcd, f);
    int64_t held_since = 0;
    for (;;) {
        if (read_keys() != 0) {
            const int64_t now = esp_timer_get_time();
            if (held_since == 0) {
                held_since = now;
            } else if (now - held_since > 3000000) {
                Clear();
                esp_restart();
            }
        } else {
            held_since = 0;
        }
        vTaskDelay(pdMS_TO_TICKS(50));
    }
}

}  // namespace bootguard
