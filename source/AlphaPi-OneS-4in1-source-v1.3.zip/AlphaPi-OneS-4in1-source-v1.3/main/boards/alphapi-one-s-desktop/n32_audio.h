#pragma once

// N32 音频协处理器输出 —— AlphaPi One (ESP32-S3) 独立版
//
// 移植自 xiaozhi-esp32/main/radio/n32_audio.{h,cc}，改动：
//   1. 去掉对 alphapi_s3_audio_codec.h 的依赖（UART 互斥锁在本模块内定义）
//   2. 新增 Init()：本模块自己完成 uart_driver_install（原由板级 codec 负责）
//
// 保留两个已被实机验证的关键做法：
//   1. 16-bit 有符号 -> 8-bit 无符号转换 (sample + 32768) >> 8
//   2. 播放前发送 44 字节 WAV 头，向 N32 声明 24000Hz / 8bit / mono

#include <atomic>
#include <cstddef>
#include <cstdint>

#include "radio_config.h"

namespace radio {

class N32Audio {
public:
    N32Audio() = default;

    // 初始化 UART 并设置初始音量。必须在任何读写之前调用一次。
    bool Init();

    // 进入播放态：停录音、设音量、发 WAV 头。
    // 会在第一次 Write() 时自动调用，也可提前手动调用。
    bool Start();
    void Stop();

    void SetVolume(int volume);
    int volume() const { return volume_; }

    // 写入 16-bit 有符号单声道 PCM，内部转换并分块发给 N32。
    // 返回实际写入的样本数（正常情况下等于 sample_count）。
    int Write(const int16_t* samples, int sample_count);

    // Real audio level for the on-screen meter, 0..100. Write() measures the
    // RMS of the samples AFTER the software volume scaling, so muting really
    // flattens the meter and there is no fake animation. Level() folds in the
    // peak seen since the last call and decays it (fast attack, slow release).
    // Called from the UI task only; peak_ is the only field shared with the
    // playback task.
    int Level();

    // 合成一段短音效（方波/正弦）经 Write() 发给 N32，用于游戏等离线提示。
    // freq 单位 Hz，ms 为时长（内部下限 83ms、上限 500ms），type=0 方波、1 正弦。
    // v28 起改为**异步**：这里只投递参数并给专用任务发通知，立即返回。
    // 以前同步 Write() 会在 UI 任务里等 UART 应答（单次可达 400ms），
    // 游戏里一得分/碰撞就卡住整屏、按键也跟着失灵。
    // v37：音效 PCM 固定为「20ms 静音预热 + 音调 + 250ms 静音尾巴」，
    // 且只在链路真的断开时才重发 WAV 头（见 PlayBeep 注释）。
    void Beep(int freq, int ms, int type = 0);

    // v40：直接播放一段**裸 8-bit unsigned / 24000Hz / 单声道** PCM
    // （assets 分区里 mmap 出来的指针直接可用，不复制、不占 RAM）。
    // 音效改成音频文件的原因见 desktop_sfx.h：时长、包络、音量都能在 PC 上
    // 定死并试听，比在固件里按参数猜要靠谱。
    // tail_ms：音效播完后再补这么多毫秒静音（默认 60），避免流断在波形中间。
    // 与 Beep() 一样是异步投递，立即返回。
    void PlayPcm(const uint8_t* pcm, size_t bytes, int tail_ms = 60);

    // v41：常开静音底流。on=true 时音效任务持续以 24kHz 写静音，把播放会话
    // 一直保持温热；on=false 时停流。
    //
    // 为什么需要它——v41 把四轮实机结果放在一起才看清：
    //   节拍器弱拍 55ms（连续流里）有声、游戏失败音 362ms 有声、
    //   倒计时结束 172ms 有声，而碰撞 95ms、移动 45ms、读秒 42ms 全都一声不响。
    // 同样是 55ms 的点击，在连续流里听得见、单独发就听不见。所以问题不在
    // "流要多长"，而在 **N32 每重开一次播放会话，开头约 100~150ms 的数据
    // 会被吞掉**（它要先把接收缓冲填起来才真正推 DAC，之前进来的直接丢弃）。
    // 短音的内容全落在被吞掉的那一段里，自然一点声音都没有；长音活过窗口，
    // 所以"只有失败音能听到"。
    // 修法有两条：本函数把会话保持温热（吞音窗口只在会话开头发生一次），
    // PlayPcmBlock() 在确实要重开会话时先垫一段静音。
    void KeepAlive(bool on);

    // v40：节拍器连续流。on=true 时由音效任务**一拍接一拍地连续写 PCM**，
    // 中间不重开播放会话，直到 on=false。
    // 为什么不用每拍一次 Beep()：N32 是先攒够一段缓冲才开播，单拍几百毫秒的
    // 流在真正出声之前就结束了（实机表现就是"节拍器没有声音"）；而拍间隔在
    // 240 BPM 时只有 250ms，靠"把单拍流拉长到够长"又会直接把速度拖慢。
    // 连续流还顺带把节拍锁在墙上时钟上：音频时间轴按 esp_timer 生成，
    // UART 偶尔慢几毫秒只会补数据，不会让速度越跑越慢。
    // accent_freq 每小节第一拍、weak_freq 其余拍；tone_ms 每拍音长；
    // period_ms 拍间隔；beats_per_bar 每小节拍数。参数随时可改（下个循环生效）。
    void ClickStream(bool on, int accent_freq, int weak_freq, int tone_ms,
                     int period_ms, int beats_per_bar);

    // 节拍器连续流用的两段音频（8-bit unsigned PCM）。设了就直接用文件取样，
    // 没设就退回上面的合成音。传 nullptr 表示清空。
    void SetClickPcm(const uint8_t* accent, size_t accent_bytes,
                     const uint8_t* weak, size_t weak_bytes);

    // 音效播放任务的主体（只由 Beep() 创建的任务调用，勿手动调用）。
    void BeepWorker();
    // 页面退出时调用：让音效任务播完当前音效后立刻自行结束，不留后台常驻任务。
    // 任务空闲 3 秒也会自动退出，下次 Beep() 才重建。
    void StopBeepTask();

    // v35：音效链路失败次数（0 表示每次 Beep 都真的把 PCM 发给了 N32）。
    int beep_fail_count() const { return beep_fail_.load(); }

    // v48：底层 I/O 计数，供播放汇总日志区分「解码/网络供不上」与
    // 「UART 写流在丢包 / 重开会话」。
    uint32_t ack_failures() const { return ack_failures_.load(); }
    uint32_t stream_gaps() const { return stream_gaps_.load(); }
    uint32_t stream_resets() const { return stream_resets_.load(); }
    uint32_t stream_stalls() const { return stream_stalls_.load(); }

    // 播放链路是否已经握手完成（发过 WAV 头）。进游戏页前用它判断要不要
    // 主动 Start，避免第一次音效因为链路没开而白丢。
    bool ready() const { return configured_; }

    // 读取按键寄存器（0x00）。
    // 返回位掩码：A=0x04 B=0x08 L=0x02 R=0x01，按下为 1（原板实测）。
    // 读取失败返回 0xFF。与音频写入共用同一把 UART 互斥锁，
    // 播放中读键会造成约 1ms 的音频空洞，调用方需自行判断时机。
    uint8_t ReadKeys();
    uint32_t key_polls() const;
    uint8_t cached_keys() const;
    int ReadMic(int16_t* samples, int count);

private:
    // 以下 *Locked 版本假定调用方已持有 UART 互斥锁，内部不再加锁。
    bool StartLocked();
    uint8_t ReadKeysLocked();
    void PollKeysLocked();
    bool SetHardwareVolumeLocked(int volume);

    bool SendCommand(uint8_t reg, const uint8_t* payload, size_t payload_size,
                     uint8_t* accepted = nullptr);
    bool ReadExact(uint8_t* data, size_t length, int timeout_ms);
    static uint8_t Checksum(const uint8_t* data, size_t length);

    static void BeepTaskThunk(void* arg);
    void PlayBeep(uint32_t req);
    // 一段 PCM 文件的实际播放（由音效任务调用）。
    void PlayPcmBlock(const uint8_t* pcm, size_t bytes, int tail_ms);
    // 需要时重握手（链路没开 / 刚从录音切回来 / 流间隙太久）。true 表示可以写。
    bool EnsureStream();
    // 下一次写入是否会重开播放会话——重开就要在音效前面垫静音（见 KeepAlive）。
    bool NeedsFreshSession() const;
    // 往流里写 ms 毫秒静音（补会话开头的吞音窗口 / 音效尾巴）。
    bool WriteSilence(int ms);
    // 常开底流的主体：持续写静音，直到有新的单次音效、停流或页面退出。
    void IdleLoop();
    // 惰性创建音效任务（Beep 与 ClickStream 共用）。返回 nullptr 表示创建失败。
    void* EnsureBeepTask();
    // 连续节拍流的写循环，由 BeepWorker 调用，直到 click_on_ 变假才返回。
    void ClickLoop();

    bool initialized_ = false;
    bool configured_ = false;
    // v37：上一次成功写出 PCM 的时刻（us）。N32 把超过 ~500ms 的流间隙
    // 视为「这一段播放会话结束」，再写数据必须先重发 WAV 头；反之若间隙
    // 很短（连击音效、倒计时三声），重发头会被芯片当成 PCM 播出——这正是
    // 「结束时有声音但像喇叭异响」的来源。
    int64_t last_write_us_ = 0;
    std::atomic<int> volume_{kDefaultVolume};
    std::atomic<int> peak_{0};   // written by Write(), consumed by Level()
    int level_ = 0;              // UI task only
    int level_tick_ = 0;         // playback task only
    std::atomic<bool> beep_busy_{false};
    std::atomic<uint32_t> beep_req_{0};  // 打包 freq/ms/type，由 Beep() 写、任务读
    std::atomic<void*> beep_task_{nullptr};  // 按需创建、空闲/退出即销毁
    std::atomic<bool> beep_stop_{false};
    // v40：节拍器连续流的状态。on 为真时音效任务不再取 beep_req_，
    // 而是一拍接一拍地自己合成 PCM；其余四个参数每轮重读，改速度立即生效。
    std::atomic<bool> click_on_{false};
    std::atomic<int> click_accent_{1568};
    std::atomic<int> click_weak_{1047};
    std::atomic<int> click_tone_ms_{90};
    std::atomic<int> click_period_ms_{500};
    std::atomic<int> click_bar_{4};
    // v40：节拍器用的音频文件（有则优先于合成音）
    std::atomic<const uint8_t*> click_accent_pcm_{nullptr};
    std::atomic<size_t> click_accent_bytes_{0};
    std::atomic<const uint8_t*> click_weak_pcm_{nullptr};
    std::atomic<size_t> click_weak_bytes_{0};
    // v40：待播的 PCM 文件。kind=1 时任务读 src/bytes/tail_ms，否则读 beep_req_。
    std::atomic<int> beep_kind_{0};
    std::atomic<const uint8_t*> pcm_src_{nullptr};
    std::atomic<size_t> pcm_bytes_{0};
    std::atomic<int> pcm_tail_ms_{60};
    // v41：请求序号。覆盖式投递只保留最新一条，任务靠这个序号判断"手里这份
    // 是否已经播过"，不再依赖"通知次数"——常开底流的循环里通知会被合并，
    // 用计数判断会重复播或漏播。
    std::atomic<uint32_t> sfx_seq_{0};
    // 已经播到哪个序号。放在成员里而不是任务局部变量：任务可能是被 Beep()/
    // PlayPcm() 才创建的，那时请求已经投递好了，局部变量初值会把这条请求
    // 当成"已播过"而跳过——第一声音效就丢了。
    std::atomic<uint32_t> sfx_done_{0};
    // v41：常开静音底流（见 KeepAlive）。为真时任务不等待通知，持续写静音。
    std::atomic<bool> keep_on_{false};
    // v35：音效链路失败计数（Start 失败 / PCM 没写出去）。启动器页面在它
    // 不为 0 时显示一行「音效失败 N」，这样"没声音"能第一时间分清是
    // 链路打开了但没触发，还是触发了却发不出去。
    std::atomic<int> beep_fail_{0};
    // v44：连续流诊断。accepted==0 是 N32 接收缓冲满的**正常背压**，不是故障。
    // 之前两版长跑退化都靠猜，这里把背压次数与链路重置次数记下来，并在
    // 节拍器里每 10 秒打一条日志：下次若仍退化，串口日志能直接区分
    // 「缓冲顶满但链路健康」/「通信失败反复重握手」/「写入被调度饿死」。
    std::atomic<uint32_t> stream_stalls_{0};
    std::atomic<uint32_t> stream_resets_{0};
    // v45：UART 事务（写帧 / 等 TX 完成 / 读 ACK）失败次数。这是「连续流
    // 长跑退化」最直接的观测量：节拍器停流时的汇总日志会带上它。
    std::atomic<uint32_t> ack_failures_{0};
    // v48：Write() 因流间隙 >500ms 而重开会话的次数。这一项专门用来验证
    // 「小智播音乐一段时间后卡住」是否由流间隙引起：正常连续播放应当为 0，
    // 若一轮播放里它 >0，说明中间真的断过，重开时必然吞掉开头约 150ms。
    std::atomic<uint32_t> stream_gaps_{0};
    // v34：句柄的「取用 / 摘除」必须互斥，否则 Beep() 可能刚刚读到句柄、
    // 任务就自删了，随后这记 xTaskNotifyGive 打在已释放的 TCB 上。
    void* beep_mux_ = nullptr;  // SemaphoreHandle_t
};

}  // namespace radio
