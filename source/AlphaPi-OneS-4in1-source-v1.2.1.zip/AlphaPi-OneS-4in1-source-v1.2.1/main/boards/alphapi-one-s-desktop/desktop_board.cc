#include "settings.h"
#include "esp_timer.h"
#include "esp_system.h"
#include <unistd.h>
#include <fcntl.h>
#include "desktop_runtime.h"
#include "desktop_assets.h"
#include "desktop_home.h"
#include "desktop_gfx.h"
#include "desktop_ui.h"
#include "desktop_sfx.h"
#include <lvgl.h>
#include "esp_heap_caps.h"
#include "assets.h"
#include "lvgl_font.h"
#include "lvgl_image.h"
#include "gif/lvgl_gif.h"
#include "desktop_face.h"
#include "application.h"
#include "wifi_board.h"
#include "esp_wifi.h"
#include "esp_wifi_default.h"
#include "esp_netif.h"
#include "cJSON.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstring>
#include <ctime>
#include <cstdio>
#include <vector>
std::atomic<int> desktop_page{0};
std::atomic<bool> desktop_network{false};
DesktopRuntime* DesktopRuntime::instance=nullptr;
namespace {
uint16_t Color(int r,int g,int b){return ((r>>3)<<11)|((g>>2)<<5)|(b>>3);}
uint32_t Codepoint(const char*& p){uint8_t c=*p++;if(c<128)return c;if((c&224)==192){uint32_t a=c&31;if(!*p)return '?';return (a<<6)|(*p++&63);}if((c&240)==224){uint32_t a=c&15;if(!p[0]||!p[1]){while(*p)++p;return '?';}a=(a<<6)|(*p++&63);return (a<<6)|(*p++&63);}return '?';}
int Text(radio::Display& lcd,int x,int y,const std::string& s,uint16_t color,int right=158,int bottom=128,bool wrap=false){
 return gfx::Text(lcd,x,y,s,color,right,bottom,wrap);
}
bool Rounded(int x,int y,int w,int h,int r){int dx=x<r?r-x:x>=w-r?x-(w-r-1):0;int dy=y<r?r-y:y>=h-r?y-(h-r-1):0;return dx*dx+dy*dy<=r*r;}
void Focus(radio::Display& lcd,int x,int y){for(int yy=0;yy<34;yy++)for(int xx=0;xx<34;xx++)if(Rounded(xx,yy,34,34,10)&&!(xx>0&&yy>0&&xx<33&&yy<33&&Rounded(xx-1,yy-1,32,32,9)))lcd.DrawPixel(x+xx,y+yy,Color(255,210,122));}
void Background(radio::Display& lcd){lcd.FillRect(0,0,160,128,Color(14,20,32));}
// Per-page key map, column order A/B/C/D. Short presses are redefined inside
// each function; double click jumps to a function and starts it; long D returns.
enum Act{kNone=0,kEnterGame,kEnterVoice,kEnterRadio,kEnterTimer,kHome,kConfig,
 kVolUp,kVolDown,kVoiceChat,kVoiceStop,
 kRadioPlay,kRadioPrev,kRadioNext,kRadioStop,kRadioMute,kRadioList,
 kTimerConfirm,kTimerField,kTimerInc,kTimerDec,kTimerReset,
 kMenuEnter,kMenuPrev,kMenuNext,kMenuBack,
 kMetroConfirm,kMetroField,kMetroInc,kMetroDec,kMetroReset,
 kStopConfirm,kStopLap,kStopReset};
// 行索引不再等于页面号：计时页（page 4）有目录和三个子界面，共用同一页。
//   0 主页 / 1 游戏 / 2 小智 / 3 收音机 / 4 计时目录 / 5 配网
//   6 节拍器 / 7 计时器（秒表）/ 8 定时器（倒计时）
// Key() 里用 RowForPage() 换算。游戏页与配网页的键位在 Key() 里单独分发，
// 这两行是占位。
constexpr Act kShort[9][4]={
 {kEnterGame,kEnterVoice,kEnterRadio,kEnterTimer},
 {kNone,kNone,kNone,kNone},  // 游戏页由 Key() 直接路由到 GameKey，不走这张表
 {kVoiceChat,kVolDown,kVolUp,kNone},
 // 收音机短按复刻独立版：A 播放/暂停、B 上台、C 下台、D 静音/恢复。
 {kRadioPlay,kRadioPrev,kRadioNext,kRadioMute},
 // v47：计时目录。A 进入所选、B/C 上下选、D 回主页。
 {kMenuEnter,kMenuPrev,kMenuNext,kHome},
 {kNone,kNone,kNone,kNone},  // 配网页：A 开关热点、长按 B 清网络、长按 D 返回
 {kMetroConfirm,kMetroField,kMetroDec,kMetroInc},
 // 计时器（秒表）：A 起停、B 计次、C 复位、D 回目录
 {kStopConfirm,kStopLap,kStopReset,kMenuBack},
 {kTimerConfirm,kTimerField,kTimerDec,kTimerInc}
};
constexpr Act kLong[9][4]={
 // v39：主页短按 D 仍是倒计时；v47 起那一页是计时目录。
 {kConfig,kVolDown,kVolUp,kNone},
 {kNone,kNone,kNone,kNone},  // 游戏页长按 D 由 Key() 直接回主页
 {kVoiceStop,kVolDown,kVolUp,kHome},
 // 长按 A 打开电台列表（独立版行为）；长按 D 仍保留回主页——桌面版需要它。
 {kRadioList,kVolDown,kVolUp,kHome},
 {kNone,kNone,kNone,kHome},
 {kNone,kNone,kNone,kNone},
 // 长按 B 一律回目录（以前是"在倒计时和节拍器之间来回切"），长按 D 回主页。
 {kMetroReset,kMenuBack,kVolUp,kHome},
 {kStopReset,kMenuBack,kVolUp,kHome},
 {kTimerReset,kMenuBack,kVolUp,kHome}
};
// v47：页面 + 计时页当前视图 → 键位表行号。计时页一个 page 里装了目录和
// 三个子界面，键位完全不同，所以不能再用"行号 = 页面号"。
int RowForPage(int page,int timer_view){
 if(page!=4)return std::clamp(page,0,5);
 switch(timer_view){
  case 1:return 8;   // 定时器（倒计时）
  case 2:return 6;   // 节拍器
  case 3:return 7;   // 计时器（秒表）
  default:return 4;  // 目录
 }
}
}

// v40：音效改成"assets 分区里的音频文件"。这里做两件事：
//   1) 把资源名解析成 mmap 指针（只做一次，失败最多重试 3 次——资源分区
//      初始化比板级构造函数晚，第一次调用可能还没就绪）；
//   2) 播放：有文件就按文件长度写，没有就退回合成音，保证不会变成静音。
namespace desktop_sfx {
namespace {
const uint8_t* g_ptr[kCount] = {};
size_t g_len[kCount] = {};
int g_tries = 0;
}  // namespace

const uint8_t* Data(Id id, size_t* bytes) {
    if (id < 0 || id >= kCount) {
        if (bytes) *bytes = 0;
        return nullptr;
    }
    if (g_ptr[kMove] == nullptr && g_tries < 3) {
        ++g_tries;
        auto& assets = Assets::GetInstance();
        const Clip* t = Table();
        for (int i = 0; i < kCount; ++i) {
            void* data = nullptr;
            size_t size = 0;
            if (assets.GetAssetData(t[i].name, data, size) && size > 0) {
                g_ptr[i] = static_cast<const uint8_t*>(data);
                g_len[i] = size;
            }
        }
        ESP_LOGI("DesktopSfx", "音效资源 %s（%d 个）",
                 g_ptr[kMove] != nullptr ? "已加载" : "缺失，退回合成音",
                 static_cast<int>(kCount));
    }
    if (bytes) *bytes = g_len[id];
    return g_ptr[id];
}

void Play(Id id, int tail_ms) {
    auto* s = DesktopRuntime::instance;
    if (s == nullptr || s->radio.running()) return;
    size_t bytes = 0;
    const uint8_t* pcm = Data(id, &bytes);
    if (pcm != nullptr && bytes > 0) {
        s->codec.audio.PlayPcm(pcm, bytes, tail_ms);
        return;
    }
    const Clip& c = Table()[id];
    s->codec.audio.Beep(c.freq, c.ms, c.type);
}
}  // namespace desktop_sfx

// 游戏页音效入口（desktop_game.h 里声明）：语义化 id，具体参数在 desktop_sfx.h
void GameSfx(int id) {
    desktop_sfx::Play(static_cast<desktop_sfx::Id>(id));
}

// 游戏页回主页（长按 D / 启动器内 D）。
void GameGotoHome() {
    auto* s = DesktopRuntime::instance;
    if (s) s->GoTo(0);
}

// ---------- v5d: 单任务 LVGL ----------
// One task owns LVGL end to end: key scan -> page state -> widget refresh ->
// lv_timer_handler -> framebuffer flush. The v5c split (a separate 33 ms pump
// task plus a UI task) could leave the screen frozen on the frame that Build()
// produced: the UI task lived at the tail of StartNetwork(), so any hiccup in
// WiFi/HTTPD meant no key scan at all, and the two tasks also raced on the
// display mutex. Keeping everything in one task removes both failure modes.
namespace {
DesktopDisplay* g_lvgl_owner=nullptr;
dui::Ui g_ui;
void LvglFlushCb(lv_display_t* disp,const lv_area_t* area,uint8_t* px_map){
 auto* owner=g_lvgl_owner;
 if(owner&&px_map){
  int w=area->x2-area->x1+1,h=area->y2-area->y1+1;
  owner->lcd.Blit(area->x1,area->y1,w,h,reinterpret_cast<const uint16_t*>(px_map));
  owner->fb_dirty=true;
 }
 lv_display_flush_ready(disp);
}
}
void DesktopDisplay::LvglPump(){
 if(!lvgl_disp_)return;
 int64_t now_us=esp_timer_get_time();
 uint32_t delta=last_tick_us_?static_cast<uint32_t>((now_us-last_tick_us_)/1000):33;
 last_tick_us_=now_us;
 if(delta==0)delta=1;
 // v32：原来把 >100ms 的间隔硬截断成 100ms，长时播放里只要 UI 偶有停顿，
 // LVGL tick 就会不断落后于真实时间，动画与重绘节奏越拖越慢。放宽到 1s。
 if(delta>1000)delta=1000;
 lv_tick_inc(delta);
 lv_timer_handler();
 // v29：整屏 DMA 提交限到 ≥28ms 一次。以前每轮 pump 只要有 invalidate
 // 就整屏提交 40KB，游戏 33ms + 波形 40ms 双重刷新时 SPI 队列会积压，
 // 长时间后 UI 任务被拖住（声音是独立任务，所以看起来"界面死了但还在响"）。
 // 来不及刷就留到下一轮，内容不丢，只是最多延迟一帧。
 int64_t ms=esp_timer_get_time()/1000;
 // v34：兜底整屏 invalidate 从 1 秒放宽到 3 秒。1 秒一次等于每秒钟多做一次
 // 全屏重绘（8 个 16 行带 + 40KB 字节交换 + 整屏 DMA），在音频流同时跑的
 // 时候是最没必要的一份负载。
 if(ms-last_force_redraw_ms_>=3000){
  last_force_redraw_ms_=ms;
  lv_obj_invalidate(lv_screen_active());
 }
 const bool dirty_now=fb_dirty.exchange(false);
 const bool want_flush=dirty_now||ms-last_flush_ms_>=1000;
 if(want_flush&&ms-last_flush_ms_>=28){
  last_flush_ms_=ms;
  if(lcd.Flush()){
   last_ok_flush_ms_=ms;
  }else if(ms-last_recover_ms_>5000&&
           (lcd.flush_fail_count()>=8||ms-last_ok_flush_ms_>2000)){
   // v35：一帧现在是 8 条带，所以失败计数门槛提到 8；同时 5 秒内最多自救
   // 一次，避免 Recover 与重推互相触发把 UI 任务占死。
   last_recover_ms_=ms;
   lcd.Recover();
   last_ok_flush_ms_=ms;
  }
 }else if(want_flush){
  fb_dirty=true;
 }
}
void DesktopDisplay::SetupUI(){
 setup_ui_called_=true;
 if(lvgl_disp_)return;
 g_lvgl_owner=this;
 lv_init();
 // v38：PSRAM 拿不到时退回内部 RAM。返回前不再一声不响地留在
 // "lvgl_disp_ 为空"状态——那时 Render() 会走自绘兜底，屏幕看起来像开不了机。
 auto* partial=static_cast<uint16_t*>(heap_caps_malloc(160*16*sizeof(uint16_t),MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT));
 if(!partial){
  partial=static_cast<uint16_t*>(heap_caps_malloc(160*16*sizeof(uint16_t),MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT));
  if(!partial){ESP_LOGE("desk_ui","LVGL 绘制缓冲分配失败（PSRAM/内部 RAM 都不可用）");return;}
  ESP_LOGW("desk_ui","LVGL 绘制缓冲改用内部 RAM（PSRAM 不可用）");
 }
 lvgl_disp_=lv_display_create(160,128);
 if(!lvgl_disp_)return;
 lv_display_set_color_format(lvgl_disp_,LV_COLOR_FORMAT_RGB565);
 lv_display_set_buffers(lvgl_disp_,partial,nullptr,160*16*sizeof(uint16_t),LV_DISPLAY_RENDER_MODE_PARTIAL);
 lv_display_set_flush_cb(lvgl_disp_,LvglFlushCb);
 if(!g_ui.Build(DesktopRuntime::instance))return;
 last_tick_us_=esp_timer_get_time();
}

DesktopRuntime::DesktopRuntime(){instance=this;
 // v36：收音机与语音/音效必须共用同一个 N32Audio（物理上只有一个 N32）。
 radio.AttachAudio(&codec.audio);
 dirty=true;boot_reset=static_cast<int>(esp_reset_reason());countdown.Load();metro.Load();LoadRadioCustom();display.SetupUI();StartUiTask();}
void DesktopRuntime::StartUiTask(){
 // Started from the board constructor on purpose: key input and the clock must
 // come up even if the later WiFi / HTTPD boot sequence bails out. Idempotent
 // so StartNetwork() can call it again without spawning a second task.
 if(ui_started_.exchange(true))return;
 auto entry=[](void* p){static_cast<DesktopRuntime*>(p)->UiTask();};
 // v31：v30 把 UI 提到 8 后音频开始卡顿（高优先级 UI 抢占 play/decode），
 // 已回退到 5。UI 饿死的根治改在音频侧：play/decode 任务每处理一批数据
 // 显式 vTaskDelay(1) 让出 CPU，不再靠优先级硬压。
 constexpr UBaseType_t kUiPriority = 5;
 if(xTaskCreate(entry,"desk_ui",8192,this,kUiPriority,nullptr)==pdPASS)return;
 if(xTaskCreate(entry,"desk_ui",4096,this,kUiPriority,nullptr)==pdPASS)return;
 ui_started_=false;
 printf("DESKTOP_UI task create failed\n");
}
void DesktopActivationCode(const std::string& code){auto s=DesktopRuntime::instance;if(!s)return;std::lock_guard<std::recursive_mutex>l(s->display.mutex);s->display.activation=code;s->dirty=true;}
void DesktopRuntime::CloseAP(){
 // Baseline (v6) shutdown: drop the radio back to station-only and let the
 // driver take care of the rest. No netif destroy, no default-netif handover,
 // no manual reconnect - with APSTA the station link was never torn down, so
 // set_mode(STA) is enough and the saved network resumes on its own.
 auto mode=esp_wifi_set_mode(WIFI_MODE_STA);
 if(mode!=ESP_OK)printf("DESKTOP_AP close error=%s\n",esp_err_to_name(mode));
 ap_enabled=false;ap_live=false;ap_started_at=0;web_error=0;ap_advise=false;ap_err=0;ap_dhcp=false;dirty=true;
 ap_ip=0;ap_chan=0;ap_dhcp_err=0;ap_netif_up=false;ap_lease=false;
}
void DesktopRuntime::Render(){
 if(display.lvgl_disp_){
  std::lock_guard<std::recursive_mutex> lock(display.mutex);
  g_ui.Refresh(desktop_page.load(),esp_timer_get_time()/1000);
  return;
 }
 auto& lcd=display.lcd;std::lock_guard<std::recursive_mutex> lock(display.mutex);Background(lcd);
 const auto white=Color(245,247,255),muted=Color(113,134,160),accent=Color(143,227,240),warm=Color(255,210,122);
 char buffer[100];int page=desktop_page.load();int64_t now_ms=esp_timer_get_time()/1000;
 if(page==0){
  time_t now=time(nullptr);tm t={};localtime_r(&now,&t);bool valid=t.tm_year+1900>=2024;
  std::string place,condition;bool available;double degrees;
  {std::lock_guard<std::mutex>s(state_mutex);place=city;condition=description;available=have_weather;degrees=temperature;}
  wifi_ap_record_t ap={};int signal=0;
  if(esp_wifi_sta_get_ap_info(&ap)==ESP_OK)signal=ap.rssi>=-55?4:ap.rssi>=-67?3:ap.rssi>=-78?2:1;
  desktop_home::Draw(lcd,t,valid,place,condition,available,degrees,signal);
  if(countdown.finished||countdown.running){
   int left=countdown.Remaining(now_ms)/1000;
   if(countdown.finished)snprintf(buffer,sizeof(buffer),"计时结束");
   else snprintf(buffer,sizeof(buffer),"计时 %02d:%02d",left/60,left%60);
   desktop_home::Text(lcd,9,70,buffer,countdown.finished?warm:accent,159);
  }
  const int xpos[]={6,44,82,120};
  for(int i=0;i<4;i++){
   if(selected==i){
    gfx::RoundRect(lcd,xpos[i]-3,81,38,38,10.0f,warm);
    gfx::RoundRect(lcd,xpos[i]-1,83,34,34,9.0f,gfx::kBg);
   }
   for(int y=0;y<32;y++)for(int x=0;x<32;x++)lcd.DrawPixel(xpos[i]+x,84+y,desk_icons[i][y*32+x]);
  }
  if(ap_enabled)desktop_home::Text(lcd,9,70,"配网热点已开启",warm,159);
 }else if(page==1){
  desktop_home::Text(lcd,9,6,"游戏",accent,159);
  snprintf(buffer,sizeof(buffer),"%02d / %02d",radio.station_index()+1,radio.station_count());
  desktop_home::Text(lcd,112,6,buffer,muted,159);
  Text(lcd,12,30,radio.station_name(),white,149,64,true);
  const char* st="等待播放";switch(radio.state()){
   case radio::PlayerState::kConnecting:st="正在连接";break;
   case radio::PlayerState::kBuffering:st="正在缓冲";break;
   case radio::PlayerState::kPlaying:st="正在播放";break;
   case radio::PlayerState::kPaused:st="已暂停";break;
   case radio::PlayerState::kReconnecting:st="正在重连";break;
   case radio::PlayerState::kError:st="暂不可用";break;default:break;}
  Text(lcd,12,78,st,warm,149,92);
  for(int i=0;i<12;i++){
   int h=4+((i*7+(int)(now_ms/120))%17);
   gfx::RoundRect(lcd,14+i*11,112-h,7,h,2.0f,i%3==0?warm:Color(42,80,110));
  }
 }else if(page==2){
  const auto ink=Color(147,170,198),hint=Color(113,134,160),bg=Color(14,20,32);
  lcd.FillRect(0,0,160,22,Color(22,35,58));
  Text(lcd,8,4,display.status,ink,118,20,false);
  time_t t=time(nullptr);tm lt={};localtime_r(&t,&lt);
  snprintf(buffer,sizeof(buffer),"%02d:%02d",lt.tm_hour,lt.tm_min);
  Text(lcd,124,4,buffer,warm,158,20,false);
  if(!display.activation.empty()){
   Text(lcd,9,30,"设备验证码",accent);
   int x=29;for(char c:display.activation){char one[2]={c,0};x=gfx::Digits(lcd,x,46,one,accent,0.6f,2);}
   Text(lcd,9,86,"请在小智网页绑定",hint);
  }else{
   desktop_face::Draw(lcd,display.emotion,Application::GetInstance().GetDeviceState(),now_ms);
   Text(lcd,8,80,display.chat,white,153,122,true);
  }
 }else if(page==3){
  desktop_home::Text(lcd,9,6,"网络收音机",white,159);
  snprintf(buffer,sizeof(buffer),"%02d / %02d",radio.station_index()+1,radio.station_count());
  desktop_home::Text(lcd,112,6,buffer,muted,159);
  Text(lcd,12,30,radio.station_name(),accent,149,64,true);
  const char* st="等待播放";switch(radio.state()){
   case radio::PlayerState::kConnecting:st="正在连接";break;
   case radio::PlayerState::kBuffering:st="正在缓冲";break;
   case radio::PlayerState::kPlaying:st="正在播放";break;
   case radio::PlayerState::kPaused:st="已暂停";break;
   case radio::PlayerState::kReconnecting:st="正在重连";break;
   case radio::PlayerState::kError:st="电台暂不可用";break;default:break;}
  Text(lcd,12,78,st,warm,149,92);
  for(int i=0;i<12;i++){
   int h=4+((i*5+(int)(now_ms/140))%17);
   gfx::RoundRect(lcd,14+i*11,112-h,7,h,2.0f,i%4==0?accent:Color(42,80,110));
  }
 }else if(page==4){
  // 自绘兜底路径（LVGL 没起来时才会走到）：目录/秒表没有对应的点阵绘制，
  // 这里只保留节拍器与倒计时，屏幕至少还能用。
  if(timer_view==2)metro.Draw(lcd,now_ms*1000,(now_ms/400)%2==0);
  else countdown.Draw(lcd,now_ms,(now_ms/400)%2==0);
 }
 if(now_ms < volume_overlay_until){
  lcd.FillRect(34,3,92,29,Color(27,39,64));
  snprintf(buffer,sizeof(buffer),"音量 %d%%",codec.audio.volume());Text(lcd,50,5,buffer,white);
  lcd.FillRect(43,23,74,3,Color(42,60,90));lcd.FillRect(43,23,74*codec.audio.volume()/100,3,warm);
 }
 lcd.Flush();
}
void DesktopRuntime::ToggleMute(){
 if(mute_saved_volume_>=0){
  const int back=mute_saved_volume_;
  mute_saved_volume_=-1;
  SetVolume(back);
  return;
 }
 const int current=codec.audio.volume();
 if(current==0){SetVolume(85);return;}  // already silent: give it a usable level
 mute_saved_volume_=current;
 SetVolume(0);
}
void DesktopRuntime::SetVolume(int value){
 value=std::clamp(value,0,100);
 if(value!=codec.audio.volume()){
  codec.SetOutputVolume(value);radio.SetVolume(value);
  volume_save_at=esp_timer_get_time()/1000+1500;
 }
 volume_overlay_until=esp_timer_get_time()/1000+1800;dirty=true;
}
void DesktopRuntime::GoTo(int page,bool quick){
 int current=desktop_page.load();
 if(current==page&&!quick){dirty=true;return;}
 // 退出功能页即收摊：清缓存、停后台任务，不允许把半局游戏 / 音频流留在后台
 // v34：顺序改成「先停流、再动界面」。原来先 OnLeaveRadio()（会 invalidate
 // 波形画布）再 radio.Stop()，退出瞬间仍有 PCM 在往 N32 写、UART 同时收到
 // 停止命令，长按 D 回主页就是死在这条路径上。先停音频再碰 UI 更干净。
 if(current==3)radio.Stop();
 if(current==1||current==3){radio_started=false;codec.audio.KeepAlive(false);codec.audio.StopBeepTask();}
 // v41：计时页也会跑常开底流（读秒声要有声），离开时同样先收流。
 if(current==4){codec.audio.KeepAlive(false);codec.audio.StopBeepTask();}
 // 节拍器离开即停拍：这一页没有"后台继续走"的意义，却会一直占着音效通道。
 if(current==4)metro.Stop();
 if(current==1)g_ui.GameLeave();
 if(current==3)g_ui.OnLeaveRadio();
 if(current==2){Application::GetInstance().ExitDesktopVoice();voice_cleanup_pending=true;}
 radio_pending=false;voice_pending=false;radio_ready_at=0;voice_ready_at=0;
 auto_chat=false;auto_play=false;auto_chat_at=0;
 if(page==0){
  // v35：回主页不再重建电台列表。以前这里调 UseRadioList()，会在播放任务
  // 还没完全退出的瞬间换 stations_ / station_count_，任务正拿旧索引读新表
  // 就是越界——长按 D 回主页死机很可能就出在这条路径上。主页不需要列表，
  // 停流在上面的 current==3 分支已经做过了。
  radio_started=false;
  desktop_page=0;
  key_taps_reset_.store(true);   // 清掉所有待判定的单击/长按，防止跨页误触发
  key_guard_until_ms_.store(esp_timer_get_time()/1000+120);
  dirty=true;return;
 }
 if(page<=4)selected=std::clamp(page-1,0,3);
 desktop_page=page;display.SetStatus("");
 if(page==2){
  UseRadioList();voice_pending=true;voice_ready_at=0;auto_chat=quick;
  display.SetStatus("正在切换小智");
 }else if(page==3){
  // v35：进收音机就自动开播，不用再按 A。用户要求"进去就开始播"。
  UseRadioList();radio_pending=true;radio_ready_at=0;auto_play=true;
 }else if(page==4){
  UseRadioList();
  // v47：进的是「计时目录」。双击 A 从主页直接跳进定时器并起跑（老行为），
  // 单击则停在目录里让人选：定时器 / 节拍器 / 计时器。
  timer_view=quick?1:0;
  if(quick){timer_menu_sel=0;countdown.Start(esp_timer_get_time()/1000);}
  metro.Stop();
  timer_hint_until=esp_timer_get_time()/1000+8000;
 }else if(page==1){
  // v35：进游戏页先确认音量不是 0。收音机静音（D 短按）会持久化成 0，
  // 到了一个只有按键音效的游戏页就是"完全没声音"，很容易被当成故障。
  if(codec.audio.volume()<=0)SetVolume(45);
  // v36：这里**不再**预发 WAV 头。以前进游戏页先 Start() 一次，结果
  // configured_ 被置成 true 却没有任何 PCM 跟上去，之后每条音效都以为
  // "链路已就绪"而跳过握手 —— 芯片其实早已不在播放态，全部静音吞掉。
  // 现在由 PlayBeep 每次发声前自己完整握手，这里无需预开。
 }
 // page==1 是游戏页，不启动任何音频流；进游戏页时上面的 current==1 分支已停掉收音机。
 dirty=true;
}
// 复刻自 v22：进首页/语音/收音机/计时页时先复位电台列表为默认台并停流。
// （原实现里的 music_list_active 已随音乐功能删除，此处不保留。）
void DesktopRuntime::UseRadioList(){RebuildRadioList();radio.Stop();radio_started=false;}

// ---------------------------------------------------------------------------
// v35：自定义电台支持多条。存储格式是一段多行文本，每行 `名称|地址`。
// 解析规则只写一份，NVS 加载和网页提交都走它。
// ---------------------------------------------------------------------------
static void ParseStationText(const std::string& text,
                             std::vector<std::string>& urls,
                             std::vector<std::string>& names){
 urls.clear();names.clear();
 size_t pos=0;
 while(pos<=text.size()&&
       static_cast<int>(urls.size())<DesktopRuntime::kMaxRadioExtras){
  const size_t nl=text.find('\n',pos);
  std::string line=text.substr(pos,(nl==std::string::npos)?std::string::npos:(nl-pos));
  pos=(nl==std::string::npos)?(text.size()+1):(nl+1);
  while(!line.empty()&&(line.back()=='\r'||line.back()==' '||line.back()=='\t'))line.pop_back();
  size_t b=0;while(b<line.size()&&(line[b]==' '||line[b]=='\t'))++b;
  if(b)line.erase(0,b);
  if(line.empty())continue;
  std::string name,url;
  const size_t bar=line.find('|');
  if(bar==std::string::npos){
   url=line;
  }else{
   name=line.substr(0,bar);url=line.substr(bar+1);
   while(!name.empty()&&(name.back()==' '||name.back()=='\t'))name.pop_back();
   while(!url.empty()&&(url.front()==' '||url.front()=='\t'))url.erase(0,1);
  }
  // 解码器只编了 MP3，直链之外的东西放不出来，这里先挡掉非 http(s)。
  if(url.compare(0,7,"http://")!=0&&url.compare(0,8,"https://")!=0)continue;
  if(url.size()>radio::kStationUrlBytes-1)url.resize(radio::kStationUrlBytes-1);
  if(name.size()>radio::kStationNameBytes-1)name.resize(radio::kStationNameBytes-1);
  urls.push_back(url);names.push_back(name);
 }
}
void DesktopRuntime::LoadRadioCustom(){
 Settings s("desk_radio",true);
 ParseStationText(s.GetString("extras",""),radio_extra_urls,radio_extra_names);
 if(radio_extra_urls.empty()){
  // v34 只存过一条（custom_url / custom_name），这里顺手迁移成列表。
  const std::string u=s.GetString("custom_url","");
  if(!u.empty()){
   const std::string n=s.GetString("custom_name","");
   ParseStationText(n+"|"+u,radio_extra_urls,radio_extra_names);
  }
 }
 radio_custom_url=radio_extra_urls.empty()?"":radio_extra_urls[0];
 radio_custom_name=radio_extra_names.empty()?"":radio_extra_names[0];
 RebuildRadioList();
}
void DesktopRuntime::RebuildRadioList(){
 const int builtins=radio::kDefaultStationCount;
 const int extras=static_cast<int>(radio_extra_urls.size());
 if(radio_pool==nullptr){
  // 一次按上限分配，之后增减电台都复用这块内存，不再 malloc/free。
  const size_t bytes=static_cast<size_t>(builtins+kMaxRadioExtras)*sizeof(radio::Station);
  radio_pool=static_cast<radio::Station*>(
      heap_caps_malloc(bytes,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT));
  if(radio_pool==nullptr)
   radio_pool=static_cast<radio::Station*>(heap_caps_malloc(bytes,MALLOC_CAP_DEFAULT));
  if(radio_pool==nullptr){  // PSRAM 也没了：退回只用内置表
   radio.SetStationList(radio::kDefaultStations,builtins);
   radio_pool_count=builtins;
   return;
  }
 }
 int n=0;
 for(int i=0;i<extras;++i){
  auto& st=radio_pool[n++];
  std::memset(&st,0,sizeof(st));
  std::snprintf(st.name,sizeof(st.name),"%s",
                radio_extra_names[i].empty()?"我的电台":radio_extra_names[i].c_str());
  std::snprintf(st.url,sizeof(st.url),"%s",radio_extra_urls[i].c_str());
 }
 for(int i=0;i<builtins;++i)radio_pool[n++]=radio::kDefaultStations[i];
 radio_pool_count=n;
 radio.SetStationList(radio_pool,n);
}
void DesktopRuntime::SetRadioExtras(const std::string& text){
 std::vector<std::string> urls,names;
 ParseStationText(text,urls,names);
 radio_extra_urls=urls;radio_extra_names=names;
 radio_custom_url=urls.empty()?"":urls[0];
 radio_custom_name=names.empty()?"":names[0];
 std::string dump;
 for(size_t i=0;i<urls.size();++i){
  if(i)dump+='\n';
  dump+=names[i];dump+='|';dump+=urls[i];
 }
 Settings s("desk_radio",true);
 if(dump.empty()){
  s.EraseKey("extras");s.EraseKey("custom_url");s.EraseKey("custom_name");
 }else{
  s.SetString("extras",dump);
  s.EraseKey("custom_url");s.EraseKey("custom_name");
 }
 // 换列表必须先把流停干净：三个播放任务还在跑的时候换 stations_ 指针，
 // 它们下一秒就可能按旧索引读新表。停完给一点时间让它们看到 running_ 变化
 // 自行退出（这里跑在 httpd 任务上，多等 120ms 没有副作用）。
 radio.Stop();
 radio_started=false;
 vTaskDelay(pdMS_TO_TICKS(120));
 RebuildRadioList();
 dirty=true;
}
void DesktopRuntime::SetRadioCustomUrl(const std::string& url,const std::string& name){
 // v34 的单条接口保留：网页的"只设一个台"按钮还走它。
 if(url.empty()){SetRadioExtras("");return;}
 SetRadioExtras((name.empty()?"我的电台":name)+"|"+url);
}
std::string DesktopRuntime::RadioStationUrl() const{
 const char* u=radio.station_url();
 return u?std::string(u):std::string();
}
void DesktopRuntime::Apply(int action){
 int64_t now=esp_timer_get_time()/1000;
 switch(action){
  case kEnterGame:if(desktop_page.load()==0)GoTo(1);break;
  case kEnterVoice:if(desktop_page.load()==0)GoTo(2);break;
  case kEnterRadio:if(desktop_page.load()==0)GoTo(3);break;
  case kEnterTimer:if(desktop_page.load()==0)GoTo(4);break;
  case kHome:GoTo(0);break;
  case kConfig:GoTo(5);OpenAPAsync(true);break;
  case kRadioStop:radio.Stop();radio_started=false;break;
  case kVoiceChat:if(!voice_pending)Application::GetInstance().ToggleChatState();break;
  case kVoiceStop:GoTo(0);break;
  case kRadioPlay:if(!radio_pending)radio.TogglePlayPause();break;
  case kRadioPrev:if(!radio_pending)radio.PreviousStation();break;
  case kRadioNext:if(!radio_pending)radio.NextStation();break;
  case kRadioMute:ToggleMute();break;
  case kRadioList:g_ui.RadioListToggle(true);break;
  case kTimerConfirm:countdown.Toggle(now);break;
  case kTimerField:countdown.NextField();break;
  case kTimerInc:countdown.Step(1,now);break;
  case kTimerDec:countdown.Step(-1,now);break;
  case kTimerReset:countdown.Reset();break;
  // v47：计时目录。以前这里是「长按 B 在倒计时/节拍器之间来回切」，两个子
  // 界面都藏在同一页里；现在是真正的目录，长按 B 一律回目录。
  case kMenuEnter:
   if(desktop_page.load()==4&&timer_view==0){
    timer_view=std::clamp(timer_menu_sel,0,2)+1;
    metro.Stop();
    if(timer_view==2&&codec.audio.volume()<=0)SetVolume(45);
    timer_hint_until=now+5000;
   }
   break;
  case kMenuPrev:
   if(desktop_page.load()==4&&timer_view==0)timer_menu_sel=(timer_menu_sel+2)%3;
   break;
  case kMenuNext:
   if(desktop_page.load()==4&&timer_view==0)timer_menu_sel=(timer_menu_sel+1)%3;
   break;
  case kMenuBack:
   if(desktop_page.load()==4&&timer_view!=0){
    metro.Stop();
    timer_view=0;
    timer_hint_until=now+6000;
   }
   break;
  // 计时器（秒表）：状态全在时间戳里，切页/回目录都不会走慢。
  case kStopConfirm:stopwatch.Toggle(now);break;
  case kStopLap:stopwatch.Lap(now);break;
  case kStopReset:stopwatch.Reset();break;
  case kMetroConfirm:metro.Toggle(now*1000);break;
  case kMetroField:metro.NextField();break;
  case kMetroInc:metro.Step(1);break;
  case kMetroDec:metro.Step(-1);break;
  case kMetroReset:metro.Reset();break;
  case kVolUp:SetVolume(codec.audio.volume()+5);break;
  case kVolDown:SetVolume(codec.audio.volume()-5);break;
  default:break;
 }
 dirty=true;
}
void DesktopRuntime::Key(uint8_t key,int gesture){
 if(esp_timer_get_time()/1000 < key_guard_until_ms_.load())return;  // 切页残留事件
 int idx=(key&4)?0:(key&8)?1:(key&2)?2:3;
 int page=desktop_page.load();
 if(page==5){
  // 配网页：短按 A 开关热点，长按 D 返回。退出不再顺手关热点——开关是独立的，
  // 否则手机刚连上就被踢下线，网页也跟着断了。
  if(gesture>=2&&idx==3){GoTo(0);return;}
  // 长按 B = 抹掉设备里存的那个 Wi-Fi（NVS + 驱动里那份都清）。旧网络连不上时
  // STA 会不停地重连，单天线被它反复拽走，手机端就永远拿不到地址。
  if(gesture>=2&&idx==1){ResetSavedWifi();return;}
  // 这里只翻"请求位"，不等驱动。以前这里有个 !ap_busy 门槛：只要有一次热点
  // 拉起卡住/失败，ap_busy 就再也不回 false，短按 A 就彻底没反应了。
  if(idx==0&&(gesture==0||gesture==1))OpenAPAsync(!ap_desired.load());
  return;
 }
 if(page==1){
  // 游戏页独占 4 键：单击/长按两档原样交给 GameKey，键位由各游戏自己定义
  // （启动器里 D 单击/长按回主页也在 GameKey 内处理，这里不再拦）。
  g_ui.RouteGame(idx,gesture>=2?2:0);
  return;
 }
 if(page==3&&g_ui.RadioListOpen()){
  // 电台列表内部键位（复刻独立版）：A 播放选中台并返回、B/C 上下移动、
  // D 返回。列表打开时双击不再跳页，长按只认 D 返回。
  if(gesture>=2){
   if(idx==3){g_ui.RadioListToggle(false);dirty=true;}
   return;
  }
  if(gesture==1)return;
  switch(idx){
   case 0:
    if(!radio_pending){
     radio.SelectStation(g_ui.RadioListSelection());
     if(radio.paused())radio.Play();
    }
    g_ui.RadioListToggle(false);
    break;
   case 1:g_ui.RadioListMove(-1);break;
   case 2:g_ui.RadioListMove(1);break;
   default:g_ui.RadioListToggle(false);break;
  }
  dirty=true;
  return;
 }
 // v47：计时页一个 page 装了目录 + 三个子界面，键位行号由 RowForPage 换算。
 const int row=RowForPage(page,timer_view);
 if(countdown.finished)countdown.Acknowledge();
 if(gesture==1){if(page==0)GoTo(idx+1,true);return;}  // 主页功能键只在主页生效
 if(gesture==2||gesture==3){Apply(kLong[row][idx]);return;}
 Apply(kShort[row][idx]);
}
void DesktopRuntime::UiTask(){
 struct Track{bool down=false;int64_t down_ms=0;bool long_fired=false;int64_t repeat_ms=0;bool tap_pending=false;int64_t tap_ms=0;};
 constexpr int64_t kLongMs=650,kRepeatMs=200,kDoubleMs=280;
 // 游戏页长按阈值更重一些：方向键按住是常事，0.9 秒才算长按，避免误退出。
 constexpr int64_t kGameLongMs=900;
 constexpr uint8_t masks[4]={4,8,2,1};
 uint8_t stable=0,candidate=0;int matches=0;
 int64_t previous_loop=0,last_render=0;
 Track track[4];
 // The task is created from the board constructor, so give the rest of
 // Application::Initialize() a moment before the first frame is drawn.
 vTaskDelay(pdMS_TO_TICKS(250));
 for(;;){
  if(key_taps_reset_.exchange(false)){
   for(int i=0;i<4;i++){track[i].tap_pending=false;track[i].long_fired=true;}
  }
  int64_t loop_start=esp_timer_get_time();
  if(previous_loop){auto gap=static_cast<uint32_t>(loop_start-previous_loop);ui_gap_us=gap;ui_max_gap_us=std::max(ui_max_gap_us.load(),gap);}
  previous_loop=loop_start;ui_loops++;
  auto raw=codec.audio.ReadKeys();
  auto pressed=(uint8_t)(raw==0xff?stable:(raw&15));
  if(pressed==candidate)matches++;else{candidate=pressed;matches=0;}
  int64_t now=esp_timer_get_time()/1000;
  // v34：流缓冲改成一次性分配、长期复用（ReleaseStoppedBuffers 已是空实现），
  // 这里不再每轮判断释放，避免「任务还在收尾就被删缓冲」的窗口。
  if(voice_cleanup_pending&&Application::GetInstance().DesktopVoiceStopped()){
   codec.audio.Stop();voice_cleanup_pending=false;
  }
  countdown.Tick(now);
  // v41：**常开静音底流**。N32 每重开一次播放会话会吞掉开头约 150ms，短音
  // 全部落在被吞的那一段里——这就是"只有失败音能听到、碰撞/读秒/移动一声都
  // 没有"的原因（v37/v39 一直在补时长，方向错了）。游戏页与跑表/节拍器期间
  // 让会话一直温热，音效插进正在跑的流里，就没有吞音窗口了。
  // 只在需要的页面开着：小智页 / 收音机页都不能有底流（半双工）。
  {
   const int kp=desktop_page.load();
   codec.audio.KeepAlive(
       kp==1||(kp==4&&(timer_view==2||countdown.running||countdown.finished)));
  }
  // v39：读秒声。跑表时每秒一声，最后 3 秒抬高音高。小智页 / 收音机页以及
  // 任何正在收流的时刻一律跳过——半双工下抢先写音效会把那一轮识别打断。
  if(countdown.ConsumeTick()&&codec.audio.volume()>0){
   const int tick_page=desktop_page.load();
   const bool tick_busy=tick_page==2||tick_page==3||radio.running()||
                        !Application::GetInstance().DesktopVoiceStopped()||
                        // 节拍器的连续流正占着音效通道，读秒声插进去只会被丢掉
                        (tick_page==4&&timer_view==2);
   if(!tick_busy){
    const int left=countdown.Remaining(now)/1000;
    // 读秒声：普通秒 40ms、最后 3 秒高音 50ms，各自是 assets 里的一段样本
    desktop_sfx::Play(left<=3?desktop_sfx::kTickHi:desktop_sfx::kTick);
   }
  }
  // v40：节拍器的声音改成"连续流"。以前每拍投递一次音效（type=2），实机上一声
  // 都没有——N32 要先攒够一段缓冲才开播，单拍几百毫秒的流在开播前就结束了；
  // 而 240BPM 的拍间隔只有 250ms，靠"把单拍流拉长到够响"又会直接把速度拖慢。
  // 现在由音效任务一拍接一拍连续写 PCM，音频时间轴锁在 esp_timer 上，
  // 速度精确，也不再依赖"单段流要多长"。
  {
   const int mpage=desktop_page.load();
   const bool on_metro_page=(mpage==4&&timer_view==2);
   if(on_metro_page)metro.Tick(esp_timer_get_time());  // 只驱动屏幕上的拍点
   else if(metro.running)metro.Stop();
   // 拍点的音色取自 assets 里的两段样本（重拍高八度）；资源缺失时 N32Audio
   // 会退回内部合成，所以这四行只是"有文件就用文件"。
   size_t ab=0,wb=0;
   const uint8_t* ap=desktop_sfx::Data(desktop_sfx::kClickHi,&ab);
   const uint8_t* wp=desktop_sfx::Data(desktop_sfx::kClick,&wb);
   codec.audio.SetClickPcm(ap,ab,wp,wb);
   codec.audio.ClickStream(on_metro_page&&metro.running,1568,1047,80,
                           metro.PeriodMs(),metro.beats);
  }
  if(countdown.beep_left>0&&now>=countdown.beep_next_ms){
   countdown.beep_left--;countdown.beep_next_ms=now+280;
   // v37：小智页 / 收音机页一律不响——那两路可能正在录音或收流，半双工下
   // 抢先写音效会把整轮识别打断（用户会感觉"小智时好时坏"）。间隔从 220ms
   // 放到 280ms，让三声提示音之间有可分辨的空隙（音效尾巴还有 150ms 静音）。
   const int pnow=desktop_page.load();
   bool busy=pnow==2||pnow==3||radio.running()||
             !Application::GetInstance().DesktopVoiceStopped();
   if(!busy){
    // v40：结束音也是 assets 里的样本（880Hz 170ms，带衰减尾巴）。
    desktop_sfx::Play(desktop_sfx::kAlarm);
   }
  }
  if(auto_chat_at&&now>=auto_chat_at){auto_chat_at=0;Application::GetInstance().ToggleChatState();}
  int page=desktop_page.load();
  const bool game_page=(page==1);
  // v37：切页等待加硬超时。原来这里无条件等「收音机三任务退干净 /
  // 语音服务停稳」，只要有一路卡在 UART 写重试（音频链路异常时可达数秒），
  // 页面就永远停在"正在切换小智/正在连接"——用户看到的就是"卡死"。
  // 4 秒还没等到就强制往下走，宁可让旧链路被后面的 Stop() 收掉。
  static int64_t radio_wait_ms=0,voice_wait_ms=0;
  if(radio_pending&&(page==3)){
   if(!radio_wait_ms)radio_wait_ms=now;
   const bool ready=Application::GetInstance().DesktopVoiceStopped()||
                    now-radio_wait_ms>4000;
   if(ready){
    radio_wait_ms=0;
    if(!radio_ready_at)radio_ready_at=now+100;
    if(now>=radio_ready_at){codec.audio.Stop();codec.EnableInput(false);codec.EnableOutput(false);radio_started=radio.Start();if(radio_started&&auto_play)radio.Play();radio_pending=false;auto_play=false;dirty=true;}
   }else radio_ready_at=0;
  }else radio_wait_ms=0;
  if(voice_pending&&page==2){
   if(!voice_wait_ms)voice_wait_ms=now;
   const bool ready=(radio.active_tasks()==0&&Application::GetInstance().DesktopVoiceStopped())||
                    now-voice_wait_ms>4000;
   if(ready){
    voice_wait_ms=0;
    if(!voice_ready_at)voice_ready_at=now+100;
    if(now>=voice_ready_at){codec.audio.Stop();voice_pending=false;display.SetStatus("A 对话");Application::GetInstance().ActivateDesktopVoice();if(auto_chat){auto_chat=false;auto_chat_at=now+500;}}
   }else voice_ready_at=0;
  }else voice_wait_ms=0;
  // v35：语音页聆听兜底。AutoStop 依赖服务端检测静音后下发停止，服务端稍慢
  // 就一直挂在「聆听中」不回来（用户看到的就是"按 A 后一直在聆听"）。
  // 这里加 15 秒硬超时：到点主动收掉这一轮，页面不会卡在聆听状态。
  if(page==2&&!voice_pending){
   if(Application::GetInstance().GetDeviceState()==kDeviceStateListening){
    if(listen_started_ms_==0)listen_started_ms_=now;
    else if(now-listen_started_ms_>15000){
     listen_started_ms_=0;
     Application::GetInstance().ToggleChatState();
     dirty=true;
    }
   }else listen_started_ms_=0;
  }
  if(matches==2&&stable!=candidate){
   uint8_t newly=candidate&~stable,released=stable&~candidate;
   for(int i=0;i<4;i++){
    if(newly&masks[i]){
     track[i].down=true;track[i].down_ms=now;track[i].long_fired=false;track[i].repeat_ms=now;
     // 游戏页按下即派发：不等松手、不做双击判定。以前要等 280ms 双触发窗口
     // 结束才算是单击，手感就是"按下去半天没反应"。
     if(game_page)Key(masks[i],0);
    }
    if(released&masks[i]){
     track[i].down=false;
     if(!game_page&&!track[i].long_fired){
      if(track[i].tap_pending&&now-track[i].tap_ms<kDoubleMs){track[i].tap_pending=false;Key(masks[i],1);}
      else{track[i].tap_pending=true;track[i].tap_ms=now;}
     }
    }
   }
   stable=candidate;
  }
  const int64_t long_ms=game_page?kGameLongMs:kLongMs;
  for(int i=0;i<4;i++){
   if(track[i].down&&!track[i].long_fired&&now-track[i].down_ms>=long_ms){
    track[i].long_fired=true;track[i].tap_pending=false;Key(masks[i],2);
   }
   // 长按连发只留给"按住连续加减"的动作，也就是音量。游戏内动作全是点按，
   // 连发会和"按住 0.9 秒 = 退出/回主页"打架，所以游戏页一律不连发。
   // v40：以前这里按掩码判断（B=0x08、C=0x02 算连发键），可计时器页与节拍器页
   // 的长按 B 是「切到另一个子界面」——按住不放就每 200ms 重放一次那记长按，
   // 于是在计时器和节拍器之间来回跳（用户说的"有概率来回切"就是这个）。
   // 改成先把这一格解析成动作，只有音量类动作才连发。
   if(!game_page&&track[i].down&&track[i].long_fired&&now-track[i].repeat_ms>=kRepeatMs){
    track[i].repeat_ms=now;
    const Act act=kLong[RowForPage(desktop_page.load(),timer_view)][i];
    if(act==kVolUp||act==kVolDown)Key(masks[i],3);
   }
   if(!game_page&&track[i].tap_pending&&now-track[i].tap_ms>=kDoubleMs){track[i].tap_pending=false;Key(masks[i],0);}
  }
  if(volume_save_at&&now>=volume_save_at){
   Settings settings("desk_audio",true);settings.SetInt("volume",codec.audio.volume());
   Settings audio_settings("audio",true);audio_settings.SetInt("output_volume",codec.audio.volume());
   volume_save_at=0;
  }
  // If the hotspot worker failed to spawn at boot because internal RAM was
  // tight, keep retrying here. Without it ap_desired gets set by the key but
  // nobody runs OpenAP(): no beacon, and the page sits on "正在开启热点".
  static int64_t last_worker_try=0;
  if(!ap_worker_up.load()&&now-last_worker_try>2000){
   last_worker_try=now;
   EnsureApWorker();
  }
  static bool overlay_visible=false;
  bool visible=now<volume_overlay_until;
  if(visible!=overlay_visible){dirty=true;overlay_visible=visible;}
  if(display.changed.exchange(false))dirty=true;
 if(now-last_render>=1000&&(page==0||page==5))dirty=true;
 // v34：收音机页 2s -> 800ms。连接/缓冲/播放这些状态切换原来最长要等 2 秒
 // 才反映到屏幕上；现在 RefreshRadio 不再整页 invalidate，多刷几次几乎不花
 // 代价（文本没变化时 Set() 直接返回）。
 if(page==3&&now-last_render>=800)dirty=true;
 // v47：计时页的三个子视图刷新节奏不一样：
 //   目录/定时器 = 250ms（数字够用）；节拍器 = 80ms（拍点要跟手）；
 //   计时器 = 80ms（百分秒在跳）。
 if(page==4){
  if(timer_view==2||timer_view==3){
   if(now-last_render>=80)dirty=true;
  }else if(now-last_render>=250||(countdown.finished&&now-last_render>=400))dirty=true;
 }
  if(page==2&&now-last_render>=160)dirty=true;
  if(countdown.finished&&page!=4&&now-last_render>=1000)dirty=true;
  if(dirty.load()&&now-last_render>=80){
   dirty=false;auto started=esp_timer_get_time();Render();render_us=esp_timer_get_time()-started;last_render=now;
  }
  // 波形由主循环按真实时钟驱动，不依赖 LVGL timer：即使 timer 被卡住，
  // 只要按键扫描还在跑，波纹就不会僵住（声音是独立任务，不随 UI 停）。
  if(page==3)g_ui.PumpRadioMeter(now);
  // Same task renders and pumps: lv_timer_handler() runs right after the widget
  // refresh so a page switch is on the panel within the same loop iteration.
  display.LvglPump();
  // 游戏页把扫描周期压到 12ms：去抖要连采 2 次，等于把输入延迟从 40ms 降到 24ms
  vTaskDelay(pdMS_TO_TICKS(game_page?12:20));
 }
}
class AlphaPiOneSDesktopBoard final : public WifiBoard {
 DesktopRuntime runtime_;
public:
 Display* GetDisplay()override{return &runtime_.display;}
 AudioCodec* GetAudioCodec()override{return &runtime_.codec;}
 void StartNetwork()override{runtime_.StartNetwork();}
 void SetNetworkEventCallback(NetworkEventCallback cb)override{runtime_.network_callback=std::move(cb);}
 const char* GetNetworkStateIcon()override{return "";}
 void SetPowerSaveLevel(PowerSaveLevel)override{esp_wifi_set_ps(WIFI_PS_NONE);}
 std::string GetBoardJson()override{return "{\"type\":\"wifi\",\"name\":\"alphapi-one-s-desktop\"}";}
 std::string GetDeviceStatusJson()override{return desktop_network?"{\"network\":\"connected\"}":"{\"network\":\"disconnected\"}";}
};
DECLARE_BOARD(AlphaPiOneSDesktopBoard)
