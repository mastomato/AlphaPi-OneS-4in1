#include "n32_audio.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstring>
#include <mutex>

#include "esp_log.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "freertos/task.h"
#include "driver/uart.h"

#include "radio_config.h"

namespace radio {
namespace {

constexpr char kTag[] = "N32Audio";
static bool g_recording = false;
static bool g_uart_initialized = false;
static std::atomic<uint8_t> g_keys{0xFF};
static std::atomic<int64_t> g_keys_at{0};
static std::atomic<uint32_t> g_key_polls{0};
static int64_t g_key_attempt_at=0; // Access only while holding UartMutex.
// 写寄存器等待应答超时：N32 持续播放时 UART 应答可能晚到，
// 120ms 太紧会导致高频"写失败→重置链路"风暴（实测引发中断看门狗崩溃），放宽到 400ms。
constexpr int kCommandTimeoutMs = 400;

// v37：音效的时长/包络全部在 PlayBeep() 里按采样数现算，不再需要固定
// 的 160ms + 120ms 常量（旧值只够把一声短促的"嘀"写出去，N32 还没开播
// 流就断了）。

// 与 N32 协处理器通信时统一持有的互斥锁。
// 音频写入、按键查询两方共用，防止抢总线导致音频卡顿。
std::mutex& UartMutex() {
    static std::mutex mutex;
    return mutex;
}

}  // namespace

uint8_t N32Audio::Checksum(const uint8_t* data, size_t length) {
    uint8_t sum = 0;
    for (size_t i = 0; i < length; ++i) {
        sum = static_cast<uint8_t>(sum + data[i]);
    }
    return sum;
}

bool N32Audio::ReadExact(uint8_t* data, size_t length, int timeout_ms) {
    // v37：改成**总预算**。原来每次 uart_read_bytes 都重新给 timeout_ms，
    // 只要字节断断续续地来，一次"50ms 超时"的事务实际能拖到几百毫秒，
    // 全程还握着 UART 锁——这就是小智页偶发卡死的直接来源。
    size_t offset = 0;
    const int64_t deadline =
        esp_timer_get_time() + static_cast<int64_t>(timeout_ms) * 1000;
    while (offset < length) {
        const int64_t left_us = deadline - esp_timer_get_time();
        if (left_us <= 0) {
            return false;
        }
        TickType_t ticks = pdMS_TO_TICKS((left_us + 999) / 1000);
        if (ticks == 0) {
            ticks = 1;
        }
        const int received = uart_read_bytes(kUartPort, data + offset,
                                             length - offset, ticks);
        if (received <= 0) {
            return false;
        }
        offset += static_cast<size_t>(received);
    }
    return true;
}

bool N32Audio::SendCommand(uint8_t reg, const uint8_t* payload,
                           size_t payload_size, uint8_t* accepted) {
    if (payload_size > kMaxPayloadSize) {
        return false;
    }
    std::array<uint8_t, kMaxPayloadSize + 4> frame = {};
    frame[0] = kWritePrefix;
    frame[1] = reg;
    frame[2] = static_cast<uint8_t>(payload_size);
    if (payload_size > 0) {
        std::memcpy(frame.data() + 3, payload, payload_size);
    }
    frame[payload_size + 3] = Checksum(frame.data(), payload_size + 3);

    const size_t frame_size = payload_size + 4;

    // 写失败 / 应答异常时重试一次：N32 播放中应答可能晚到，
    // 立即判失败会触发"重置播放链路"风暴（见 kCommandTimeoutMs 注释）。
    for (int attempt = 0; attempt < 2; ++attempt) {
        uart_flush_input(kUartPort);
        if (uart_write_bytes(kUartPort, frame.data(), frame_size) !=
            static_cast<int>(frame_size)) {
            continue;
        }

        std::array<uint8_t, 3> ack = {};
        if (ReadExact(ack.data(), ack.size(), kCommandTimeoutMs) &&
            ack[0] == kWriteAck && ack[1] == reg) {
            if (accepted != nullptr) {
                *accepted = ack[2];
            }
            return true;
        }
    }
    return false;
}

bool N32Audio::Init() {
    std::lock_guard<std::mutex> lock(UartMutex());
    if (initialized_) {
        return true;
    }

    if(g_uart_initialized){initialized_=true;return true;}
    const uart_config_t config = {
        .baud_rate = kUartBaudRate,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .rx_flow_ctrl_thresh = 0,
        .source_clk = UART_SCLK_APB,
        .flags = {},
    };
    if (uart_driver_install(kUartPort, 8192, 8192, 0, nullptr, 0) != ESP_OK) {
        ESP_LOGE(kTag, "UART 驱动安装失败");
        return false;
    }
    if (uart_param_config(kUartPort, &config) != ESP_OK) {
        ESP_LOGE(kTag, "UART 参数配置失败");
        return false;
    }
    if (uart_set_pin(kUartPort, kUartTx, kUartRx, UART_PIN_NO_CHANGE,
                     UART_PIN_NO_CHANGE) != ESP_OK) {
        ESP_LOGE(kTag, "UART 引脚设置失败");
        return false;
    }
    uart_flush_input(kUartPort);

    gpio_config_t keys={};keys.pin_bit_mask=(1ULL<<10)|(1ULL<<11)|(1ULL<<12)|(1ULL<<13);
    keys.mode=GPIO_MODE_INPUT;keys.pull_down_en=GPIO_PULLDOWN_ENABLE;gpio_config(&keys);
    vTaskDelay(pdMS_TO_TICKS(2000));
    initialized_ = true;
    g_uart_initialized = true;
    ESP_LOGI(kTag, "UART1 初始化完成 (TX=%d RX=%d baud=%d)",
             kUartTx, kUartRx, kUartBaudRate);
    return true;
}

bool N32Audio::SetHardwareVolumeLocked(int volume) {
    // Verified against the supplied original XiaoZhi firmware, function
    // 0x4202b084: level = (clamp(percent, 0, 100) * 6 + 50) / 100.
    // N32 expects an internal level, never a raw percentage such as 100.
    const uint8_t level = static_cast<uint8_t>(
        (std::clamp(volume, kVolumeMin, kVolumeMax) * 6 + 50) / 100);
    uint8_t accepted = 0;
    return SendCommand(kRegVolume, &level, 1, &accepted);
}

bool N32Audio::Start() {
    std::lock_guard<std::mutex> lock(UartMutex());
    return StartLocked();
}

bool N32Audio::StartLocked() {
    // 调用方必须已持有 UART 互斥锁

    // v37：顺序对齐已被实机验证的原版驱动（audio_uart.cc）：
    //   音量 -> 停录音 -> 44 字节 WAV 头。
    // v36 是「停录音 -> 音量 -> 头」，在 N32 上 0x10 写 0 会让音频通路
    // 复位一次，紧随其后的音量设置偶尔被吞掉，播放链路就停在「已应答但
    // 不出声」的半开状态。
    if (!SetHardwareVolumeLocked(100)) {
        ESP_LOGW(kTag, "设置音量失败（不影响播放，继续）");
    }

    // 半双工：播放前必须先停掉麦克风流
    const uint8_t stop_record = 0;
    if (!SendCommand(kRegAudioControl, &stop_record, 1)) {
        ESP_LOGW(kTag, "停止录音失败（不影响播放，继续）");
    }

    // 44 字节标准 WAV 头，向 N32 声明 24000Hz / 8bit / 单声道。
    constexpr uint32_t rate = kOutputSampleRate;
    const std::array<uint8_t, 44> wav_header = {
        'R', 'I', 'F', 'F', 0xff, 0xff, 0xff, 0xff,
        'W', 'A', 'V', 'E', 'f', 'm', 't', ' ',
        0x10, 0x00, 0x00, 0x00,        // fmt chunk size = 16
        0x01, 0x00,                    // PCM
        0x01, 0x00,                    // mono
        static_cast<uint8_t>(rate), static_cast<uint8_t>(rate >> 8),
        static_cast<uint8_t>(rate >> 16), static_cast<uint8_t>(rate >> 24),
        static_cast<uint8_t>(rate), static_cast<uint8_t>(rate >> 8),
        static_cast<uint8_t>(rate >> 16), static_cast<uint8_t>(rate >> 24),
        0x01, 0x00,                    // block align = 1
        0x08, 0x00,                    // 8 bits per sample
        'd', 'a', 't', 'a', 0xff, 0xff, 0xff, 0xff,
    };
    if (!SendCommand(kRegStream, wav_header.data(), wav_header.size())) {
        ESP_LOGE(kTag, "发送 WAV 头失败");
        return false;
    }

    g_recording = false;
    configured_ = true;
    last_write_us_ = esp_timer_get_time();
    ESP_LOGI(kTag, "播放已就绪：%u Hz / 8-bit unsigned / mono", kOutputSampleRate);
    return true;
}

void N32Audio::Stop() {
    std::lock_guard<std::mutex> lock(UartMutex());
    if (!configured_ && !g_recording) {
        return;
    }
    const uint8_t stop_record = 0;
    SendCommand(kRegAudioControl, &stop_record, 1);
    g_recording = false;
    configured_ = false;
    last_write_us_ = 0;
}

void N32Audio::SetVolume(int volume) {
    volume_ = std::clamp(volume, kVolumeMin, kVolumeMax);
    // 音量一律走软件缩放（Write() 内按 volume_ 对 PCM 缩放，真实生效）。
    // 不再每次按键写 N32 硬件寄存器 0x14 —— 高频写硬件音量曾触发链路异常导致重启。
}

int N32Audio::Level() {
    // Fast attack, slow release: fold in the loudest block seen since the last
    // UI frame, otherwise decay by roughly a quarter. Same curve as the local
    // standalone radio firmware, so the meter reads the same on both builds.
    const int peak = peak_.exchange(0);
    const int decayed = level_ - (level_ + 3) / 4;
    level_ = peak > decayed ? peak : decayed;
    return level_;
}

void N32Audio::BeepTaskThunk(void* arg) {
    static_cast<N32Audio*>(arg)->BeepWorker();
}

void N32Audio::BeepWorker() {
    for (;;) {
        // 空闲 3 秒 or 页面退出 -> 任务自行结束并清掉句柄，不留后台常驻任务
        const uint32_t got = ulTaskNotifyTake(pdTRUE, pdMS_TO_TICKS(3000));
        if (got == 0 || beep_stop_.exchange(false)) {
            // 先摘句柄再删自己：Beep() 只要在互斥量内拿到非空句柄，就一定
            // 还没走到 vTaskDelete，不会对已释放的 TCB 发通知。
            auto mux = static_cast<SemaphoreHandle_t>(beep_mux_);
            if (mux) xSemaphoreTake(mux, portMAX_DELAY);
            beep_busy_.store(false);
            beep_task_.store(nullptr);
            if (mux) xSemaphoreGive(mux);
            vTaskDelete(nullptr);
            return;
        }
        const uint32_t req = beep_req_.load(std::memory_order_relaxed);
        PlayBeep(req);
        beep_busy_.store(false);
    }
}

void N32Audio::StopBeepTask() {
    // v35：置标志与取句柄必须在同一把锁里。原来先 store(true) 再 load 句柄，
    // 中间任务可能正好自删并把 beep_task_ 清空——这里的 load 还是能读到旧值，
    // 于是 xTaskNotifyGive 打在一个已经释放的 TCB 上（退出功能页时死机）。
    auto mux = static_cast<SemaphoreHandle_t>(beep_mux_);
    if (mux) xSemaphoreTake(mux, portMAX_DELAY);
    beep_stop_.store(true);
    void* t = beep_task_.load();
    if (mux) xSemaphoreGive(mux);
    if (t) xTaskNotifyGive(static_cast<TaskHandle_t>(t));
}

void N32Audio::Beep(int freq, int ms, int type) {
    if (freq <= 0 || ms <= 0) return;
    // v35：不再「上一个音效还没发完就丢弃这一次」。游戏里吃豆/击砖/过关都是
    // 连续触发，按旧逻辑会被丢得只剩零星一声。这里改成覆盖成最新的请求，
    // 任务处理完手上这份就会看到最新的一份，至少最后一次一定响。
    const uint32_t req = (static_cast<uint32_t>(freq & 0x3FFF) << 18) |
                         (static_cast<uint32_t>(ms & 0x3FF) << 8) |
                         static_cast<uint32_t>(type & 0xFF);
    beep_req_.store(req, std::memory_order_relaxed);
    if (!beep_mux_) beep_mux_ = xSemaphoreCreateMutex();
    auto mux = static_cast<SemaphoreHandle_t>(beep_mux_);
    if (mux) xSemaphoreTake(mux, portMAX_DELAY);
    void* task = beep_task_.load();
    if (task == nullptr) {
        TaskHandle_t handle = nullptr;
        // v34：这里必须把 beep_stop_ 复位。StopBeepTask() 会把它置 true，
        // 以前新建任务时没有清回来，导致「第一次退出功能页之后，后面所有
        // 音效都被新任务当成退出指令，一声都不响」。
        beep_stop_.store(false);
        beep_busy_.store(false);
        // 优先级 4：高于 idle，低于 UI 的 5。旧值 3 在收音机收尾任务（优先级
        // 7）还没退干净时会被长时间压住，音效直接"没声音"。
        if (xTaskCreate(&N32Audio::BeepTaskThunk, "game_beep", 3072, this, 4,
                        &handle) != pdPASS) {
            if (mux) xSemaphoreGive(mux);
            beep_fail_.fetch_add(1);
            ESP_LOGW(kTag, "音效任务创建失败（内存不足）");
            return;
        }
        beep_task_.store(handle);
        task = handle;
    }
    if (mux) xSemaphoreGive(mux);
    xTaskNotifyGive(static_cast<TaskHandle_t>(task));
}

void N32Audio::PlayBeep(uint32_t req) {
    const int freq = static_cast<int>(req >> 18);
    const int ms = static_cast<int>((req >> 8) & 0x3FF);
    const int type = static_cast<int>(req & 0xFF);
    if (freq <= 0 || ms <= 0) return;

    const int sr = 24000;
    // v37：音调最短 83ms、最长 500ms。18~30ms 的短音在 N32 的接收/播放
    // 缓冲里根本来不及开播，这就是「游戏一声都不响」最直接的原因——
    // 数据全都写出去了（beep_fail 为 0），但芯片还没开始播，流就断了。
    int tone = (sr * ms) / 1000;
    if (tone < sr / 12) tone = sr / 12;   // 83 ms
    if (tone > sr / 2) tone = sr / 2;     // 500 ms
    const int pre = sr / 50;              // 20ms 静音预热：先把流推起来
    const int tail = sr * 3 / 20;         // 150ms 静音尾：保证音调整段播完
    const int total = pre + tone + tail;

    // v37：**只在链路真的断开时重握手**。
    // v36 每次 Beep 都发一遍 44 字节 WAV 头：连续音效（倒计时三声、游戏连击）
    // 时上一段流还没结束，新头会被 N32 当成 PCM 数据播出去——用户听到的
    // 「结束时有疑似声音、但像喇叭异响」正是这 44 个 RIFF 字节。
    // 反过来，流间隙超过约 500ms 后芯片会把这一段播放会话判为结束（原版
    // 驱动 audio_uart.cc 的 kStreamGapUs 是实机结论），这时必须重发头，
    // 否则后面的 PCM 会被静默吞掉。
    const int64_t now_us = esp_timer_get_time();
    const bool stream_gap =
        last_write_us_ == 0 || (now_us - last_write_us_) > 400 * 1000;
    if (!configured_ || g_recording || stream_gap) {
        if (!Start()) {
            // 链路可能停在半开状态（上一路流没退净），完整复位一次再重来
            Stop();
            if (!Start()) {
                beep_fail_.fetch_add(1);
                ESP_LOGW(kTag, "音效握手失败 freq=%d ms=%d", freq, ms);
                return;
            }
        }
    }

    // 分块合成并写出：每块最多 200 样本（400 B，即 2 个 200 B 的 UART 帧）。
    // 不再一次性分配整段 1.5s 的缓冲（那要 72 KB），也不再依赖 PSRAM 大块分配。
    int16_t block[200];
    constexpr int kBlockSamples = sizeof(block) / sizeof(block[0]);
    const int fade = sr / 200;  // 5ms 淡入淡出，去掉起振/收尾的"咔"声
    for (int off = 0; off < total; off += kBlockSamples) {
        const int n = std::min(kBlockSamples, total - off);
        for (int i = 0; i < n; ++i) {
            const int k = off + i;
            float v = 0.0f;
            if (k >= pre && k < pre + tone) {
                const int j = k - pre;
                const float t = static_cast<float>(j) / static_cast<float>(sr);
                if (type == 1) {
                    v = std::sin(2.0f * 3.14159265f * static_cast<float>(freq) * t);
                } else {
                    const float ph = std::fmod(t * static_cast<float>(freq), 1.0f);
                    v = ph < 0.5f ? 0.92f : -0.92f;  // 方波更"街机"
                }
                if (j < fade) {
                    v *= static_cast<float>(j) / static_cast<float>(fade);
                } else if (j > tone - fade) {
                    v *= static_cast<float>(tone - j) / static_cast<float>(fade);
                }
            }
            // v37：幅度 9000 -> 20000。旧值转成 8-bit 后只有 ±35/128（约
            // -11 dBFS），几十毫秒的短音在小喇叭上几乎听不见。
            block[i] = static_cast<int16_t>(v * 20000.0f);
        }
        if (Write(block, n) <= 0) {
            beep_fail_.fetch_add(1);
            ESP_LOGW(kTag, "音效写入失败 freq=%d ms=%d fail=%d", freq, ms,
                     beep_fail_.load());
            configured_ = false;
            return;
        }
    }
}

int N32Audio::Write(const int16_t* samples, int sample_count) {
    if (samples == nullptr || sample_count <= 0) {
        return 0;
    }

    std::unique_lock<std::mutex> lock(UartMutex());

    // 此处已持有互斥锁，必须调用无锁版本，否则 std::mutex 不可重入会死锁
    if ((!configured_ || g_recording) && !StartLocked()) {
        ESP_LOGE(kTag, "播放未就绪，丢弃 %d 样本", sample_count);
        return 0;
    }

    const size_t total = static_cast<size_t>(sample_count);
    size_t written = 0;
    std::array<uint8_t, kMaxPayloadSize> chunk = {};
    // Measure every other block. The RMS uses the SCALED samples (after the
    // software volume below), so volume/mute is reflected in the meter exactly
    // as it is in the speaker - no independent fake animation.
    const bool measure = (++level_tick_ >= 2);
    if (measure) level_tick_ = 0;
    uint64_t sum_sq = 0;
    uint64_t measured = 0;

    while (written < total) {
        if (!lock.owns_lock()) lock.lock();
        if (!configured_ || g_recording) return static_cast<int>(written);
        const size_t n = std::min(total - written, kMaxPayloadSize);

        // 软件音量：直接对 PCM 样本缩放（N32 寄存器 0x14 在播放流中
        // 可能不响应，软件缩放保证真实音量一定变化；100 时旁路不缩）。
        const int vol = volume_.load();
        for (size_t i = 0; i < n; ++i) {
            int32_t s = samples[written + i];
            if (vol != kVolumeMax) {
                s = (s * vol) / 100;
            }
            if (measure) {
                sum_sq += static_cast<uint64_t>(static_cast<int64_t>(s) * s);
                ++measured;
            }
            // 16-bit signed -> 8-bit unsigned：静音(0) 映射到 128
            chunk[i] = static_cast<uint8_t>((s + 32768) >> 8);
        }

        size_t sent = 0;
        int stalled = 0;
        while (sent < n) {
            PollKeysLocked();
            uint8_t accepted = 0;
            if (!SendCommand(kRegStream, chunk.data() + sent, n - sent,
                             &accepted)) {
                ESP_LOGW(kTag, "PCM 写入失败，重置播放链路");
                configured_ = false;
                return static_cast<int>(written + sent);
            }
            if (accepted == 0) {
                // N32 的接收缓冲满了，短暂等待后重试
                if (++stalled > 20) {
                    ESP_LOGW(kTag, "PCM 写入停滞，重置播放链路");
                    configured_ = false;
                    return static_cast<int>(written + sent);
                }
                // 注意：此时已持有 mutex，等待必须很短（5ms 上限）
                // At CONFIG_FREERTOS_HZ=100, pdMS_TO_TICKS(5) is zero!
                // A zero-tick yield does not let lower priority UI tasks run.
                vTaskDelay(std::max<TickType_t>(1,pdMS_TO_TICKS(5)));
                continue;
            }
            sent += std::min<size_t>(accepted, n - sent);
            stalled = 0;
        }
        written += n;
        last_write_us_ = esp_timer_get_time();
        // Let key polling use the bus between complete, checksum-protected frames.
        lock.unlock();
        taskYIELD();
    }
    if (measure && measured > 0) {
        const double rms = std::sqrt(static_cast<double>(sum_sq) / measured) / 32768.0;
        int percent = static_cast<int>(rms * 330.0);
        if (percent > 100) percent = 100;
        int seen = peak_.load();
        while (percent > seen && !peak_.compare_exchange_weak(seen, percent)) {
        }
    }
    return sample_count;
}

uint8_t N32Audio::ReadKeys() {
    uint8_t keys=(gpio_get_level(GPIO_NUM_13)?4:0)|(gpio_get_level(GPIO_NUM_12)?8:0)|
        (gpio_get_level(GPIO_NUM_11)?2:0)|(gpio_get_level(GPIO_NUM_10)?1:0);
    g_keys=keys;g_keys_at=esp_timer_get_time();g_key_polls++;return keys;
}

uint32_t N32Audio::key_polls() const { return g_key_polls.load(); }
uint8_t N32Audio::cached_keys() const { return g_keys.load(); }

void N32Audio::PollKeysLocked() { ReadKeys(); }

uint8_t N32Audio::ReadKeysLocked() {

    // 读键事务：0x80 <reg> <len> -> 应答 0x81 <reg> <len> <value> <sum>
    const std::array<uint8_t, 3> query = {kReadPrefix, kRegKey, 1};
    std::array<uint8_t, 5> response = {};

    uart_flush_input(kUartPort);
    if (uart_write_bytes(kUartPort, query.data(), query.size()) !=
        static_cast<int>(query.size())) {
        return 0xFF;
    }
    if (!ReadExact(response.data(), response.size(), 20)) {
        return 0xFF;
    }

    const uint8_t checksum = static_cast<uint8_t>(
        response[0] + response[1] + response[2] + response[3]);
    if (response[0] != kReadAck || response[1] != kRegKey ||
        response[2] != 1 || response[4] != checksum) {
        return 0xFF;
    }
    return response[3];
}


int N32Audio::ReadMic(int16_t* samples, int count) {
    if (!samples || count <= 0) return 0;
    std::lock_guard<std::mutex> lock(UartMutex());
    PollKeysLocked();

    // 从播放切到录音：N32 是半双工，切换需要一点时间；顺便把播放残留的
    // 应答字节丢掉，否则第一次读麦克风会拿错帧。
    if (!g_recording) {
        uint8_t enable = 1;
        if (!SendCommand(kRegAudioControl, &enable, 1)) {
            uart_flush_input(kUartPort);
            return 0;
        }
        configured_ = false;
        last_write_us_ = 0;
        g_recording = true;
        vTaskDelay(1);
    }

    // v37：一次取满 200 字节（原版驱动 audio_uart.cc 的上限）。以前固定
    // 160，AudioService 一帧要拆成 2~4 次 UART 往返，任何一次超时都会整帧
    // 丢掉——用户感知就是"小智识别不灵敏"。
    const int n = std::min(count, static_cast<int>(kMaxPayloadSize));
    const std::array<uint8_t, 3> query = {kReadPrefix, kRegAudioRead,
                                          static_cast<uint8_t>(n)};
    std::array<uint8_t, kMaxPayloadSize + 4> response = {};

    // 失败统一走这里：半帧残留会让之后每一次读事务整体错位（校验一直失败），
    // 必须清空接收缓冲并重新发 0x10=1 开录音，而不是一路失败下去。
    auto fail = [&]() -> int {
        uart_flush_input(kUartPort);
        g_recording = false;
        last_write_us_ = 0;
        return -1;
    };

    uart_flush_input(kUartPort);
    if (uart_write_bytes(kUartPort, query.data(), query.size()) !=
        static_cast<int>(query.size())) {
        return fail();
    }
    if (!ReadExact(response.data(), 3, 30)) return fail();
    const int received = response[2];
    if (response[0] != kReadAck || response[1] != kRegAudioRead ||
        received <= 0 || received > n) {
        return fail();
    }
    if (!ReadExact(response.data() + 3, received + 1, 40)) return fail();
    if (Checksum(response.data(), received + 3) != response[received + 3]) {
        return fail();
    }
    for (int i = 0; i < received; ++i) {
        samples[i] =
            static_cast<int16_t>((static_cast<int>(response[3 + i]) - 128) * 256);
    }
    return received;
}

}  // namespace radio
