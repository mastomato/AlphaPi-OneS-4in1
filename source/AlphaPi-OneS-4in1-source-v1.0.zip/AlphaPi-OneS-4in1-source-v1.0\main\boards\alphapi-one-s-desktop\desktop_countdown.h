#pragma once
#include "desktop_home.h"
#include "desktop_gfx.h"
#include "st7789.h"
#include "settings.h"
#include <algorithm>
#include <cstdint>
#include <cstdio>

namespace desktop_countdown {
inline uint16_t C(int r,int g,int b){return ((r>>3)<<11)|((g>>2)<<5)|(b>>3);}

// Standalone timer. B cycles the editable field (minutes / seconds),
// C / D adjust it, A confirms and starts (or pauses) with the current preset.
struct Timer {
    static constexpr int kMinSec=1;
    static constexpr int kMaxSec=5999;
    int preset_ms=300000;
    int remain_ms=300000;
    int64_t end_ms=0;
    bool running=false;
    bool finished=false;
    int field=0;
    int beep_left=0;
    int64_t beep_next_ms=0;

    void Load(){
        Settings s("desk_timer",true);
        int sec=std::clamp(static_cast<int>(s.GetInt("preset",300)),kMinSec,kMaxSec);
        preset_ms=sec*1000;remain_ms=preset_ms;
    }
    void Save(){Settings s("desk_timer",true);s.SetInt("preset",preset_ms/1000);}
    void Reset(){running=false;finished=false;remain_ms=preset_ms;end_ms=0;beep_left=0;}
    void SetPreset(int sec){
        sec=std::clamp(sec,kMinSec,kMaxSec);
        preset_ms=sec*1000;remain_ms=preset_ms;
        running=false;finished=false;end_ms=0;beep_left=0;Save();
    }
    int Remaining(int64_t now)const{
        if(finished)return 0;
        if(running)return std::max(0,static_cast<int>(end_ms-now));
        return remain_ms;
    }
    void Start(int64_t now){
        if(finished)Reset();
        if(remain_ms<=0)remain_ms=preset_ms;
        end_ms=now+remain_ms;running=true;finished=false;
    }
    void Pause(int64_t now){
        if(!running)return;
        remain_ms=Remaining(now);running=false;
    }
    void Toggle(int64_t now){if(running)Pause(now);else Start(now);}
    void NextField(){field=(field+1)%2;}
    void Step(int delta,int64_t now){
        if(running)Pause(now);
        if(finished){finished=false;beep_left=0;remain_ms=preset_ms;}
        int total=std::clamp(remain_ms/1000+(field==0?delta*60:delta),kMinSec,kMaxSec);
        remain_ms=total*1000;preset_ms=total*1000;
        Save();
    }
    void Tick(int64_t now){
        if(running&&end_ms<=now){
            running=false;finished=true;remain_ms=0;
            beep_left=3;beep_next_ms=now;
        }
    }
    void Acknowledge(){if(finished){finished=false;beep_left=0;Reset();}}

    void Draw(radio::Display& lcd,int64_t now,bool blink){
        const auto bg=C(14,20,32),cyan=C(143,227,240),warm=C(255,210,122),
                   ink=C(147,170,198),dim=C(113,134,160);
        int left=Remaining(now),total=left/1000;
        char buf[16];snprintf(buf,sizeof(buf),"%02d:%02d",total/60,total%60);
        desktop_home::Text(lcd,9,6,"计时器",cyan,159);
        const char* state=finished?"时间到":running?"运行中":(left<preset_ms?"已暂停":"设定");
        desktop_home::Text(lcd,112,6,state,finished?warm:dim,159);
        uint16_t big=finished?(blink?warm:bg):(running?cyan:ink);
        gfx::Digits(lcd,20,32,buf,big,1.2f,4,bg);
        if(!running&&!finished){
            int fx=field==0?20:20+3*24;
            gfx::RoundRect(lcd,fx,88,46,2,1.0f,warm);
        }
        gfx::RoundRect(lcd,12,100,136,6,3.0f,C(27,39,64));
        int pct=preset_ms>0?std::clamp(static_cast<int>(static_cast<int64_t>(left)*136/preset_ms),0,136):0;
        if(pct>0)gfx::RoundRect(lcd,12,100,pct,6,3.0f,finished?warm:cyan);
        if(finished)desktop_home::Text(lcd,48,112,"任意键确认",warm,159);
    }
};
}
