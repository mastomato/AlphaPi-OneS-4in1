#pragma once

// N32 音频协处理器输出 —— AlphaPi One (ESP32-S3) 独立版
//
// 移植自 xiaozhi-esp32/main/radio/n32_audio.{h,cc}，改动：
//   1. 去掉对 alphapi_s3_audio_codec.h 的依赖（UART 互斥锁在本模块内定义）
//   2. 新增 Init()：本模块自己完成 uart_driver_install（原由板级 codec 负责）
//
// 保留两个已被实机验证的关键做法：
//   1. 16-bit 有符号 -> 8-bit 无符号转换 (sample + 32768) >> 8
//   2. 播放前发送 44 字节 WAV 头，向 N32 声明 24000Hz / 8bit / mono

#include <atomic>
#include <cstddef>
#include <cstdint>

#include "radio_config.h"

namespace radio {

class N32Audio {
public:
    N32Audio() = default;

    // 初始化 UART 并设置初始音量。必须在任何读写之前调用一次。
    bool Init();

    // 进入播放态：停录音、设音量、发 WAV 头。
    // 会在第一次 Write() 时自动调用，也可提前手动调用。
    bool Start();
    void Stop();

    void SetVolume(int volume);
    int volume() const { return volume_; }

    // 写入 16-bit 有符号单声道 PCM，内部转换并分块发给 N32。
    // 返回实际写入的样本数（正常情况下等于 sample_count）。
    int Write(const int16_t* samples, int sample_count);

    // Real audio level for the on-screen meter, 0..100. Write() measures the
    // RMS of the samples AFTER the software volume scaling, so muting really
    // flattens the meter and there is no fake animation. Level() folds in the
    // peak seen since the last call and decays it (fast attack, slow release).
    // Called from the UI task only; peak_ is the only field shared with the
    // playback task.
    int Level();

    // 合成一段短音效（方波/正弦）经 Write() 发给 N32，用于游戏等离线提示。
    // freq 单位 Hz，ms 为时长（内部下限 83ms、上限 500ms），type=0 方波、1 正弦。
    // v28 起改为**异步**：这里只投递参数并给专用任务发通知，立即返回。
    // 以前同步 Write() 会在 UI 任务里等 UART 应答（单次可达 400ms），
    // 游戏里一得分/碰撞就卡住整屏、按键也跟着失灵。
    // v37：音效 PCM 固定为「20ms 静音预热 + 音调 + 250ms 静音尾巴」，
    // 且只在链路真的断开时才重发 WAV 头（见 PlayBeep 注释）。
    void Beep(int freq, int ms, int type = 0);

    // 音效播放任务的主体（只由 Beep() 创建的任务调用，勿手动调用）。
    void BeepWorker();
    // 页面退出时调用：让音效任务播完当前音效后立刻自行结束，不留后台常驻任务。
    // 任务空闲 3 秒也会自动退出，下次 Beep() 才重建。
    void StopBeepTask();

    // v35：音效链路失败次数（0 表示每次 Beep 都真的把 PCM 发给了 N32）。
    int beep_fail_count() const { return beep_fail_.load(); }

    // 播放链路是否已经握手完成（发过 WAV 头）。进游戏页前用它判断要不要
    // 主动 Start，避免第一次音效因为链路没开而白丢。
    bool ready() const { return configured_; }

    // 读取按键寄存器（0x00）。
    // 返回位掩码：A=0x04 B=0x08 L=0x02 R=0x01，按下为 1（原板实测）。
    // 读取失败返回 0xFF。与音频写入共用同一把 UART 互斥锁，
    // 播放中读键会造成约 1ms 的音频空洞，调用方需自行判断时机。
    uint8_t ReadKeys();
    uint32_t key_polls() const;
    uint8_t cached_keys() const;
    int ReadMic(int16_t* samples, int count);

private:
    // 以下 *Locked 版本假定调用方已持有 UART 互斥锁，内部不再加锁。
    bool StartLocked();
    uint8_t ReadKeysLocked();
    void PollKeysLocked();
    bool SetHardwareVolumeLocked(int volume);

    bool SendCommand(uint8_t reg, const uint8_t* payload, size_t payload_size,
                     uint8_t* accepted = nullptr);
    bool ReadExact(uint8_t* data, size_t length, int timeout_ms);
    static uint8_t Checksum(const uint8_t* data, size_t length);

    static void BeepTaskThunk(void* arg);
    void PlayBeep(uint32_t req);

    bool initialized_ = false;
    bool configured_ = false;
    // v37：上一次成功写出 PCM 的时刻（us）。N32 把超过 ~500ms 的流间隙
    // 视为「这一段播放会话结束」，再写数据必须先重发 WAV 头；反之若间隙
    // 很短（连击音效、倒计时三声），重发头会被芯片当成 PCM 播出——这正是
    // 「结束时有声音但像喇叭异响」的来源。
    int64_t last_write_us_ = 0;
    std::atomic<int> volume_{kDefaultVolume};
    std::atomic<int> peak_{0};   // written by Write(), consumed by Level()
    int level_ = 0;              // UI task only
    int level_tick_ = 0;         // playback task only
    std::atomic<bool> beep_busy_{false};
    std::atomic<uint32_t> beep_req_{0};  // 打包 freq/ms/type，由 Beep() 写、任务读
    std::atomic<void*> beep_task_{nullptr};  // 按需创建、空闲/退出即销毁
    std::atomic<bool> beep_stop_{false};
    // v35：音效链路失败计数（Start 失败 / PCM 没写出去）。启动器页面在它
    // 不为 0 时显示一行「音效失败 N」，这样"没声音"能第一时间分清是
    // 链路打开了但没触发，还是触发了却发不出去。
    std::atomic<int> beep_fail_{0};
    // v34：句柄的「取用 / 摘除」必须互斥，否则 Beep() 可能刚刚读到句柄、
    // 任务就自删了，随后这记 xTaskNotifyGive 打在已释放的 TCB 上。
    void* beep_mux_ = nullptr;  // SemaphoreHandle_t
};

}  // namespace radio
