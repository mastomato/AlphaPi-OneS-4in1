#include <ctime>
#include "esp_system.h"
#include "esp_timer.h"
#include "application.h"
#include <algorithm>
#include <cstdlib>
#include "desktop_runtime.h"
#include "desktop_web.h"
#include "esp_netif.h"
#include "esp_wifi.h"
#include "cJSON.h"
#include "esp_heap_caps.h"
#include <cstdio>
#include <cstring>
#include <sys/stat.h>
namespace {
std::string Body(httpd_req_t* r){if(r->content_len<=0||r->content_len>4096)return {};std::string body(r->content_len,'\0');int offset=0;while(offset<r->content_len){int n=httpd_req_recv(r,body.data()+offset,r->content_len-offset);if(n<=0)return {};offset+=n;}return body;}
esp_err_t Reply(httpd_req_t* r,const std::string& json,int code=200){httpd_resp_set_type(r,"application/json; charset=utf-8");httpd_resp_set_hdr(r,"Cache-Control","no-store");if(code!=200)httpd_resp_set_status(r,code==400?"400 Bad Request":"500 Internal Server Error");return httpd_resp_send(r,json.c_str(),json.size());}
esp_err_t Route(httpd_req_t* req){
 auto& self=*DesktopRuntime::instance;std::string path=req->uri;auto q=path.find('?');if(q!=std::string::npos)path.resize(q);
 self.http_requests++;
 {std::lock_guard<std::mutex> lock(self.state_mutex);self.http_last_path=path;}
 if(path=="/"){httpd_resp_set_type(req,"text/html; charset=utf-8");httpd_resp_set_hdr(req,"Cache-Control","no-store");return httpd_resp_send(req,desktop_html,HTTPD_RESP_USE_STRLEN);}
 if(path=="/ping"){httpd_resp_set_type(req,"text/plain; charset=utf-8");return httpd_resp_sendstr(req,"pong");}
 if(path=="/favicon.ico"){httpd_resp_set_status(req,"204 No Content");return httpd_resp_send(req,"",0);}
 if(path=="/api/weather"){
  if(req->method==HTTP_GET)return Reply(req,self.RegionJson());
  const auto data=Body(req);bool ok=!data.empty()&&self.SaveRegion(data.c_str());return Reply(req,ok?"{\"ok\":true}":"{\"ok\":false,\"error\":\"地区参数不正确\"}",ok?200:400);
 }
 if(path=="/api/regions"){
  char query[256]={},name[160]={};httpd_req_get_url_query_str(req,query,sizeof(query));
  if(httpd_query_key_value(query,"q",name,sizeof(name))!=ESP_OK||strlen(name)<1)return Reply(req,"{\"ok\":false,\"error\":\"请输入城市\"}",400);
  return Reply(req,self.SearchRegions(name));
 }
 if(path=="/api/wifi"){
  if(req->method==HTTP_GET)return Reply(req,self.ScanWifi());
  auto data=Body(req);auto root=cJSON_Parse(data.c_str());auto ssid=cJSON_GetObjectItem(root,"ssid"),pass=cJSON_GetObjectItem(root,"password");
  bool ok=cJSON_IsString(ssid)&&cJSON_IsString(pass)&&strlen(ssid->valuestring)>0&&strlen(ssid->valuestring)<=32&&(strlen(pass->valuestring)==0||(strlen(pass->valuestring)>=8&&strlen(pass->valuestring)<=63));
  if(!ok){cJSON_Delete(root);return Reply(req,"{\"ok\":false,\"error\":\"请检查网络名称和密码长度\"}",400);}
  std::string name=ssid->valuestring,password=pass->valuestring;cJSON_Delete(root);auto result=Reply(req,"{\"ok\":true}");self.ConnectWifi(name,password);return result;
 }
 if(path=="/api/ap"){
  // Provisioning hotspot switch. The page is normally served over the hotspot
  // itself, so turning it off from here also drops the phone: reply first, then
  // let the background task do the switch.
  if(req->method==HTTP_GET){
   auto root=cJSON_CreateObject();
   cJSON_AddBoolToObject(root,"on",self.ap_desired.load());
   cJSON_AddBoolToObject(root,"live",self.ap_live.load());
   cJSON_AddBoolToObject(root,"busy",self.ap_busy.load());
   cJSON_AddBoolToObject(root,"failed",self.ap_failed.load());
   cJSON_AddStringToObject(root,"ssid","AlphaPi-Desk");
   // Report the address the netif actually holds; 0.0.0.0 is a useful answer too.
   {
    const uint32_t a=self.ap_ip.load();char ipbuf[20];
    std::snprintf(ipbuf,sizeof(ipbuf),"%u.%u.%u.%u",(unsigned)(a&0xFF),(unsigned)((a>>8)&0xFF),
                  (unsigned)((a>>16)&0xFF),(unsigned)((a>>24)&0xFF));
    cJSON_AddStringToObject(root,"ip",ipbuf);
   }
   cJSON_AddBoolToObject(root,"dhcp",self.ap_dhcp.load());
   cJSON_AddNumberToObject(root,"channel",self.ap_chan.load());
   cJSON_AddNumberToObject(root,"error",self.web_error.load());
   char* json=cJSON_PrintUnformatted(root);auto out=Reply(req,json?json:"{}");free(json);cJSON_Delete(root);return out;
  }
  const auto data=Body(req);auto root=cJSON_Parse(data.c_str());auto on=cJSON_GetObjectItem(root,"on");
  if(!cJSON_IsBool(on)){cJSON_Delete(root);return Reply(req,"{\"ok\":false,\"error\":\"参数不正确\"}",400);}
  bool want=cJSON_IsTrue(on);cJSON_Delete(root);
  auto result=Reply(req,"{\"ok\":true}");
  self.OpenAPAsync(want);
  return result;
 }
 if(path=="/api/status"){
  // Counters only: audio content is never exposed by the diagnostic endpoint.
  auto root=cJSON_CreateObject();cJSON_AddBoolToObject(root,"connected",desktop_network.load());cJSON_AddNumberToObject(root,"volume",self.codec.audio.volume());cJSON_AddNumberToObject(root,"mic_frames",self.codec.mic_frames.load());cJSON_AddNumberToObject(root,"mic_errors",self.codec.mic_errors.load());cJSON_AddNumberToObject(root,"mic_peak",self.codec.mic_peak.load());cJSON_AddNumberToObject(root,"mic_frame_us",self.codec.mic_frame_us.load());
  cJSON_AddNumberToObject(root,"mic_samples",self.codec.mic_samples.load());cJSON_AddNumberToObject(root,"output_samples",self.codec.output_samples.load());cJSON_AddNumberToObject(root,"output_peak",self.codec.output_peak.load());
  {std::lock_guard<std::recursive_mutex> lock(self.display.mutex);cJSON_AddStringToObject(root,"status",self.display.status.c_str());
   if(Application::GetInstance().GetDeviceState()==kDeviceStateActivating)cJSON_AddStringToObject(root,"connection_detail",self.display.chat.c_str());}
  cJSON_AddNumberToObject(root,"mic_hardware_rate",self.codec.input_sample_rate());
  cJSON_AddNumberToObject(root,"uptime_ms",esp_timer_get_time()/1000);
  cJSON_AddNumberToObject(root,"reset_reason",static_cast<int>(esp_reset_reason()));
  cJSON_AddNumberToObject(root,"ui_loops",self.ui_loops.load());
  cJSON_AddNumberToObject(root,"ui_gap_us",self.ui_gap_us.load());
  cJSON_AddNumberToObject(root,"ui_max_gap_us",self.ui_max_gap_us.load());
  cJSON_AddNumberToObject(root,"render_us",self.render_us.load());
  cJSON_AddNumberToObject(root,"page",desktop_page.load());
  cJSON_AddBoolToObject(root,"radio_running",self.radio.running());
  cJSON_AddNumberToObject(root,"radio_tasks",self.radio.active_tasks());
  cJSON_AddNumberToObject(root,"voice_tasks",Application::GetInstance().GetAudioService().ActiveTasks());
  cJSON_AddBoolToObject(root,"voice_stopped",Application::GetInstance().DesktopVoiceStopped());
  cJSON_AddBoolToObject(root,"radio_paused",self.radio.paused());
  cJSON_AddNumberToObject(root,"radio_state",static_cast<int>(self.radio.state()));
  cJSON_AddNumberToObject(root,"radio_station",self.radio.station_index());
  cJSON_AddNumberToObject(root,"radio_pcm_bytes",self.radio.pcm_available());
  cJSON_AddNumberToObject(root,"heap_internal",heap_caps_get_free_size(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT));
  cJSON_AddNumberToObject(root,"heap_largest_internal",heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT));
  cJSON_AddNumberToObject(root,"state",Application::GetInstance().GetDeviceState());
  cJSON_AddNumberToObject(root,"key_polls",self.codec.audio.key_polls());
  cJSON_AddNumberToObject(root,"keys",self.codec.audio.cached_keys());
  esp_netif_ip_info_t ip={};auto netif=esp_netif_get_handle_from_ifkey("WIFI_STA_DEF");char text[24]={};if(netif&&esp_netif_get_ip_info(netif,&ip)==ESP_OK)snprintf(text,sizeof(text),IPSTR,IP2STR(&ip.ip));cJSON_AddStringToObject(root,"ip",text);
  {
   esp_netif_ip_info_t ap_ip={};auto ap=esp_netif_get_handle_from_ifkey("WIFI_AP_DEF");
   char ap_text[24]={};
   if(ap&&esp_netif_get_ip_info(ap,&ap_ip)==ESP_OK)snprintf(ap_text,sizeof(ap_text),IPSTR,IP2STR(&ap_ip.ip));
   cJSON_AddBoolToObject(root,"ap_enabled",self.ap_enabled.load());
   cJSON_AddBoolToObject(root,"ap_live",self.ap_live.load());
   cJSON_AddStringToObject(root,"ap_ip",ap_text);
   cJSON_AddBoolToObject(root,"ap_dhcp",self.ap_dhcp.load());
   cJSON_AddBoolToObject(root,"ap_lease",self.ap_lease.load());
   cJSON_AddBoolToObject(root,"ap_netif_up",self.ap_netif_up.load());
   cJSON_AddNumberToObject(root,"ap_channel",self.ap_chan.load());
   cJSON_AddNumberToObject(root,"ap_dhcp_err",self.ap_dhcp_err.load());
   {wifi_mode_t m=WIFI_MODE_NULL;esp_wifi_get_mode(&m);cJSON_AddNumberToObject(root,"wifi_mode",(int)m);}
   cJSON_AddNumberToObject(root,"heap_internal",
       (int)heap_caps_get_free_size(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT));
   cJSON_AddBoolToObject(root,"ap_busy",self.ap_busy.load());
   cJSON_AddNumberToObject(root,"web_error",self.web_error.load());
   cJSON_AddBoolToObject(root,"web_ready",self.server!=nullptr);
   cJSON_AddNumberToObject(root,"http_requests",self.http_requests.load());
   cJSON_AddStringToObject(root,"http_last",self.http_last_path.c_str());
  }
  time_t now=time(nullptr);tm local={};localtime_r(&now,&local);char timestamp[32];strftime(timestamp,sizeof(timestamp),"%Y-%m-%d %H:%M:%S",&local);cJSON_AddStringToObject(root,"local_time",timestamp);cJSON_AddNumberToObject(root,"utc",static_cast<double>(now));
  {std::lock_guard<std::mutex>lock(self.state_mutex);cJSON_AddBoolToObject(root,"weather_valid",self.have_weather);cJSON_AddStringToObject(root,"city",self.city.c_str());cJSON_AddStringToObject(root,"weather",self.description.c_str());if(self.have_weather)cJSON_AddNumberToObject(root,"temperature",self.temperature);}
  char* json=cJSON_PrintUnformatted(root);auto result=Reply(req,json?json:"{}");free(json);cJSON_Delete(root);return result;
 }
 if(path=="/api/radio"){
  auto root=cJSON_CreateObject();
  cJSON_AddNumberToObject(root,"page",desktop_page.load());
  cJSON_AddNumberToObject(root,"index",self.radio.station_index());
  cJSON_AddNumberToObject(root,"count",self.radio.station_count());
  cJSON_AddStringToObject(root,"name",self.radio.station_name());
  cJSON_AddStringToObject(root,"url",self.radio.station_url());
  cJSON_AddStringToObject(root,"custom_url",self.radio_custom_url.c_str());
  cJSON_AddNumberToObject(root,"state",static_cast<int>(self.radio.state()));
  cJSON_AddNumberToObject(root,"volume",self.codec.audio.volume());
  cJSON_AddBoolToObject(root,"running",self.radio.running());
  // v35：把整份播放列表发出去，网页才能显示"现在有哪些台"并逐条删除。
  {
   auto arr=cJSON_CreateArray();
   const int cnt=self.radio.station_count();
   const int extras=static_cast<int>(self.radio_extra_urls.size());
   for(int i=0;i<cnt;++i){
    auto it=cJSON_CreateObject();
    cJSON_AddNumberToObject(it,"index",i);
    const char* nm=self.radio.station_name_at(i);
    const char* uu=self.radio.station_url_at(i);
    cJSON_AddStringToObject(it,"name",nm?nm:"");
    cJSON_AddStringToObject(it,"url",uu?uu:"");
    cJSON_AddBoolToObject(it,"custom",i<extras);
    cJSON_AddItemToArray(arr,it);
   }
   cJSON_AddNumberToObject(root,"extras",extras);
   cJSON_AddItemToObject(root,"stations",arr);
  }
  if(req->method==HTTP_POST){
   const auto data=Body(req);auto cmd=cJSON_Parse(data.c_str());
   if(cmd){auto a=cJSON_GetObjectItem(cmd,"action");auto v=cJSON_GetObjectItem(cmd,"value");
    if(cJSON_IsString(a)){
     std::string action=a->valuestring;
     if(action=="next")self.radio.NextStation();
     else if(action=="prev")self.radio.PreviousStation();
     else if(action=="play")self.radio.Play();
     else if(action=="pause")self.radio.Pause();
     else if(action=="toggle")self.radio.TogglePlayPause();
     else if(action=="stop")self.radio.Stop();
     else if(action=="volume"&&cJSON_IsNumber(v))self.SetVolume(v->valueint);
     // v35：整份自定义列表替换。value 是多行文本，每行 `名称|地址`；
     // 传空串等于清空。网页那边就是一个文本框，增删都靠编辑它。
     else if(action=="setextras"&&cJSON_IsString(v)){
      self.SetRadioExtras(v->valuestring);
     }
     // v34：自定义电台地址。只认 http(s) 直链，且必须是 MP3（解码器只编了
     // MP3 一种）。传空串即清除自定义台、恢复纯内置列表。
     else if(action=="seturl"&&cJSON_IsString(v)){
      std::string url=v->valuestring;
      auto name_item=cJSON_GetObjectItem(cmd,"name");
      std::string name=cJSON_IsString(name_item)?name_item->valuestring:"";
      while(!url.empty()&&(url.back()==' '||url.back()=='\n'||url.back()=='\r'))url.pop_back();
      const bool plain=url.empty()||url.compare(0,7,"http://")==0||url.compare(0,8,"https://")==0;
      if(plain){
       self.SetRadioCustomUrl(url,name);
      }else{
       cJSON_AddStringToObject(root,"error","地址必须以 http:// 或 https:// 开头");
      }
     }
    }
    cJSON_Delete(cmd);
   }
  }
  char* json=cJSON_PrintUnformatted(root);auto result=Reply(req,json?json:"{}");free(json);cJSON_Delete(root);return result;
 }
 httpd_resp_send_404(req);return ESP_OK;
}
// Answer only the OS connectivity probes with a redirect. A 204 here would tell
// the phone "this network has internet" (no portal sheet); a 302 makes Android,
// iOS and the Chinese ROMs show "sign in to network" and open 192.168.4.1.
// Everything else still 404s - unlike the old blanket "/*" -> 302, this never
// redirects an /api/ call, so the page itself keeps working.
esp_err_t PortalFallback(httpd_req_t* req){
 std::string path=req->uri;auto q=path.find('?');if(q!=std::string::npos)path.resize(q);
 static const char* kProbes[]={"/generate_204","/gen_204","/hotspot-detect.html",
  "/connecttest.txt","/ncsi.txt","/success.txt","/library/test/success.html",
  "/check_network_status.txt","/fwlink","/redirect","/portal","/portal.html"};
 for(auto p:kProbes){
  if(path==p){
   httpd_resp_set_status(req,"302 Found");
   httpd_resp_set_hdr(req,"Location","http://192.168.4.1/");
   httpd_resp_set_hdr(req,"Cache-Control","no-store");
   return httpd_resp_send(req,"",0);
  }
 }
 httpd_resp_send_404(req);return ESP_OK;
}
}
void DesktopRuntime::StartWeb(){
 if(server)return;
 // 8192 B is NOT optional here. Route() builds cJSON trees, std::string paths
 // and snprintf buffers; v18 tried 6144 / 4096 to save internal RAM and the
 // httpd task overflowed its stack on the first real request -> panic reboot.
 // Same failure mode as the 3072 B ap_switch stack in v7. Only ONE start
 // attempt: a second httpd_start() after a partial failure can double-bind
 // port 80, and repeated retries slowly eat the last few KB of internal RAM.
 httpd_config_t cfg=HTTPD_DEFAULT_CONFIG();cfg.max_uri_handlers=20;cfg.stack_size=8192;cfg.recv_wait_timeout=15;cfg.send_wait_timeout=15;
 // 默认是精确匹配，`/*` 会被当成字面量 "/\*" 去比，通配处理器从来不会命中。
 // 手机连上热点后会依次探测 /generate_204、/hotspot-detect.html 之类的地址，
 // 这些请求全部 404 → 系统判定"没有门户" → 页面永远不弹。
 cfg.uri_match_fn=httpd_uri_match_wildcard;
 // 手机探测会同时开好几个连接；socket 用满以后新连接就没人 accept 了，
 // 浏览器表现就是一直转圈。让服务端在满的时候回收最久没动的那个。
 cfg.lru_purge_enable=true;
 cfg.max_open_sockets=6;
 auto err=httpd_start(&server,&cfg);
 if(err!=ESP_OK){
  server=nullptr;
  web_start_err=static_cast<int>(err)&0xFFFF;
  web_error=static_cast<int>(err)&0xFF;
  printf("DESKTOP_WEB start error=%s\n",esp_err_to_name(err));
  return;
 }
 web_start_err=0;
 // 只在服务端自己的错误码上清零；热点启动失败用的是 100+x，别被这里抹掉。
 if(web_error>0&&web_error<100)web_error=0;
 for(const char* path:{"/","/ping","/favicon.ico","/api/weather","/api/regions","/api/wifi","/api/ap","/api/status","/api/radio"}){httpd_uri_t r={};r.uri=path;r.method=HTTP_GET;r.handler=Route;httpd_register_uri_handler(server,&r);}
 for(const char* path:{"/api/weather","/api/wifi","/api/ap","/api/radio"}){httpd_uri_t r={};r.uri=path;r.method=HTTP_POST;r.handler=Route;httpd_register_uri_handler(server,&r);}
 // Registered LAST: httpd walks handlers in registration order, so all exact
 // routes above win and this wildcard is only a fallback for unknown paths.
 // Only the OS probe URLs get a 302; API calls and the page itself are untouched.
 httpd_uri_t portal={};portal.uri="/*";portal.method=HTTP_GET;portal.handler=PortalFallback;
 httpd_register_uri_handler(server,&portal);
}

