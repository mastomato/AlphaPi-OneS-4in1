#pragma once

// AlphaPi One (ESP32-S3) 网络收音机 —— 硬件配置与常量
//
// 独立版：从 xiaozhi-esp32/main/radio/radio_config.h 移植，
// 去掉了对 boards/alphapi/alphapi-s3/config.h 的依赖，硬件参数直接内联。
//
// 硬件参数来源（已实机验证）：
//   main/boards/alphapi/alphapi-s3/config.h（xiaozhi-esp32 项目）

#include <cstddef>
#include <cstdint>
#include <driver/gpio.h>
#include <driver/uart.h>

namespace radio {

// ---------------------------------------------------------------------------
// 独立模式：开机直进收音机（本项目无小智共存，恒为 true）
// ---------------------------------------------------------------------------
constexpr bool kStandaloneMode = true;

// ---------------------------------------------------------------------------
// N32 音频协处理器 UART
// ---------------------------------------------------------------------------
constexpr uart_port_t kUartPort = UART_NUM_1;
constexpr int kUartBaudRate = 460800;
constexpr gpio_num_t kUartTx = GPIO_NUM_3;
constexpr gpio_num_t kUartRx = GPIO_NUM_0;

// 寄存器地址
constexpr uint8_t kRegAudioControl = 0x10;
constexpr uint8_t kRegAudioRead = 0x11;
constexpr uint8_t kRegVolume = 0x14;
constexpr uint8_t kRegStream = 0x15;
constexpr uint8_t kRegKey = 0x00;

// 帧协议
constexpr uint8_t kWritePrefix = 0x90;  // 写寄存器
constexpr uint8_t kWriteAck = 0x91;     // 写应答
constexpr uint8_t kReadPrefix = 0x80;   // 读寄存器
constexpr uint8_t kReadAck = 0x81;      // 读应答
constexpr size_t kMaxPayloadSize = 200;

// ---------------------------------------------------------------------------
// 音频格式
// ---------------------------------------------------------------------------
// N32 的 DAC 实际消费速率是 24000 B/s（8-bit unsigned mono）。
constexpr uint32_t kOutputSampleRate = 24000;

// 缓冲区容量（沿用 One S 已验证的取值）
constexpr size_t kCompressedBufferBytes = 64 * 1024;
constexpr size_t kPcmBufferBytes =
    kOutputSampleRate * sizeof(int16_t) * 3;  // 约 3 秒
constexpr size_t kInitialPrebufferBytes = kPcmBufferBytes / 2;  // 约 1.5 秒
constexpr size_t kRebufferBytes = kOutputSampleRate * sizeof(int16_t) / 2;

constexpr size_t kPlaybackChunkSamples = 480;

// ---------------------------------------------------------------------------
// 音量（ONE 的 N32 固件范围 0..100）
// ---------------------------------------------------------------------------
constexpr int kVolumeMin = 0;
constexpr int kVolumeMax = 100;
constexpr int kDefaultVolume = 67;

// ---------------------------------------------------------------------------
// 按键（ONE 的 4 键全在 N32 寄存器 0x00，通过 UART 读取）
// ---------------------------------------------------------------------------
constexpr uint8_t kKeyMaskA = 0x04;  // bit2
constexpr uint8_t kKeyMaskB = 0x08;  // bit3
constexpr uint8_t kKeyMaskL = 0x02;  // bit1
constexpr uint8_t kKeyMaskR = 0x01;  // bit0

// 按键轮询周期（毫秒）——播放中加快响应
constexpr int kKeyPollIntervalMsIdle = 30;
constexpr int kKeyPollIntervalMsPlaying = 50;

// 播放中允许读键的缓冲水位门槛
constexpr size_t kKeyPollSlackBytes = kPcmBufferBytes / 2;

// 长按判定时长（毫秒）
constexpr int kLongPressMs = 1200;

// ---------------------------------------------------------------------------
// ST7789 显示屏（SPI）
// ---------------------------------------------------------------------------
constexpr int kDisplaySck = 37;
constexpr int kDisplayMosi = 38;
constexpr int kDisplayMiso = 45;
constexpr int kDisplayCs = 34;
constexpr int kDisplayDc = 36;
constexpr int kDisplayReset = 35;
constexpr int kDisplayBacklight = 33;
constexpr int kDisplayWidth = 160;   // 逻辑宽（旋转后）
constexpr int kDisplayHeight = 128;  // 逻辑高

// ---------------------------------------------------------------------------
// 电台表容量
// ---------------------------------------------------------------------------
constexpr int kMaxStations = 64;
constexpr int kStationNameBytes = 40;
constexpr int kStationUrlBytes = 224;

// ---------------------------------------------------------------------------
// 播放器状态
// ---------------------------------------------------------------------------
enum class PlayerState {
    kIdle,
    kConnecting,
    kBuffering,
    kPlaying,
    kPaused,
    kReconnecting,
    kError,
};

struct Station {
    char name[kStationNameBytes];
    char url[kStationUrlBytes];
};

// ---------------------------------------------------------------------------
// 默认电台表（2026-10-31 全部逐台实测 HTTP 200 + audio/mpeg）
// 注意：解码器硬编码为 MP3（ESP_AUDIO_SIMPLE_DEC_TYPE_MP3），
// AAC / HLS(.m3u8) / Ogg 全部不可用；故国际主流台（BBC/VOA/RTHK/
// 台湾各台等）因 AAC/HLS 或国内网络不可达无法入表，
// 已纳入可达的 RFI 中文与 AsiaFM 亚洲天空台作为国际/港澳代表。
// 顺序：济南本地（6）→ 山东省内（11）→ 国内央广/直辖市/重点省（31）
// → 国际港澳与特色音乐（5）。用户要求济南台放前面。
// 台名均为蜻蜓真实频道名。
// ---------------------------------------------------------------------------
inline const Station kDefaultStations[] = {
    // ===== 济南本地（最前） =====
    {"济南故事广播", "http://lhttp.qtfm.cn/live/1672/64k.mp3"},
    {"济南新闻广播", "http://lhttp.qtfm.cn/live/1667/64k.mp3"},
    {"济南经济广播", "http://lhttp.qtfm.cn/live/1668/64k.mp3"},
    {"济南交通广播", "http://lhttp.qtfm.cn/live/1669/64k.mp3"},
    {"936私家车广播", "http://lhttp.qtfm.cn/live/1670/64k.mp3"},
    {"济南音乐广播", "http://lhttp.qtfm.cn/live/1671/64k.mp3"},
    // ===== 山东省内 =====
    {"山东综合广播", "http://lhttp.qtfm.cn/live/20234/64k.mp3"},
    {"山东文艺广播", "http://lhttp.qtfm.cn/live/20238/64k.mp3"},
    {"山东经济广播", "http://lhttp.qtfm.cn/live/20236/64k.mp3"},
    {"山东经典音乐广播", "http://lhttp.qtfm.cn/live/20240/64k.mp3"},
    {"济宁交通文艺广播", "http://lhttp.qtfm.cn/live/20087/64k.mp3"},
    {"临沂交通旅游广播", "http://lhttp.qtfm.cn/live/3993/64k.mp3"},
    {"东营交通音乐广播", "http://lhttp.qingting.fm/live/20142/64k.mp3"},
    {"东营综合广播", "http://lhttp.qingting.fm/live/20144/64k.mp3"},
    {"青岛交通广播", "http://lhttp.qingting.fm/live/1676/64k.mp3"},
    {"青岛经济广播", "http://lhttp.qingting.fm/live/1674/64k.mp3"},
    {"聊城经济广播", "http://lhttp.qtfm.cn/live/5022262/64k.mp3"},
    // ===== 央广 / 北京 / 天津 =====
    {"中国之声", "http://lhttp.qtfm.cn/live/15318317/64k.mp3"},
    {"北京新闻广播", "http://lhttp.qtfm.cn/live/339/64k.mp3"},
    {"北京交通广播", "http://lhttp.qingting.fm/live/336/64k.mp3"},
    {"北京音乐广播", "http://lhttp.qtfm.cn/live/332/64k.mp3"},
    {"北京文艺广播", "http://lhttp.qtfm.cn/live/333/64k.mp3"},
    {"天津新闻广播", "http://lhttp-hw.qtfm.cn/live/5022134/64k.mp3"},
    {"天津经济广播", "http://lhttp-hw.qtfm.cn/live/15318227/64k.mp3"},
    // ===== 上海 =====
    {"上海新闻广播", "http://lhttp.qingting.fm/live/270/64k.mp3"},
    {"上海交通广播", "http://lhttp.qingting.fm/live/266/64k.mp3"},
    {"上海音乐广播", "http://lhttp.qingting.fm/live/273/64k.mp3"},
    {"上海经典音乐广播", "http://lhttp.qingting.fm/live/267/64k.mp3"},
    {"上海流行音乐动感101", "http://lhttp-hw.qtfm.cn/live/274/64k.mp3"},
    {"上海第一财经广播", "http://lhttp-hw.qtfm.cn/live/276/64k.mp3"},
    {"上海戏剧曲艺广播", "http://lhttp.qingting.fm/live/269/64k.mp3"},
    // ===== 其他重点省台 =====
    {"石家庄交通广播", "http://lhttp.qingting.fm/live/1655/64k.mp3"},
    {"辽宁交通广播", "http://lhttp.qtfm.cn/live/20025/64k.mp3"},
    {"辽宁音乐广播", "http://lhttp.qingting.fm/live/1101/64k.mp3"},
    {"辽宁经济广播", "http://lhttp-hw.qtfm.cn/live/20019/64k.mp3"},
    {"江苏财经广播", "http://lhttp.qingting.fm/live/1802/64k.mp3"},
    {"无锡交通广播", "http://lhttp.qingting.fm/live/2780/64k.mp3"},
    {"无锡新闻综合广播", "http://lhttp.qtfm.cn/live/2777/64k.mp3"},
    {"合肥交通信息广播", "http://lhttp-hw.qtfm.cn/live/1960/64k.mp3"},
    {"合肥文艺广播", "http://lhttp-hw.qtfm.cn/live/1975/64k.mp3"},
    {"重庆音乐广播", "http://lhttp.qtfm.cn/live/20176/64k.mp3"},
    {"成都经济广播", "http://lhttp-hw.qtfm.cn/live/1121/64k.mp3"},
    {"云南经济广播", "http://lhttp.qtfm.cn/live/1927/64k.mp3"},
    {"云南音乐广播", "http://lhttp.qtfm.cn/live/1929/64k.mp3"},
    {"湖南潇湘之声", "http://lhttp.qingting.fm/live/20500092/64k.mp3"},
    {"广东珠江经济", "http://lhttp.qtfm.cn/live/1259/64k.mp3"},
    {"深圳新闻广播", "http://lhttp.qingting.fm/live/1270/64k.mp3"},
    {"内蒙古交通之声", "http://lhttp-hw.qtfm.cn/live/1884/64k.mp3"},
    {"商丘综合广播", "http://lhttp-hw.qtfm.cn/live/5022443/24k.mp3"},
    // ===== 国际 / 港澳 / 特色音乐 =====
    {"AsiaFM亚洲天空台", "http://lhttp.qingting.fm/live/20071/64k.mp3"},
    {"法国国际广播电台中文", "https://rfienchinois64k.ice.infomaniak.ch/rfienchinois-64.mp3"},
    {"蜻蜓音乐台", "http://lhttp-hw.qtfm.cn/live/4915/64k.mp3"},
    {"500首华语经典", "http://lhttp.qtfm.cn/live/5022308/64k.mp3"},
    {"中国民乐", "http://radio.chinesemusicworld.com/chinesemusic.mp3"},
};
constexpr int kDefaultStationCount =
    sizeof(kDefaultStations) / sizeof(kDefaultStations[0]);

}  // namespace radio
