#pragma once

// 网络收音机播放器 —— AlphaPi One (ESP32-S3) 移植版
//
// 架构沿用 One S 版已验证的四段流水线（各段独立任务，用 StreamBuffer 串联）：
//
//   NetworkTask  ──compressed_buffer──>  DecoderTask  ──pcm_buffer──>  PlaybackTask
//   (HTTP 收流)      (64KB, PSRAM)      (MP3解码+重采样)  (3秒 PCM)     (写 N32)
//
// 与 One S 版的差异：
//   - 重采样改用自研 Q16 定点插值（q16_resampler.h），
//     不再依赖有跨系转换缺陷的 esp_ae_rate_cvt
//   - 音频输出改用 N32Audio（n32_audio.h）
//   - 去掉了 display / wifi / settings 依赖：
//     屏幕由 xiaozhi 的 Display 管理，Wi-Fi 由 WifiBoard 管理，
//     电台表先用内置的实测列表（后续可接 NVS 让用户自定义）

#include <atomic>
#include <cstdint>

#include "freertos/FreeRTOS.h"
#include "freertos/stream_buffer.h"

#include "n32_audio.h"
#include "q16_resampler.h"
#include "radio_config.h"

namespace radio {

class RadioPlayer {
public:
    RadioPlayer() = default;
    ~RadioPlayer();

    // v36：绑定唯一的 N32Audio 实例（DesktopCodec 里的那一份）。
    // 必须在 Start()/Play() 之前调用，通常由 DesktopRuntime 构造时完成。
    void AttachAudio(N32Audio* audio) { audio_ = audio; }

    // 创建缓冲与任务。Start() 之后默认处于暂停态，需显式 Play()。
    bool Start();
    void Stop();

    void Play();
    void Pause();
    void TogglePlayPause();
    bool paused() const { return paused_.load(); }

    void NextStation();
    void PreviousStation();

    // Switch the source list at runtime (radio stations <-> music tracks).
    // The caller must Stop() before changing the list.
    void SetStationList(const Station* list, int count);

    // volume: 0..100（ONE 的 N32 固件直接接受这个范围）
    void SetVolume(int volume);
    int volume() const { return volume_.load(); }

    PlayerState state() const { return state_.load(); }
    const char* status_text() const { return status_text_; }
    int station_index() const { return station_index_.load(); }
    int station_count() const { return station_count_; }
    const char* station_name() const;
    // 当前电台的流地址（收音机页显示用；越界时返回 ""）
    const char* station_url() const;
    const char* station_url_at(int index) const;
    // For the on-device station list page.
    const char* station_name_at(int index) const;
    void SelectStation(int index);

    // Real PCM loudness (0..100) from the audio output driver, for the UI meter.
    int Level() { return audio_ ? audio_->Level() : 0; }

    bool running() const { return running_.load(); }
    int active_tasks() const { return active_tasks_.load(); }
    // v34：两个流缓冲改为「首次播放时分配、之后一直复用」，不再在退出时
    // 释放。原来退出收音机时会在 UI 任务里删掉 64KB+6KB 的 PSRAM 流缓冲，
    // 只要有一路任务还没真正退出（或用释放后仍被阻塞的缓冲）就是一次
    // use-after-free —— 现象正好是「长按 D 回主页时直接死机」。这两个缓冲
    // 只占 PSRAM，固定复用还能顺便避免反复分配造成的堆碎片。
    void ReleaseStoppedBuffers() {}

    // PCM 缓冲当前可用字节数 / 容量。
    // 按键任务用它判断"现在占用总线读键是否安全"：
    // 缓冲充裕时读键造成的 1ms 空洞无所谓，欠载边缘时绝不能读。
    // xStreamBufferBytesAvailable 可从任意任务调用。
    size_t pcm_available() const;
    size_t pcm_capacity() const { return kPcmBufferBytes; }
    bool HasPlaybackSlack() const {
        return pcm_available() >= kKeyPollSlackBytes;
    }

private:
    void NetworkTask();
    void DecoderTask();
    void PlaybackTask();

    static void NetworkTaskEntry(void* context);
    static void DecoderTaskEntry(void* context);
    static void PlaybackTaskEntry(void* context);

    void SetState(PlayerState state, const char* status);
    void RestartStream();

    StreamBufferHandle_t compressed_buffer_ = nullptr;
    StreamBufferHandle_t pcm_buffer_ = nullptr;

    // v36：**不再自带一个 N32Audio 实例**。
    // 以前这里是 `N32Audio audio_;`，于是系统里有两个 N32Audio 对象：收音机
    // 一个、DesktopCodec 一个，各自记着 configured_（"我已经发过 WAV 头"）。
    // 但物理上只有一个 N32 芯片、只有一个播放状态。任何一方 Stop() 都会把
    // 芯片的播放状态清掉，而另一方的 configured_ 还是 true —— 它接着写 PCM
    // 时就不会再发 WAV 头，芯片把这些字节当废数据丢掉，**一声不响**。
    // 游戏音效/倒计时提示音走的正是 DesktopCodec 那一个，这就是"完全没声音
    // 但也没有任何报错"的结构性原因。改成共用同一个实例。
    N32Audio* audio_ = nullptr;
    Q16Resampler resampler_;

    std::atomic<bool> running_{false};
    std::atomic<bool> starting_{false};
    std::atomic<int> active_tasks_{0};
    std::atomic<bool> paused_{true};
    std::atomic<PlayerState> state_{PlayerState::kIdle};
    const Station* stations_ = kDefaultStations;
    int station_count_ = kDefaultStationCount;
    std::atomic<int> station_index_{0};
    std::atomic<int> volume_{kDefaultVolume};
    std::atomic<uint32_t> generation_{0};

    char status_text_[24] = "WAITING";
};

}  // namespace radio
