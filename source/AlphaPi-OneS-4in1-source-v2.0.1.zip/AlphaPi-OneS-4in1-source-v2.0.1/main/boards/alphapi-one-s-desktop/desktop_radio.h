#pragma once

// 收音机 UI façade（无任务、无缓冲）
//
// DesktopRuntime::radio 是这个类型。它的方法名与 v54 的 RadioPlayer 一一对应，
// 所以 desktop_ui.h / desktop_board.cc / desktop_server.cc 的调用点一处不改。
// 真正干活的是 radio::RadioPlayer 单例（radio_player.h 的三段流水线）。
//
// 这里只多做三件旧调用点依赖的事：
//   1. paused 语义（UI 用 radio.paused() 判断要不要补一个 Play()）。
//   2. HasPlaybackSlack() 以样本数（1.5 s）回答，不再以字节水位回答。
//   3. status_text() 的生命周期由播放器保证，这里直接透传。

#include <cstddef>
#include <cstdint>

#include "desktop_audio.h"
#include "radio_config.h"
#include "radio_player.h"

namespace radio {

class DesktopRadio {
public:
    // 兼容入口：音频由 AudioUart 单例直接持有，无需绑定。保留以便构造函数
    // 里的 `radio.AttachAudio(&codec.audio)` 一行不改。
    void AttachAudio(AudioBus*) {}

    // 建缓冲 + 建任务（幂等）。成功即可后续 Play()。
    bool Start();
    void Stop();

    void Play();
    void Pause();
    void TogglePlayPause();
    // 暂停语义只在 RadioPlayer 一处维护：UI 用 radio.paused() 判断要不要补一个 Play()。
    bool paused() const { return RadioPlayer::Instance().paused(); }

    void NextStation();
    void PreviousStation();
    void SelectStation(int index);

    // 必须在 Stop() 之后调用；内容由播放器复制进自己的 PSRAM 池。
    void SetStationList(const Station* list, int count);

    void SetVolume(int volume);
    int volume() const { return RadioPlayer::Instance().volume(); }

    PlayerState state() const { return RadioPlayer::Instance().state(); }
    const char* status_text() const { return RadioPlayer::Instance().status_text(); }

    int station_index() const { return RadioPlayer::Instance().index(); }
    int station_count() const { return RadioPlayer::Instance().count(); }
    const char* station_name() const { return RadioPlayer::Instance().name(); }
    const char* station_name_at(int index) const { return RadioPlayer::Instance().name_at(index); }
    const char* station_url() const { return RadioPlayer::Instance().url(); }
    const char* station_url_at(int index) const { return RadioPlayer::Instance().url_at(index); }

    int Level() { return RadioPlayer::Instance().Level(); }

    bool running() const { return RadioPlayer::Instance().running(); }
    // 仍在拉流的三段任务的个数；GoTo() 用它决定何时可以安全切到小智页。
    int active_tasks() const { return RadioPlayer::Instance().active_tasks(); }

    RadioPlayer::Stats stats() const { return RadioPlayer::Instance().stats(); }

    // PCM 环可用量（**样本**，1 s = 24000）。/api/status 的 radio_pcm_bytes
    // 一直报这个量，脚本按「越大越充裕」使用，不需要改。
    size_t pcm_available() const { return RadioPlayer::Instance().pcm_available(); }
    size_t pcm_capacity() const { return RadioPlayer::Instance().pcm_capacity(); }
    bool HasPlaybackSlack() const {
        return pcm_available() >= kOutputSampleRate * 3 / 2;
    }

    // v34 教训：退出时释放流缓冲会造成 use-after-free。缓冲一次性申请、
    // 长期复用，本函数恒为空，保留只为兼容调用点。
    void ReleaseStoppedBuffers() {}
};

}  // namespace radio
