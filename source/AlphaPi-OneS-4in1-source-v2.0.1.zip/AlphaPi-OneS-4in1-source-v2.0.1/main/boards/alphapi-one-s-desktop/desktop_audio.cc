#include "desktop_audio.h"

#include <algorithm>
#include <cmath>
#include <cstring>

#include "esp_log.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "freertos/task.h"

#include "board_config.h"
#include "desktop_runtime.h"
#include "desktop_sfx.h"

namespace radio {

// ---------------------------------------------------------------------------
// AudioBus：零状态转发壳
// ---------------------------------------------------------------------------
bool AudioBus::Init() {
    const bool uart_ok = AudioUart::Instance().Init();
    DesktopKeys::Instance().Init();
    return uart_ok;
}

void AudioBus::Start() { AudioUart::Instance().InvalidateStream(); }

void AudioBus::Stop() {
    // 先让音效任务退出，再让协处理器离开播放/录音态：反过来的话音效任务
    // 会在 StopRecord 之后立刻把会话又开起来。
    desktop_audio::SfxChannel::Instance().Stop();
    AudioUart::Instance().StopRecord();
}

void AudioBus::SetVolume(int volume) { AudioUart::Instance().SetVolume(volume); }

int AudioBus::Write(const int16_t* samples, int count) {
    return AudioUart::Instance().Write(samples, count);
}

int AudioBus::ReadMic(int16_t* samples, int count) {
    return AudioUart::Instance().Read(samples, count);
}

int AudioBus::Level() { return AudioUart::Instance().Level(); }

void AudioBus::InvalidateStream() { AudioUart::Instance().InvalidateStream(); }

void AudioBus::Beep(int freq, int ms, int type) {
    desktop_audio::SfxChannel::Instance().Beep(freq, ms, type);
}

void AudioBus::PlayPcm(const uint8_t* pcm, size_t bytes, int tail_ms) {
    desktop_audio::SfxChannel::Instance().PlayPcm(pcm, bytes, tail_ms);
}

void AudioBus::KeepAlive(bool on) {
    desktop_audio::SfxChannel::Instance().KeepAlive(on);
}

void AudioBus::ClickStream(bool on, int accent, int weak, int tone_ms,
                           int period_ms, int bar) {
    desktop_audio::SfxChannel::Instance().ClickStream(on, accent, weak, tone_ms,
                                                      period_ms, bar);
}

void AudioBus::SetClickPcm(const uint8_t* accent, size_t accent_bytes,
                           const uint8_t* weak, size_t weak_bytes) {
    desktop_audio::SfxChannel::Instance().SetClickPcm(accent, accent_bytes, weak,
                                                     weak_bytes);
}

void AudioBus::StopBeepTask() { desktop_audio::SfxChannel::Instance().Stop(); }

int AudioBus::beep_fail_count() const {
    return desktop_audio::SfxChannel::Instance().fail_count();
}

uint32_t AudioBus::sfx_lead_ins() const {
    return desktop_audio::SfxChannel::Instance().lead_ins();
}

uint8_t AudioBus::ReadKeys() { return DesktopKeys::Instance().Read(); }

uint32_t AudioBus::key_polls() const { return DesktopKeys::Instance().polls(); }

uint8_t AudioBus::cached_keys() const { return DesktopKeys::Instance().cached(); }

}  // namespace radio

namespace desktop_audio {

using radio::AudioUart;

namespace {
constexpr char kTag[] = "DesktopSfx";
}  // namespace

SfxChannel& SfxChannel::Instance() {
    static SfxChannel instance;
    return instance;
}

bool SfxChannel::Start() {
    return EnsureTask() != nullptr;
}

void SfxChannel::Stop() {
    // 置标志与取句柄必须在同一把锁里，否则任务可能正好自删并把句柄清空，
    // 这里的 load 读到旧值，xTaskNotifyGive 打在已释放的 TCB 上。
    auto mux = static_cast<SemaphoreHandle_t>(mux_);
    if (mux == nullptr) {
        stop_.store(true);  // 任务还没创建过：只留标志，下次创建时清掉
        return;
    }
    xSemaphoreTake(mux, portMAX_DELAY);
    stop_.store(true);
    void* t = task_.load();
    xSemaphoreGive(mux);
    if (t == nullptr) return;  // 已自行退出，没有需要唤醒的对象
    xTaskNotifyGive(static_cast<TaskHandle_t>(t));
    // 最多等 30ms：任务自己 vTaskDelete，绝不 join，也绝不阻塞 UI 太久。
    for (int i = 0; i < 30 && task_.load() != nullptr; ++i) {
        vTaskDelay(1);
    }
}
int SfxChannel::Write(const int16_t* samples, int count) {
    return AudioUart::Instance().Write(samples, count);
}
void SfxChannel::TaskThunk(void* arg) {
    static_cast<SfxChannel*>(arg)->Worker();
}

void SfxChannel::Worker() {
    // 三种工作状态按优先级串在一个循环里：
    //   1) 有新的单次音效（sfx_seq_ 变了）→ 播它
    //   2) 节拍器连续流开着 → ClickLoop
    //   3) 常开底流开着 → IdleLoop（写静音，边写边看有没有新请求）
    //   4) 都不满足 → 等通知，空闲 3 秒自行退出
    for (;;) {
        if (stop_.load()) {
            // 退出功能页：先收流再清句柄，最后删自己。KeepAlive 必须一起关，
            // 否则重新进页面时任务会带着旧状态继续写静音。
            click_on_.store(false);
            keep_on_.store(false);
            stop_.store(false);
            busy_.store(false);
            auto mux = static_cast<SemaphoreHandle_t>(mux_);
            if (mux) xSemaphoreTake(mux, portMAX_DELAY);
            task_.store(nullptr);
            if (mux) xSemaphoreGive(mux);
            vTaskDelete(nullptr);
            return;
        }

        const uint32_t seq = sfx_seq_.load(std::memory_order_acquire);
        if (seq != sfx_done_.load()) {
            // 先记已播再播：播放期间来的新请求（seq 又变了）下一轮还能看到。
            sfx_done_.store(seq);
            busy_.store(true);
            owner_.store(1);
            if (kind_.load(std::memory_order_acquire) == 1) {
                PlayClip(pcm_src_.load(), pcm_bytes_.load(), pcm_tail_ms_.load());
            } else {
                PlayBeep(req_.load(std::memory_order_relaxed));
            }
            busy_.store(false);
            owner_.store(0);
            continue;
        }

        if (click_on_.load()) {
            owner_.store(3);
            ClickLoop();
            // 流期间攒下的通知和那一次单音效请求都作废，否则收流之后
            // 会突然把上一次的音效（甚至很早以前的）补播一遍。
            (void)ulTaskNotifyTake(pdTRUE, 0);
            sfx_done_.store(sfx_seq_.load());
            owner_.store(0);
            continue;
        }

        if (keep_on_.load()) {
            owner_.store(2);
            IdleLoop();
            owner_.store(0);
            continue;
        }

        // 空闲 3 秒 or 页面退出 -> 任务自行结束并清掉句柄。
        const uint32_t got = ulTaskNotifyTake(pdTRUE, pdMS_TO_TICKS(3000));
        if (got == 0) {
            stop_.store(true);
        }
    }
}

bool SfxChannel::WriteSilence(int ms) {
    if (ms <= 0) return true;
    constexpr int kBlockSamples = 200;
    int16_t quiet[kBlockSamples] = {};
    size_t left = static_cast<size_t>(ms) * board::kAudioSampleRate / 1000;
    while (left > 0) {
        const size_t n = std::min<size_t>(kBlockSamples, left);
        if (Write(quiet, static_cast<int>(n)) <= 0) {
            fail_.fetch_add(1);
            return false;
        }
        left -= n;
    }
    return true;
}

bool SfxChannel::NeedsSession() const { return AudioUart::Instance().session_stale(); }

void SfxChannel::IdleLoop() {
    constexpr int kBlockSamples = 200;
    int16_t quiet[kBlockSamples] = {};
    const int sr = static_cast<int>(board::kAudioSampleRate);
    // 底流启动时先看会话状态。凉的（换页超过 500ms / 从未开过）必须垫上
    // 吞音窗口的静音，否则第一段数据落在 N32 的预缓冲丢弃窗口里。
    if (NeedsSession()) {
        if (!WriteSilence(board::kStreamLeadInMs)) {
            keep_on_.store(false);
            vTaskDelay(pdMS_TO_TICKS(150));
            return;
        }
        lead_ins_.fetch_add(1);
    }
    int64_t start_us = esp_timer_get_time();
    int64_t written = 0;
    busy_.store(true);
    while (keep_on_.load() && !stop_.load() &&
           sfx_seq_.load() == sfx_done_.load() && !click_on_.load()) {
        const int64_t now_us = esp_timer_get_time();
        const int64_t due = (now_us - start_us) * sr / 1000000;
        int64_t behind = due - written;
        if (behind > sr / 12) {
            // 重新锚定时钟基准，不追补、不跳相位。一口气补半秒会把 N32
            // 接收缓冲灌满。
            start_us = now_us - written * 1000000 / sr;
            behind = 0;
        }
        if (behind < kBlockSamples) {
            vTaskDelay(1);  // CONFIG_FREERTOS_HZ=1000：1ms
            continue;
        }
        // 一次最多 2 块，避免长时间追赶灌缓冲。
        int blocks = static_cast<int>(std::min<int64_t>(behind / kBlockSamples, 2));
        while (blocks-- > 0) {
            if (Write(quiet, kBlockSamples) <= 0) {
                fail_.fetch_add(1);
                keep_on_.store(false);
                vTaskDelay(pdMS_TO_TICKS(150));
                busy_.store(false);
                return;
            }
            written += kBlockSamples;
        }
    }
    busy_.store(false);
}

void SfxChannel::KeepAlive(bool on) {
    if (keep_on_.exchange(on) == on) return;  // 状态没变，省掉空通知开销
    void* task = EnsureTask();
    if (task == nullptr) {
        keep_on_.store(false);
        return;
    }
    xTaskNotifyGive(static_cast<TaskHandle_t>(task));
}

void SfxChannel::Beep(int freq, int ms, int type) {
    if (freq <= 0 || ms <= 0) return;
    // 覆盖式投递：游戏里连击/碰撞连续触发，后来的顶掉前一个，至少最后
    // 一次一定响。
    const uint32_t req = (static_cast<uint32_t>(freq & 0x3FFF) << 18) |
                         (static_cast<uint32_t>(ms & 0x3FF) << 8) |
                         static_cast<uint32_t>(type & 0xFF);
    req_.store(req, std::memory_order_relaxed);
    kind_.store(0, std::memory_order_release);
    (void)sfx_seq_.fetch_add(1, std::memory_order_release);
    void* task = EnsureTask();
    if (task == nullptr) return;
    xTaskNotifyGive(static_cast<TaskHandle_t>(task));
}

void SfxChannel::PlayPcm(const uint8_t* pcm, size_t bytes, int tail_ms) {
    if (pcm == nullptr || bytes == 0) return;
    pcm_src_.store(pcm, std::memory_order_relaxed);
    pcm_bytes_.store(bytes, std::memory_order_relaxed);
    pcm_tail_ms_.store(tail_ms >= 0 ? tail_ms : 60, std::memory_order_relaxed);
    kind_.store(1, std::memory_order_release);
    (void)sfx_seq_.fetch_add(1, std::memory_order_release);
    void* task = EnsureTask();
    if (task == nullptr) return;
    xTaskNotifyGive(static_cast<TaskHandle_t>(task));
}

void SfxChannel::SetClickPcm(const uint8_t* accent, size_t accent_bytes,
                           const uint8_t* weak, size_t weak_bytes) {
    click_accent_pcm_.store(accent, std::memory_order_relaxed);
    click_accent_bytes_.store(accent_bytes, std::memory_order_relaxed);
    click_weak_pcm_.store(weak, std::memory_order_relaxed);
    click_weak_bytes_.store(weak_bytes, std::memory_order_relaxed);
}

void* SfxChannel::EnsureTask() {
    if (!mux_) mux_ = xSemaphoreCreateMutex();
    auto mux = static_cast<SemaphoreHandle_t>(mux_);
    if (mux) xSemaphoreTake(mux, portMAX_DELAY);
    void* task = task_.load();
    if (task == nullptr) {
        TaskHandle_t handle = nullptr;
        // Must clear stop_ here: StopBeepTask() sets it, and a fresh task
        // would otherwise treat it as "quit now" and stay silent forever.
        stop_.store(false);
        busy_.store(false);
        // Priority 6 is above the UI task (5) on purpose: one 200 byte frame is
        // an 8.3 ms synchronous transaction, and a UI that redraws every 12 ms
        // would otherwise delay every ack wake-up by 5-12 ms and push the feed
        // rate below 24 kHz. Blocking on the ack yields the CPU anyway, so the
        // UI still gets served.
        if (xTaskCreate(&SfxChannel::TaskThunk, "desktop_sfx", 4096, this, 6,
                        &handle) != pdPASS) {
            if (mux) xSemaphoreGive(mux);
            fail_.fetch_add(1);
            ESP_LOGW(kTag, "sfx task create failed (out of memory)");
            return nullptr;
        }
        task_.store(handle);
        task = handle;
    }
    if (mux) xSemaphoreGive(mux);
    return task;
}

void SfxChannel::ClickStream(bool on, int accent_freq, int weak_freq, int tone_ms,
                           int period_ms, int beats_per_bar) {
    // Parameters land first: start, retune and stop all read the latest values.
    click_accent_.store(accent_freq > 0 ? accent_freq : 1568);
    click_weak_.store(weak_freq > 0 ? weak_freq : 1047);
    click_tone_ms_.store(tone_ms > 0 ? tone_ms : 90);
    click_period_ms_.store(period_ms > 0 ? period_ms : 500);
    click_bar_.store(beats_per_bar > 0 ? beats_per_bar : 4);
    if (!on) {
        // Only a real on -> off transition needs a wake-up; the UI calls this
        // every 20 ms and most calls are no-ops.
        if (click_on_.exchange(false)) {
            void* t = task_.load();
            if (t != nullptr) xTaskNotifyGive(static_cast<TaskHandle_t>(t));
        }
        return;
    }
    if (click_on_.exchange(true)) return;  // already running: params updated
    // Drop any pending one-shot so the metronome does not replay it.
    req_.store(0, std::memory_order_relaxed);
    void* task = EnsureTask();
    if (task == nullptr) {
        click_on_.store(false);
        return;
    }
    xTaskNotifyGive(static_cast<TaskHandle_t>(task));
}
void SfxChannel::ClickLoop() {
    const int sr = static_cast<int>(board::kAudioSampleRate);
    constexpr int kBlockSamples = 200;  // one UART frame = 200 samples = 8.3 ms
    int16_t block[kBlockSamples];
    const int fade = sr / 200;  // 5 ms fade in/out kills the click of each beat
    // A cold session (just booted / just came back from another page) swallows
    // the first 100-150 ms, so the first beats would be lost. Pad lead-in
    // silence only when the session really has to be reopened.
    if (NeedsSession()) {
        if (!WriteSilence(board::kStreamLeadInMs)) {
            click_on_.store(false);
            vTaskDelay(pdMS_TO_TICKS(150));
            return;
        }
        lead_ins_.fetch_add(1);
    }
    // Rate is locked by N32's accepted backpressure, not by a wall clock: the
    // ESP32 and the N32 DAC crystals drift by ppm, so a host-driven timeline
    // always ends up either flooding or starving after tens of seconds. The
    // wall clock below only guards against unbounded pre-generation.
    int64_t start_us = esp_timer_get_time();
    int64_t written = 0;
    const AudioUart::Stats stats_at_start = AudioUart::Instance().stats();
    int heal_failures = 0;
    busy_.store(true);
    while (click_on_.load() && !stop_.load()) {
        const int64_t now_us = esp_timer_get_time();
        const int64_t due = (now_us - start_us) * sr / 1000000;
        // Watchdog only: ahead of schedule by more than 0.5 s means an ack went
        // missing and the loop is running free. Wait rather than keep pushing,
        // otherwise a stop leaves seconds of audio queued up.
        if (written > due + sr / 2) {
            vTaskDelay(1);
            continue;
        }
        // The host was blocked for a long time: re-anchor the internal clock only,
        // keeping written untouched and skipping no beats.
        if (due > written + 2 * sr) {
            start_us = now_us - static_cast<int64_t>(written) * 1000000 / sr;
        }
        // Exactly one block per pass. Filling 2-4 blocks per pass only floods
        // the N32 receive buffer, which drifts in one direction on long runs.
        int blocks = 1;
        while (blocks-- > 0 && click_on_.load() && !stop_.load()) {
            const int period_ms = std::max(60, click_period_ms_.load());
            const int bar = std::max(1, click_bar_.load());
            const int period = std::max(sr / 10, sr * period_ms / 1000);
            int tone = sr * std::max(10, click_tone_ms_.load()) / 1000;
            const int min_gap = sr / 50;  // 20 ms of silence between beats
            if (tone > period - min_gap) tone = std::max(sr / 50, period - min_gap);
            const uint8_t* apcm = click_accent_pcm_.load();
            const size_t alen = click_accent_bytes_.load();
            const uint8_t* wpcm = click_weak_pcm_.load();
            const size_t wlen = click_weak_bytes_.load();
            for (int i = 0; i < kBlockSamples; ++i) {
                const int64_t p = written + i;
                const int pos = static_cast<int>(p % period);
                float v = 0.0f;
                if (pos < tone) {
                    const int beat = static_cast<int>((p / period) % bar);
                    const uint8_t* src = (beat == 0) ? apcm : wpcm;
                    const size_t slen = (beat == 0) ? alen : wlen;
                    if (src != nullptr && slen > 0) {
                        // Assets are mmap'd, so they cost no RAM. The file
                        // carries its own envelope; when it is shorter than one
                        // beat the rest is silence.
                        if (static_cast<size_t>(pos) < slen) {
                            block[i] = static_cast<int16_t>(
                                (static_cast<int>(src[pos]) - 128) * 256);
                        } else {
                            block[i] = 0;
                        }
                        continue;
                    }
                    // No asset (older resource pack): fall back to a square wave
                    // so the metronome still ticks. First beat of a bar is an
                    // octave up, audible without looking at the screen.
                    const int freq = (beat == 0) ? click_accent_.load() : click_weak_.load();
                    const float t = static_cast<float>(pos) / static_cast<float>(sr);
                    const float ph = std::fmod(t * static_cast<float>(freq), 1.0f);
                    v = ph < 0.5f ? 0.92f : -0.92f;
                    if (pos < fade) {
                        v *= static_cast<float>(pos) / static_cast<float>(fade);
                    } else if (pos > tone - fade) {
                        v *= static_cast<float>(tone - pos) / static_cast<float>(fade);
                    }
                }
                block[i] = static_cast<int16_t>(v * 20000.0f);
            }
            const int wrote = Write(block, kBlockSamples);
            if (wrote != kBlockSamples) {
                // A single failed write must not stop the whole stream: the UI
                // calls ClickStream(true) again every 20 ms, and every restart
                // costs a re-handshake plus the 240 ms lead-in. Instead the
                // header cache is invalidated here and the next write reopens
                // the session by itself, keeping the beat phase intact.
                fail_.fetch_add(1);
                AudioUart::Instance().InvalidateStream();
                if (!WriteSilence(board::kStreamLeadInMs)) {
                    if (++heal_failures >= 10) {
                        ESP_LOGW(kTag, "metronome link failed 10 times, stopping");
                        click_on_.store(false);
                    }
                    vTaskDelay(pdMS_TO_TICKS(150));
                } else {
                    heal_failures = 0;
                }
                break;  // return to the pacing loop instead of rewriting this block
            }
            heal_failures = 0;
            written += kBlockSamples;
            // game_beep runs above the UI, and an ack already sitting in the FIFO
            // means this loop may never block; yield so LVGL is not starved.
            // Actual rate is still set by N32's accepted backpressure.
            vTaskDelay(1);
        }
    }
    // One summary line at stop time, never periodically: a synchronous log line
    // costs about 10 ms, longer than the 8.3 ms frame it would interrupt.
    const AudioUart::Stats stats_at_end = AudioUart::Instance().stats();
    ESP_LOGI(kTag,
             "metro stop written=%lld stalls=%u resets=%u ackfail=%u gaps=%u fails=%d",
             static_cast<long long>(written),
             static_cast<unsigned>(stats_at_end.stalls - stats_at_start.stalls),
             static_cast<unsigned>(stats_at_end.stream_resets - stats_at_start.stream_resets),
             static_cast<unsigned>(stats_at_end.ack_failures - stats_at_start.ack_failures),
             static_cast<unsigned>(stats_at_end.stream_gaps - stats_at_start.stream_gaps),
             fail_.load());
    busy_.store(false);
}

void SfxChannel::PlayClip(const uint8_t* pcm, size_t bytes, int tail_ms) {
    if (pcm == nullptr || bytes == 0) return;
    // Decide *before* handshaking whether this will reopen the playback
    // session: every reopen swallows the first 100-150 ms while the N32 fills
    // its receive buffer. Padding lead-in silence is what makes a short sound
    // land where it is actually audible.
    const bool fresh = NeedsSession();
    if (fresh && !WriteSilence(board::kStreamLeadInMs)) return;
    if (fresh) lead_ins_.fetch_add(1);
    // 8-bit unsigned -> 16-bit signed. Write() converts back with
    // (s + 32768 + 128) >> 8, so (u8 - 128) * 256 round-trips exactly.
    int16_t block[200];
    constexpr int kBlockSamples = 200;
    size_t done = 0;
    while (done < bytes) {
        const size_t n = std::min<size_t>(kBlockSamples, bytes - done);
        for (size_t i = 0; i < n; ++i) {
            block[i] = static_cast<int16_t>((static_cast<int>(pcm[done + i]) - 128) * 256);
        }
        if (Write(block, static_cast<int>(n)) <= 0) {
            fail_.fetch_add(1);
            ESP_LOGW(kTag, "sfx write failed (asset, %u/%u B)", (unsigned)done,
                     (unsigned)bytes);
            AudioUart::Instance().InvalidateStream();
            return;
        }
        done += n;
    }
    // Trailing silence so the stream does not stop in the middle of a waveform.
    (void)WriteSilence(tail_ms > 0 ? tail_ms : 60);
}
void SfxChannel::PlayBeep(uint32_t req) {
    const int freq = static_cast<int>(req >> 18);
    const int ms = static_cast<int>((req >> 8) & 0x3FF);
    const int type = static_cast<int>(req & 0xFF);
    if (freq <= 0 || ms <= 0) return;

    const int sr = static_cast<int>(board::kAudioSampleRate);
    // 18-30 ms tones never get played: the N32 receive/playback buffer does not
    // even start before the stream stops again. Clamp to 83 ms .. 500 ms, the
    // shortest length that is actually audible on this speaker.
    int tone = (sr * ms) / 1000;
    if (tone < sr / 12) tone = sr / 12;   // 83 ms
    if (tone > sr / 2) tone = sr / 2;     // 500 ms
    // type 2 is the metronome tick: at 240 BPM beats are only 250 ms apart, and
    // the normal 20 ms pre-roll + 150 ms tail would overlap the next beat
    // (Beep is a covering queue, so the result is dropped beats).
    const bool click = (type == 2);
    const int pre = click ? sr / 100 : sr / 50;      // 10 ms / 20 ms pre-roll
    const int tail = click ? sr / 25 : sr * 3 / 20;  // 40 ms / 150 ms tail
    const int total = pre + tone + tail;

    // Fallback path when the resource pack is missing. The lead-in has to be
    // padded at the *front*: padding the tail never helped, the swallowed part
    // is the beginning of the session.
    const bool fresh = NeedsSession();
    if (fresh && !WriteSilence(board::kStreamLeadInMs)) return;
    if (fresh) lead_ins_.fetch_add(1);

    // Synthesise and write in blocks of at most 200 samples so no large buffer
    // (72 KB for 1.5 s) is ever allocated.
    int16_t block[200];
    constexpr int kBlockSamples = sizeof(block) / sizeof(block[0]);
    const int fade = sr / 200;  // 5 ms fade in/out, removes onset/offset clicks
    for (int off = 0; off < total; off += kBlockSamples) {
        const int n = std::min(kBlockSamples, total - off);
        for (int i = 0; i < n; ++i) {
            const int k = off + i;
            float v = 0.0f;
            if (k >= pre && k < pre + tone) {
                const int j = k - pre;
                const float t = static_cast<float>(j) / static_cast<float>(sr);
                if (click) {
                    // Full amplitude square wave, no exponential decay: decay
                    // removes so much energy that the short tick disappears.
                    const float ph = std::fmod(t * static_cast<float>(freq), 1.0f);
                    v = ph < 0.5f ? 0.92f : -0.92f;
                } else if (type == 1) {
                    v = std::sin(2.0f * 3.14159265f * static_cast<float>(freq) * t);
                } else {
                    const float ph = std::fmod(t * static_cast<float>(freq), 1.0f);
                    v = ph < 0.5f ? 0.92f : -0.92f;  // square reads as arcade
                }
                if (j < fade) {
                    v *= static_cast<float>(j) / static_cast<float>(fade);
                } else if (j > tone - fade) {
                    v *= static_cast<float>(tone - j) / static_cast<float>(fade);
                }
            }
            // Amplitude 20000: at 9000 the 8-bit conversion left only about
            // -11 dBFS, which is inaudible on this tiny speaker.
            block[i] = static_cast<int16_t>(v * 20000.0f);
        }
        if (Write(block, n) <= 0) {
            fail_.fetch_add(1);
            ESP_LOGW(kTag, "sfx write failed freq=%d ms=%d fail=%d", freq, ms,
                     fail_.load());
            AudioUart::Instance().InvalidateStream();
            return;
        }
    }
}

}  // namespace desktop_audio

// ---------------------------------------------------------------------------
// desktop_sfx::Play —— 有资源就用资源，没有就退回合成音（v40 语义原样保留）
//
// Data() 仍在 desktop_board.cc（它负责 assets mmap 解析与 3 次重试），这个
// 函数只决定「往哪条通道投递」。radio.running() 的守卫必须留着：半双工下
// 收音机占着链路时插音效只会被协处理器吞掉，还会打断正在播的那一路。
// ---------------------------------------------------------------------------
namespace desktop_sfx {

void Play(Id id, int tail_ms) {
    auto* s = DesktopRuntime::instance;
    if (s == nullptr || s->radio.running()) return;
    size_t bytes = 0;
    const uint8_t* pcm = Data(id, &bytes);
    if (pcm != nullptr && bytes > 0) {
        desktop_audio::SfxChannel::Instance().PlayPcm(pcm, bytes, tail_ms);
        return;
    }
    const Clip& c = Table()[id];
    desktop_audio::SfxChannel::Instance().Beep(c.freq, c.ms, c.type);
}

}  // namespace desktop_sfx