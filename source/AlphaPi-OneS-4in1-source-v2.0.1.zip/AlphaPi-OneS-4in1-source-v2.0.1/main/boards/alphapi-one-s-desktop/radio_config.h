#pragma once

// 网络收音机的「数据面」常量：只留播放器与 UI 都需要的东西。
//
// 硬件事实（UART 引脚/波特率、显示屏引脚、键 GPIO）在 board_config.h；
// UART1 驱动与帧协议在 audio_uart.cc。这里不再重复它们，避免出现第二份
// 会漂移的硬件定义。

#include <cstddef>
#include <cstdint>

namespace radio {

// ---------------------------------------------------------------------------
// 音频格式
// ---------------------------------------------------------------------------
// N32 的 DAC 实际消费速率是 24000 B/s（8-bit unsigned mono）。
constexpr uint32_t kOutputSampleRate = 24000;

// ---------------------------------------------------------------------------
// 缓冲区容量
// ---------------------------------------------------------------------------
constexpr size_t kCompressedCapacityBytes = 64 * 1024;  // ~8 s @ 64 kbps
// PCM 环 6 秒 = 144000 样本 = 288 KB，必须放 PSRAM。
constexpr size_t kPcmCapacity = kOutputSampleRate * 6;

// ---------------------------------------------------------------------------
// 音量
// ---------------------------------------------------------------------------
constexpr int kVolumeMin = 0;
constexpr int kVolumeMax = 100;
constexpr int kDefaultVolume = 67;

// ---------------------------------------------------------------------------
// 电台表容量
// ---------------------------------------------------------------------------
constexpr int kMaxStations = 64;
constexpr int kStationNameBytes = 40;
constexpr int kStationUrlBytes = 224;

// ---------------------------------------------------------------------------
// 播放器状态
// ---------------------------------------------------------------------------
enum class PlayerState {
    kIdle,
    kConnecting,
    kBuffering,
    kPlaying,
    kPaused,
    kReconnecting,
    kError,
};

struct Station {
    char name[kStationNameBytes];
    char url[kStationUrlBytes];
};
inline const Station kDefaultStations[] = {
    // ===== 济南本地（最前） =====
    {"济南故事广播", "http://lhttp.qtfm.cn/live/1672/64k.mp3"},
    {"济南新闻广播", "http://lhttp.qtfm.cn/live/1667/64k.mp3"},
    {"济南经济广播", "http://lhttp.qtfm.cn/live/1668/64k.mp3"},
    {"济南交通广播", "http://lhttp.qtfm.cn/live/1669/64k.mp3"},
    {"936私家车广播", "http://lhttp.qtfm.cn/live/1670/64k.mp3"},
    {"济南音乐广播", "http://lhttp.qtfm.cn/live/1671/64k.mp3"},
    // ===== 山东省内 =====
    {"山东综合广播", "http://lhttp.qtfm.cn/live/20234/64k.mp3"},
    {"山东文艺广播", "http://lhttp.qtfm.cn/live/20238/64k.mp3"},
    {"山东经济广播", "http://lhttp.qtfm.cn/live/20236/64k.mp3"},
    {"山东经典音乐广播", "http://lhttp.qtfm.cn/live/20240/64k.mp3"},
    {"济宁交通文艺广播", "http://lhttp.qtfm.cn/live/20087/64k.mp3"},
    {"临沂交通旅游广播", "http://lhttp.qtfm.cn/live/3993/64k.mp3"},
    {"东营交通音乐广播", "http://lhttp.qingting.fm/live/20142/64k.mp3"},
    {"东营综合广播", "http://lhttp.qingting.fm/live/20144/64k.mp3"},
    {"青岛交通广播", "http://lhttp.qingting.fm/live/1676/64k.mp3"},
    {"青岛经济广播", "http://lhttp.qingting.fm/live/1674/64k.mp3"},
    {"聊城经济广播", "http://lhttp.qtfm.cn/live/5022262/64k.mp3"},
    // ===== 央广 / 北京 / 天津 =====
    {"中国之声", "http://lhttp.qtfm.cn/live/15318317/64k.mp3"},
    {"北京新闻广播", "http://lhttp.qtfm.cn/live/339/64k.mp3"},
    {"北京交通广播", "http://lhttp.qingting.fm/live/336/64k.mp3"},
    {"北京音乐广播", "http://lhttp.qtfm.cn/live/332/64k.mp3"},
    {"北京文艺广播", "http://lhttp.qtfm.cn/live/333/64k.mp3"},
    {"天津新闻广播", "http://lhttp-hw.qtfm.cn/live/5022134/64k.mp3"},
    {"天津经济广播", "http://lhttp-hw.qtfm.cn/live/15318227/64k.mp3"},
    // ===== 上海 =====
    {"上海新闻广播", "http://lhttp.qingting.fm/live/270/64k.mp3"},
    {"上海交通广播", "http://lhttp.qingting.fm/live/266/64k.mp3"},
    {"上海音乐广播", "http://lhttp.qingting.fm/live/273/64k.mp3"},
    {"上海经典音乐广播", "http://lhttp.qingting.fm/live/267/64k.mp3"},
    {"上海流行音乐动感101", "http://lhttp-hw.qtfm.cn/live/274/64k.mp3"},
    {"上海第一财经广播", "http://lhttp-hw.qtfm.cn/live/276/64k.mp3"},
    {"上海戏剧曲艺广播", "http://lhttp.qingting.fm/live/269/64k.mp3"},
    // ===== 其他重点省台 =====
    {"石家庄交通广播", "http://lhttp.qingting.fm/live/1655/64k.mp3"},
    {"辽宁交通广播", "http://lhttp.qtfm.cn/live/20025/64k.mp3"},
    {"辽宁音乐广播", "http://lhttp.qingting.fm/live/1101/64k.mp3"},
    {"辽宁经济广播", "http://lhttp-hw.qtfm.cn/live/20019/64k.mp3"},
    {"江苏财经广播", "http://lhttp.qingting.fm/live/1802/64k.mp3"},
    {"无锡交通广播", "http://lhttp.qingting.fm/live/2780/64k.mp3"},
    {"无锡新闻综合广播", "http://lhttp.qtfm.cn/live/2777/64k.mp3"},
    {"合肥交通信息广播", "http://lhttp-hw.qtfm.cn/live/1960/64k.mp3"},
    {"合肥文艺广播", "http://lhttp-hw.qtfm.cn/live/1975/64k.mp3"},
    {"重庆音乐广播", "http://lhttp.qtfm.cn/live/20176/64k.mp3"},
    {"成都经济广播", "http://lhttp-hw.qtfm.cn/live/1121/64k.mp3"},
    {"云南经济广播", "http://lhttp.qtfm.cn/live/1927/64k.mp3"},
    {"云南音乐广播", "http://lhttp.qtfm.cn/live/1929/64k.mp3"},
    {"湖南潇湘之声", "http://lhttp.qingting.fm/live/20500092/64k.mp3"},
    {"广东珠江经济", "http://lhttp.qtfm.cn/live/1259/64k.mp3"},
    {"深圳新闻广播", "http://lhttp.qingting.fm/live/1270/64k.mp3"},
    {"内蒙古交通之声", "http://lhttp-hw.qtfm.cn/live/1884/64k.mp3"},
    {"商丘综合广播", "http://lhttp-hw.qtfm.cn/live/5022443/24k.mp3"},
    // ===== 国际 / 港澳 / 特色音乐 =====
    {"AsiaFM亚洲天空台", "http://lhttp.qingting.fm/live/20071/64k.mp3"},
    {"法国国际广播电台中文", "https://rfienchinois64k.ice.infomaniak.ch/rfienchinois-64.mp3"},
    {"蜻蜓音乐台", "http://lhttp-hw.qtfm.cn/live/4915/64k.mp3"},
    {"500首华语经典", "http://lhttp.qtfm.cn/live/5022308/64k.mp3"},
    {"中国民乐", "http://radio.chinesemusicworld.com/chinesemusic.mp3"},
};
constexpr int kDefaultStationCount =
    sizeof(kDefaultStations) / sizeof(kDefaultStations[0]);

}  // namespace radio
