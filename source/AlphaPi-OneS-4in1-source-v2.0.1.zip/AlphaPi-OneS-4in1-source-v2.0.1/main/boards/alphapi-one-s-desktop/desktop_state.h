#pragma once
#include <atomic>
#include <string>
extern std::atomic<int> desktop_page;
extern std::atomic<bool> desktop_network;
void DesktopActivationCode(const std::string& code);
