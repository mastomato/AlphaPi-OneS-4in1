#pragma once

// 音效通道 + 音频总线 façade
//
// B3 之后音频层分三层，职责不重叠：
//
//   DesktopCodec::audio (radio::AudioBus)   —— 零状态转发壳，UI/board/server 的唯一入口
//        ├── radio::AudioUart（UART1 唯一 owner：帧、会话、音量、8bit 转换）
//        ├── radio::DesktopKeys（4 键 GPIO，无任务无锁）
//        └── desktop_audio::SfxChannel（唯一音效任务：单次音效/常开底流/节拍器）
//
// AudioBus 本身不存任何状态：它每次调用都转发到上面的单例，所以即使被复制、
// 被多个对象持有也只有一个真实状态。这一点很关键——v36 之前系统里有两个
// 各记一份「我已经发过 WAV 头」的对象，结果是一声不响。

#include <atomic>
#include <cstddef>
#include <cstdint>

#include "audio_uart.h"
#include "desktop_keys.h"

namespace radio {

class AudioBus {
public:
    // 幂等。UART 驱动 + 键 GPIO 都在这里初始化（2s 协处理器上电等待只发生一次）。
    bool Init();
    // 兼容入口：丢掉缓存的 WAV 头，下一次写入重新握手。
    void Start();
    // 「让出/释放播放会话」：先停音效任务，再让协处理器退出录音/播放态。
    void Stop();

    void SetVolume(int volume);
    int volume() const { return AudioUart::Instance().volume(); }

    int Write(const int16_t* samples, int count);
    int ReadMic(int16_t* samples, int count);
    int Level();
    void InvalidateStream();

    // 音效（全部转发到 SfxChannel；异步投递，立即返回）
    void Beep(int freq, int ms, int type = 0);
    void PlayPcm(const uint8_t* pcm, size_t bytes, int tail_ms = 60);
    void KeepAlive(bool on);
    void ClickStream(bool on, int accent, int weak, int tone_ms, int period_ms,
                     int bar);
    void SetClickPcm(const uint8_t* accent, size_t accent_bytes,
                     const uint8_t* weak, size_t weak_bytes);
    void StopBeepTask();
    int beep_fail_count() const;
    uint32_t sfx_lead_ins() const;

    // 键（GPIO 直读）
    uint8_t ReadKeys();
    uint32_t key_polls() const;
    uint8_t cached_keys() const;

    // 诊断：UART 侧的原始计数
    uint32_t ack_failures() const { return AudioUart::Instance().stats().ack_failures; }
    uint32_t stream_gaps() const { return AudioUart::Instance().stats().stream_gaps; }
    uint32_t stream_resets() const { return AudioUart::Instance().stats().stream_resets; }
    uint32_t stream_stalls() const { return AudioUart::Instance().stats().stalls; }
};

}  // namespace radio

namespace desktop_audio {

// 唯一音效 owner。三种流（单次音效 / 常开静音底流 / 节拍器连续流）串在同一个
// 任务里执行，任何时刻只有一个在跑 —— 这就是「唯一 owner 令牌」。
class SfxChannel {
public:
    static SfxChannel& Instance();

    // 幂等。任务由本函数按需创建（name=desktop_sfx, stack 4096, prio 6）。
    bool Start();
    // 置退出标志并唤醒任务；最多等 30ms，不 join（任务自己 vTaskDelete）。
    void Stop();

    // 覆盖式投递：后来的请求顶掉前一个（连击/碰撞时至少最后一次一定响）。
    void Beep(int freq, int ms, int type = 0);
    void PlayPcm(const uint8_t* pcm, size_t bytes, int tail_ms = 60);
    void KeepAlive(bool on);
    void ClickStream(bool on, int accent_freq, int weak_freq, int tone_ms,
                     int period_ms, int beats_per_bar);
    void SetClickPcm(const uint8_t* accent, size_t accent_bytes,
                     const uint8_t* weak, size_t weak_bytes);

    int fail_count() const { return fail_.load(); }
    uint32_t lead_ins() const { return lead_ins_.load(); }
    // 0=none 1=sfx 2=keepalive 3=metronome
    int active_owner() const { return owner_.load(); }

private:
    SfxChannel() = default;

    void Worker();
    static void TaskThunk(void* arg);
    void PlayBeep(uint32_t req);
    void PlayClip(const uint8_t* pcm, size_t bytes, int tail_ms);
    void IdleLoop();
    void ClickLoop();
    bool WriteSilence(int ms);
    bool NeedsSession() const;
    void* EnsureTask();

    int Write(const int16_t* samples, int count);

    std::atomic<bool> stop_{false};
    std::atomic<bool> busy_{false};
    std::atomic<void*> task_{nullptr};
    std::atomic<int> owner_{0};
    std::atomic<uint32_t> req_{0};        // 打包 freq/ms/type
    std::atomic<int> kind_{0};            // 0=合成音 1=PCM 文件
    std::atomic<const uint8_t*> pcm_src_{nullptr};
    std::atomic<size_t> pcm_bytes_{0};
    std::atomic<int> pcm_tail_ms_{60};
    std::atomic<uint32_t> sfx_seq_{0};
    std::atomic<uint32_t> sfx_done_{0};
    std::atomic<bool> keep_on_{false};
    std::atomic<bool> click_on_{false};
    std::atomic<int> click_accent_{1568};
    std::atomic<int> click_weak_{1047};
    std::atomic<int> click_tone_ms_{90};
    std::atomic<int> click_period_ms_{500};
    std::atomic<int> click_bar_{4};
    std::atomic<const uint8_t*> click_accent_pcm_{nullptr};
    std::atomic<size_t> click_accent_bytes_{0};
    std::atomic<const uint8_t*> click_weak_pcm_{nullptr};
    std::atomic<size_t> click_weak_bytes_{0};
    std::atomic<int> fail_{0};
    std::atomic<uint32_t> lead_ins_{0};
    // 句柄的「取用 / 摘除」必须互斥，否则投递方可能刚读到句柄、任务就自删了。
    void* mux_ = nullptr;  // SemaphoreHandle_t
};

}  // namespace desktop_audio