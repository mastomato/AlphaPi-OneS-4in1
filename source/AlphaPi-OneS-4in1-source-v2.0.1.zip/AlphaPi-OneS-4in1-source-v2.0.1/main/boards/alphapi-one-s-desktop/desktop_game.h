#pragma once
// 游戏页（替代原「音乐」页）：一个 lv_canvas 像素画布 + 少量 lv_label 文字层。
// 4 款离线小游戏（贪吃蛇 / 打砖块 / 像素鸟 / 俄罗斯方块）+ 启动器，全部用 4 键操作，
// 音效走 N32Audio，样本是 assets 分区里的音频文件（见 desktop_sfx.h）。

#include <lvgl.h>
#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <cstring>

#include "esp_heap_caps.h"
#include "esp_random.h"
#include "desktop_sfx.h"

class DesktopRuntime;  // 前向声明，仅用于 D 键回主页（GoTo 为 public）

// 由 desktop_board.cc 提供：音效前会检查收音机未在播放，避免抢占音频通道。
// v40：音效改成按语义选（assets 里的音频文件），不再传频率和时长。
// 具体文件与兜底参数见 desktop_sfx.h。
void GameSfx(int id);
// 由 desktop_board.cc 提供：游戏页长按/启动器内按 D 回主页（绕过不完整类型）。
void GameGotoHome();

namespace dui {

// ---- 调色板（与预览 game-preview.html 逐色一致）----
static inline lv_color_t lc(uint8_t r, uint8_t g, uint8_t b) { return lv_color_make(r, g, b); }
static const lv_color_t G_BG     = lc(9, 14, 24);
static const lv_color_t G_PANEL  = lc(17, 26, 42);
static const lv_color_t G_PANEL2 = lc(26, 39, 62);
static const lv_color_t G_EDGE   = lc(44, 62, 94);
static const lv_color_t G_INK    = lc(150, 176, 208);
static const lv_color_t G_WARM   = lc(255, 196, 92);
static const lv_color_t G_CYAN   = lc(96, 214, 236);
static const lv_color_t G_WHITE  = lc(240, 246, 255);
static const lv_color_t G_RED    = lc(240, 90, 96);
static const lv_color_t G_GREEN  = lc(78, 201, 120);
static const lv_color_t G_BLUE   = lc(96, 148, 255);
static const lv_color_t G_YELLOW = lc(255, 214, 102);
static const lv_color_t G_PURPLE = lc(186, 140, 246);
static const lv_color_t G_ORANGE = lc(255, 150, 64);
static const lv_color_t G_SKY    = lc(24, 38, 64);
static const lv_color_t G_GRASS  = lc(74, 150, 86);
static const lv_color_t G_DIRT   = lc(56, 44, 38);
static const lv_color_t G_PIPE   = lc(70, 190, 110);

// 方块配色查表：命名空间级静态数组（类内 static const 非整型数组需 constexpr，
// 而调色板非常量表达式，故定义在类外、类之前，供类内方法引用）。
static const lv_color_t PCOL[7] = {G_CYAN, G_BLUE, G_WARM, G_YELLOW, G_GREEN, G_PURPLE, G_RED};

class GameUi {
public:
    enum Game { kSnake = 0, kBreakout, kFlappy, kTetris, kCount };
    enum Screen { kLauncher, kPlay };

    void Build(lv_obj_t* scr, const lv_font_t* font, DesktopRuntime* rt) {
        rt_ = rt;
        font_ = font;
        root = lv_obj_create(scr);
        lv_obj_set_size(root, 160, 128);
        lv_obj_set_style_bg_color(root, G_BG, 0);
        lv_obj_set_style_bg_opa(root, LV_OPA_COVER, 0);
        lv_obj_set_style_border_width(root, 0, 0);
        lv_obj_set_style_pad_all(root, 0, 0);

        canvas_ = lv_canvas_create(root);
        // 画布是 RGB565：160*128*2 = 40960 B，必须用 uint16_t 视图。
        // 千万不要用 lv_color_t —— 它在 LVGL 9 里恒为 3 字节，
        // 按 3 字节步进写、LVGL 按 2 字节步进读，屏幕会是斜向花屏。
        static uint16_t* gbuf = static_cast<uint16_t*>(
            heap_caps_malloc(160 * 128 * sizeof(uint16_t),
                             MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
        buf_ = gbuf ? gbuf : static_cast<uint16_t*>(malloc(160 * 128 * sizeof(uint16_t)));
        if (!buf_) return;  // 没有画布就不要继续建 UI，避免空指针逐像素写
        // 大块状态数组放到堆（优先 PSRAM），避免占满紧张的 DRAM bss。
        snake_.seg = static_cast<int*>(heap_caps_malloc(240 * sizeof(int), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
        if (!snake_.seg) snake_.seg = static_cast<int*>(heap_caps_malloc(240 * sizeof(int), MALLOC_CAP_DEFAULT));
        br_.bricks = static_cast<int*>(heap_caps_malloc(24 * sizeof(int), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
        if (!br_.bricks) br_.bricks = static_cast<int*>(heap_caps_malloc(24 * sizeof(int), MALLOC_CAP_DEFAULT));
        tet_.well = static_cast<uint8_t*>(heap_caps_malloc(180 * sizeof(uint8_t), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
        if (!tet_.well) tet_.well = static_cast<uint8_t*>(heap_caps_malloc(180 * sizeof(uint8_t), MALLOC_CAP_DEFAULT));
        lv_canvas_set_buffer(canvas_, buf_, 160, 128, LV_COLOR_FORMAT_RGB565);
        lv_obj_align(canvas_, LV_ALIGN_TOP_LEFT, 0, 0);

        title_ = Label(root, G_WARM, 68, 3, 40, "游戏");
        msg_   = Label(root, G_WARM, 0, 52, 160, "");
        hint_  = Label(root, G_INK, 6, 114, 150, "");
        for (int i = 0; i < 4; ++i) gname_[i] = Label(root, G_INK, 0, 0, 44, "");
        SetScreen();
    }

    void Refresh() {}  // 主循环已通过 Tick() 持续刷新画布

    // 键位：游戏页由 board 侧按下即派发（gesture 0=单击 / >=2 长按），
    // 每款游戏的单击键位各自独立，长按则统一成一套语义：
    //   A 长按 = 开始/重开   B 长按 = 退回游戏列表
    //   C 长按 = 暂停/继续   D 长按 = 结束本局并回主页
    // 按键「立刻见效」：以前改完状态要等下一个 25~40ms 动画帧才画出来，
    // 叠加 LVGL 绘制 + SPI flush 就有明显拖滞。这里包一层，KeyImpl 返回后
    // 马上重画一次画布，让转向 / 拍翅 / 挡板移动当帧可见。
    void Key(int idx, int gesture) {
        KeyImpl(idx, gesture);
        RedrawNow();
    }
    void KeyImpl(int idx, int gesture) {
        const bool hold = (gesture >= 2);
        if (screen_ == kLauncher) {
            // 启动器：A 进入 · B 上一个 · C 下一个 · D 回主页
            if (hold) {
                if (idx == 3) GameGotoHome();
                return;
            }
            if (idx == 0) EnterGame(selected_);
            else if (idx == 1) selected_ = static_cast<Game>((selected_ + kCount - 1) % kCount);
            else if (idx == 2) selected_ = static_cast<Game>((selected_ + 1) % kCount);
            else GameGotoHome();
            return;
        }
        if (hold) {
            // v36：打砖块的 B 长按改成「暂停/继续」（短按变成加速），
            // 所以「退出到游戏列表」给它挪到 C 长按，四个功能一个不丢：
            //   A 长按重开 · B 长按暂停/继续 · C 长按回列表 · D 长按回主页
            if (current_ == kBreakout) {
                if (idx == 1) { TogglePause(); return; }
                if (idx == 2) { ExitToLauncher(); return; }
            }
            switch (idx) {
                case 0: Restart(); break;
                case 1: ExitToLauncher(); break;
                case 2: TogglePause(); break;
                default: EndAndHome(); break;
            }
            return;
        }
        // 结束态下任意键即重开，不必再记是哪个键
        if (IsDead()) { Restart(); return; }
        if (IsPaused()) { TogglePause(); return; }
        switch (current_) {
            case kSnake:  // A 上 · B 下 · C 左 · D 右
                if (idx == 0) snake_.ndir = 0;
                else if (idx == 1) snake_.ndir = 2;
                else if (idx == 2) snake_.ndir = 3;
                else snake_.ndir = 1;
                GameSfx(desktop_sfx::kTurn);   // 转向的轻音
                break;
            case kBreakout:  // A 发球 · B 短按加速（长按暂停/继续）· C 左移 · D 右移
                if (idx == 0) {
                    if (!br_.launched) { br_.launched = true; br_.bvy = -1; GameSfx(desktop_sfx::kMove); }
                } else if (idx == 1) {
                    // 逐级加速：2 -> 3 -> 4 档（60 / 90 / 120 px/s），到顶再按回到 2。
                    if (!br_.dead) {
                        br_.spd = (br_.spd >= 4) ? 2 : (br_.spd + 1);
                        GameSfx(desktop_sfx::kKey);
                    }
                } else if (idx == 2) {
                    br_.px = std::max(6, br_.px - 20);
                } else {
                    br_.px = std::min(128, br_.px + 20);
                }
                break;
            case kFlappy:  // 四键分档拍翅：A 大跳 / B 中 / C 小 / D 轻点
                { static const int lift[4] = {-8, -6, -5, -4};
                  fl_.bvy = lift[idx]; }
                GameSfx(desktop_sfx::kTurn);
                break;
            case kTetris:  // A 旋转 · B 硬降 · C 左移 · D 右移
                if (idx == 0) TetRotate();
                else if (idx == 1) TetHardDrop();
                else if (idx == 2) TetMove(-1);
                else TetMove(1);
                break;
            default: break;
        }
    }

    // 当前是否处于游戏内（启动器画面不需要高频重绘）
    bool InPlay() const { return screen_ == kPlay; }
    // public 包装：Ui / board 在离开游戏页时调用，内部走 private 的 OnLeave()
    void LeaveCleanup() { OnLeave(); }

    // 全屏 canvas 重绘统一走这里，**30ms 内最多画一次**。
    // 小鸟玩家会高频连按拍翅：若每次按键都立刻重画 160x128 画布 + 整屏 flush，
    // 再叠上 33ms 定时帧，一秒内会有几十次全屏重绘，直接把 UI 任务拖死
    // ——这就是 Beep 异步化之后「小鸟玩一会儿仍卡住」剩下的那一半根因。
    void DrawFrame(int64_t now, bool force) {
        if (!canvas_ || !buf_) return;
        // 节流命中的按键不能丢：记下来，下一帧补画一次（暂停/结束提示靠这个显示）
        if (!force && now - last_draw_ms_ < 30) { pending_draw_ = true; return; }
        pending_draw_ = false;
        last_draw_ms_ = now;
        if (screen_ == kLauncher) {
            DrawLauncher();
            launcher_drawn_ = true;
            launcher_key_ = static_cast<int>(selected_);
        } else {
            switch (current_) {
                case kSnake: SnakeDraw(); break;
                case kBreakout: BrDraw(); break;
                case kFlappy: FlDraw(); break;
                case kTetris: TetDraw(); break;
                default: break;
            }
        }
        lv_obj_invalidate(canvas_);
    }
    // 只重画、不推进游戏逻辑（供 Key() 立即刷新用）
    void RedrawNow() { DrawFrame(lv_tick_get(), false); }

    void Tick() {
        if (!canvas_ || !buf_) return;
        const int64_t now = lv_tick_get();
        if (tick_ms_ == 0) tick_ms_ = now;
        const int64_t dt = now - tick_ms_;
        tick_ms_ = now;
        if (msg_hint_ && now > hint_until_) { Hide(msg_, true); msg_hint_ = false; }
        if (screen_ == kLauncher) {
            // 菜单是静态画面：只有选中项变了才重绘。
            const int key = static_cast<int>(selected_);
            if (!launcher_drawn_ || key != launcher_key_) {
                DrawLauncher();
                launcher_drawn_ = true;
                launcher_key_ = key;
                lv_obj_invalidate(canvas_);
            }
            return;
        }
        ++tick_count_;
        // 蛇 200ms 才动一格、方块 560ms 才落一格，中间那些帧完全没必要
        // 全屏重绘；砖块 / 小鸟每帧都在动，才需要每帧画。
        bool need = false;
        switch (current_) {
            case kSnake:
                if (!snake_.paused && !snake_.dead) {
                    snake_.step += dt;
                    if (snake_.step >= 200) { snake_.step = 0; SnakeStep(); need = true; }
                }
                break;
            case kBreakout:
                // v29：每帧走两个 1px 子步 = 60px/s。v28 的 1px/帧(30px/s)
                // 太慢，v27 的 2px/25ms(80px/s) 又快到挡板跟不上；子步进
                // 还能避免一次跳 2px 时穿过挡板/砖块的判定空隙。
                // v36：子步数改成可调（br_.spd），B 短按逐级加速。
                if (!br_.paused && !br_.dead) {
                    for (int i = 0; i < br_.spd && !br_.dead; ++i) BrStep();
                    need = true;
                }
                break;
            case kFlappy:
                if (!fl_.paused && !fl_.dead) { FlStep(dt); need = true; }
                break;
            case kTetris:
                if (!tet_.paused && !tet_.dead) {
                    tet_.fall += dt;
                    if (tet_.fall >= 560) { tet_.fall = 0; TetStep(); need = true; }
                }
                break;
            default: break;
        }
        if (need) DrawFrame(now, false);
        else if (pending_draw_) DrawFrame(now, true);
    }

    lv_obj_t* root = nullptr;

private:
    // ---------- 通用绘制 ----------
    // 画布按 LV_COLOR_FORMAT_RGB565 解释：每像素 2 字节紧密排列。
    // lv_color_t 是 {blue,green,red} 三字节（LVGL 9 与色深无关），绝不能直接
    // 写进这块缓冲——那会让每个像素偏移 1.5 倍，屏幕呈斜向花屏。
    // 所有绘制统一经过 Px()/Pxv()，在这里做一次 packed RGB565 转换。
    uint16_t* buf_ = nullptr;
    static uint16_t To565(lv_color_t c) {
        return static_cast<uint16_t>(((c.red & 0xF8) << 8) | ((c.green & 0xFC) << 3) | (c.blue >> 3));
    }
    void Pxv(int x, int y, uint16_t v) {
        if (!buf_ || x < 0 || x >= 160 || y < 0 || y >= 128) return;
        buf_[y * 160 + x] = v;
    }
    void Px(int x, int y, lv_color_t c) { Pxv(x, y, To565(c)); }
    void Rect(int x, int y, int w, int h, lv_color_t c) {
        const uint16_t v = To565(c);
        for (int j = 0; j < h; ++j) for (int i = 0; i < w; ++i) Pxv(x + i, y + j, v);
    }
    void Border(int x, int y, int w, int h, lv_color_t c) {
        Rect(x, y, w, 1, c); Rect(x, y + h - 1, w, 1, c);
        Rect(x, y, 1, h, c); Rect(x + w - 1, y, 1, h, c);
    }
    void Clear(lv_color_t c) {
        if (!buf_) return;
        const uint16_t v = To565(c);
        for (int i = 0; i < 160 * 128; ++i) buf_[i] = v;
    }
    // 1px 圆角描边：等价于「实心 RRect 减去内缩 1px 的实心 RRect」，
    // 但只填边线（约 500 像素，实心要 17000+）。棋盘外框、预览窗外框用它，
    // 视觉与实心三层完全一致，每帧省下约 5 万次像素写。
    void RFrame(int x, int y, int w, int h, int r, lv_color_t c) {
        if (!buf_) return;
        const uint16_t v = To565(c);
        for (int j = 0; j < h; ++j) {
            const int jy = (j < r) ? (r - 1 - j) : ((j >= h - r) ? (j - (h - r)) : -1);
            int lo = 0, hi = w - 1;
            if (jy >= 0) {                     // 圆角行：解 ix² + jy² <= r²
                int lim = 0;
                while ((lim + 1) * (lim + 1) + jy * jy <= r * r) ++lim;
                lo = r - 1 - lim;
                hi = w - r + lim;
            }
            if (lo > hi) continue;
            if (j == 0 || j == h - 1) {
                for (int i = lo; i <= hi; ++i) Pxv(x + i, y + j, v);
            } else {
                Pxv(x + lo, y + j, v);
                Pxv(x + hi, y + j, v);
            }
        }
    }
    // 亮度缩放：pct=100 为原色，150 提亮一半，70 压暗
    static uint8_t Cl(int v) { return v > 255 ? 255 : (v < 0 ? 0 : static_cast<uint8_t>(v)); }
    static lv_color_t Mix(lv_color_t c, int pct) {
        return lv_color_make(Cl(c.red * pct / 100), Cl(c.green * pct / 100), Cl(c.blue * pct / 100));
    }
    void Circle(int cx, int cy, int r, lv_color_t c) {
        for (int y = -r; y <= r; ++y)
            for (int x = -r; x <= r; ++x)
                if (x * x + y * y <= r * r + r * 7 / 10) Px(cx + x, cy + y, c);
    }
    // 圆角实心矩形
    void RRect(int x, int y, int w, int h, int r, lv_color_t c) {
        for (int j = 0; j < h; ++j) for (int i = 0; i < w; ++i) {
            bool ok = true;
            if (i < r && j < r)              ok = ((r-1-i)*(r-1-i) + (r-1-j)*(r-1-j) <= r*r);
            else if (i >= w-r && j < r)      ok = ((i-(w-r))*(i-(w-r)) + (r-1-j)*(r-1-j) <= r*r);
            else if (i < r && j >= h-r)      ok = ((r-1-i)*(r-1-i) + (j-(h-r))*(j-(h-r)) <= r*r);
            else if (i >= w-r && j >= h-r)   ok = ((i-(w-r))*(i-(w-r)) + (j-(h-r))*(j-(h-r)) <= r*r);
            if (ok) Px(x + i, y + j, c);
        }
    }
    // 立体圆角块：圆角 + 顶/左高光 + 底/右暗边
    void Block3d(int x, int y, int w, int h, int r, lv_color_t c) {
        RRect(x, y, w, h, r, c);
        const lv_color_t hi = Mix(c, 150), mid = Mix(c, 120), lo = Mix(c, 55);
        for (int i = r; i < w - r; ++i) { Px(x+i, y, hi); Px(x+i, y+1, mid); }
        for (int j = r; j < h - r; ++j) { Px(x, y+j, hi); Px(x+1, y+j, mid); }
        for (int i = r; i < w - r; ++i) Px(x+i, y+h-1, lo);
        for (int j = r; j < h - r; ++j) Px(x+w-1, y+j, lo);
    }

    // ---- 像素 HUD ----
    // 画面本身是像素风，得分若用 LVGL 平滑字压上去会非常突兀，
    // 故改用与游戏同像素密度的 3×5 点阵数字，画在棋盘上沿的徽章里。
    static constexpr uint8_t DIG[50] = {
        7,5,5,5,7,  2,6,2,2,7,  7,1,7,4,7,  7,1,7,1,7,  5,5,7,1,1,
        7,4,7,1,7,  7,4,7,5,7,  7,1,1,1,1,  7,5,7,5,7,  7,5,7,1,7
    };
    static int Digits(int v) { return (v < 100) ? 2 : (v < 1000 ? 3 : 4); }
    void DrawNum(int x, int y, int v, lv_color_t c) {
        if (v < 0) v = 0; else if (v > 9999) v = 9999;
        const int n = Digits(v);
        int d[4] = {0, 0, 0, 0};
        for (int k = n - 1, t = v; k >= 0; --k, t /= 10) d[k] = t % 10;
        for (int k = 0; k < n; ++k) {
            const uint8_t* g = &DIG[d[k] * 5];
            for (int r = 0; r < 5; ++r)
                for (int b = 0; b < 3; ++b) if (g[r] & (4 >> b)) Px(x + k * 4 + b, y + r, c);
        }
    }
    void ChipBg(int x, int y, int w, int h) {
        RRect(x, y, w, h, 3, G_EDGE);
        RRect(x + 1, y + 1, w - 2, h - 2, 2, Mix(G_PANEL, 108));
    }
    // 图标：0=苹果 1=砖块 2=小鸟 3=方块
    void Ico(int id, int x, int y) {
        if (id == 0)      { Circle(x, y+1, 2, G_RED); Px(x, y-1, Mix(G_GREEN,120)); Px(x+1, y-1, G_GREEN); }
        else if (id == 1) { Rect(x-3, y-1, 3, 3, Mix(G_ORANGE,115)); Rect(x+1, y-1, 3, 3, G_ORANGE); }
        else if (id == 2) { Circle(x, y, 2, G_WARM); Px(x+2, y, G_ORANGE); Px(x+1, y-1, G_WHITE); }
        else              { RRect(x-2, y-2, 5, 5, 1, G_CYAN); Px(x-1, y-1, G_WHITE); }
    }
    void IcoPaddle(int x, int y, lv_color_t c) { Rect(x, y, 5, 2, c); Px(x+1, y, Mix(c,150)); }
    // 启动器用的大图标（比 HUD 图标细节更多）
    void IcoBig(int id, int x, int y, lv_color_t col) {
        if (id == 0)      { Circle(x-3, y-3, 2, col); Circle(x+2, y, 2, col); Circle(x-3, y+3, 2, col); }
        else if (id == 1) { Rect(x-5, y-4, 4, 3, col); Rect(x, y-4, 4, 3, col); Rect(x-3, y, 4, 3, Mix(col,125)); }
        else if (id == 2) { Circle(x, y, 4, col); Rect(x+3, y-1, 3, 2, G_ORANGE); Px(x+1, y-2, G_BG); }
        else              { Rect(x-3, y-5, 6, 3, col); Rect(x-1, y-2, 3, 4, Mix(col,125)); }
    }
    void IcoBars(int x, int y) {
        Rect(x, y, 5, 1, Mix(G_YELLOW,70)); Rect(x, y+2, 5, 1, G_YELLOW); Rect(x, y+4, 5, 1, Mix(G_YELLOW,50));
    }
    // 左侧计分徽章：图标 + 数字
    // v35：HUD 分数原来用 3x5 的极小点阵数字，小屏上一眼根本看不出是"分数"，
    // 用户反馈"游戏没有分数"多半就是这个原因。这里补一个 2 倍放大的数字
    // （6x10），HUD 徽章高度同步放到 10，正好占满顶部一行。
    void DrawNum2(int x, int y, int v, lv_color_t c) {
        if (v < 0) v = 0; else if (v > 9999) v = 9999;
        const int n = Digits(v);
        int d[4] = {0, 0, 0, 0};
        for (int k = n - 1, t = v; k >= 0; --k, t /= 10) d[k] = t % 10;
        for (int k = 0; k < n; ++k) {
            const uint8_t* g = &DIG[d[k] * 5];
            for (int r = 0; r < 5; ++r)
                for (int b = 0; b < 3; ++b)
                    if (g[r] & (4 >> b)) Rect(x + k * 7 + b * 2, y + r * 2, 2, 2, c);
        }
    }
    void HudLeft(int ico, int value) {
        const int w = 15 + Digits(value) * 7;
        ChipBg(6, 0, w, 10);
        Ico(ico, 11, 5);
        DrawNum2(18, 0, value, G_WHITE);
    }
    // 右侧辅助徽章（命数 / 消行）
    int HudRightW(int units) { return units * 7 + 6; }
    void HudRight(int w) { ChipBg(154 - w, 0, w, 9); }
    // 像素鸟水管
    void DrawPipe(int x, int y, int w, int h, bool isTop) {
        if (h < 1) return;
        Rect(x + 1, y, w - 2, h, G_PIPE);
        Rect(x + 1, y, 2, h, Mix(G_PIPE, 128));
        Rect(x + w - 3, y, 2, h, Mix(G_PIPE, 68));
        const int ry = isTop ? y + h - 4 : y;
        Rect(x - 1, ry, w + 2, 4, Mix(G_PIPE, 112));
        Rect(x - 1, ry, w + 2, 1, Mix(G_PIPE, 138));
        Rect(x - 1, ry + 3, w + 2, 1, Mix(G_PIPE, 58));
    }
    void Hide(lv_obj_t* o, bool h) {
        if (!o) return;
        if (h) lv_obj_add_flag(o, LV_OBJ_FLAG_HIDDEN);
        else lv_obj_remove_flag(o, LV_OBJ_FLAG_HIDDEN);
    }

    lv_obj_t* Label(lv_obj_t* p, lv_color_t color, int x, int y, int w, const char* t) {
        lv_obj_t* l = lv_label_create(p);
        lv_obj_set_style_text_font(l, font_, 0);
        lv_obj_set_style_text_color(l, color, 0);
        lv_label_set_long_mode(l, LV_LABEL_LONG_MODE_CLIP);
        lv_obj_set_width(l, w);
        lv_obj_set_x(l, x); lv_obj_set_y(l, y);
        lv_label_set_text(l, t);
        return l;
    }

    // 退出即收摊：清掉画布像素、把四局状态全部停摆并复位，不留任何"半局"
    // 或残留画面在后台。缓冲本身是一次性静态分配，保留它可避免反复
    // malloc/free 把 PSRAM 打碎；清的是内容，不是反复申请内存。
    void ResetGames() {
        if (buf_) {
            const uint16_t bg = To565(G_BG);
            for (int i = 0; i < 160 * 128; ++i) buf_[i] = bg;
        }
        snake_.dead = true; snake_.paused = true; snake_.step = 0;
        br_.dead = true; br_.paused = true;
        fl_.dead = true; fl_.paused = true;
        tet_.dead = true; tet_.paused = true; tet_.fall = 0;
        pending_draw_ = false; msg_hint_ = false;
        last_draw_ms_ = 0; tick_ms_ = 0;
        launcher_drawn_ = false;
        HideMsg();
    }
    // board.cc 离开游戏页时调用
    void OnLeave() {
        ResetGames();
        screen_ = kLauncher;
        selected_ = kSnake;
        if (canvas_) lv_obj_invalidate(canvas_);
    }

    void SetScreen() {
        const bool launcher = (screen_ == kLauncher);
        for (int i = 0; i < 4; ++i) Hide(gname_[i], !launcher);
        Hide(title_, !launcher);
        Hide(hint_, !launcher);  // 进游戏后底栏文案会压在棋盘上，直接藏掉
    }

    // ---------- 启动器 ----------
    void DrawLauncher() {
        Clear(G_BG);
        // 卡片仅 70 宽，用简称避免文字被裁
        const int cx[4] = {7, 83, 7, 83};
        const int cy[4] = {24, 24, 62, 62};
        const int cw = 70, ch = 34;
        const char* names[4] = {"贪吃蛇", "打砖块", "小鸟", "方块"};
        const lv_color_t icoc[4] = {G_GREEN, G_ORANGE, G_WARM, G_CYAN};
        for (int i = 0; i < 4; ++i) {
            const bool sel = (i == static_cast<int>(selected_));
            const lv_color_t base = sel ? G_PANEL2 : G_PANEL;
            if (sel) RRect(cx[i] - 2, cy[i] - 2, cw + 4, ch + 4, 6, G_WARM);  // 选中发光边
            RRect(cx[i], cy[i], cw, ch, 4, base);
            for (int k = 4; k < cw - 4; ++k) Px(cx[i] + k, cy[i] + 1, Mix(base, 155));  // 顶部高光
            IcoBig(i, cx[i] + 11, cy[i] + 17, icoc[i]);
            lv_label_set_text(gname_[i], names[i]);
            lv_obj_set_style_text_color(gname_[i], sel ? G_WARM : G_INK, 0);
            lv_obj_set_x(gname_[i], cx[i] + 24);
            lv_obj_set_y(gname_[i], cy[i] + 10);
        }
        // v30：v29 的 transform 80% 缩放 + 负字距叠加，字全挤在一起看不清，
        // y=113 也贴着屏幕底边。这里去掉缩放、用空格分段、提亮颜色，
        // 并上移到 y=100（下排卡片到 y=96，正好留出底栏）。
        lv_label_set_text(hint_, "A 进   B/C 选   D 退");
        lv_obj_set_style_text_color(hint_, G_WARM, 0);
        lv_obj_set_style_text_letter_space(hint_, 0, 0);
        lv_obj_set_style_transform_scale_x(hint_, 256, 0);
        lv_obj_set_style_transform_scale_y(hint_, 256, 0);
        lv_obj_set_x(hint_, 6); lv_obj_set_y(hint_, 100);
        HideMsg();
    }
    void EnterGame(Game g) {
        current_ = g; screen_ = kPlay;
        if (g == kSnake) SnakeReset();
        else if (g == kBreakout) BrReset();
        else if (g == kFlappy) FlReset();
        else if (g == kTetris) TetReset();
        SetScreen();
        ShowGameHint();
        GameSfx(desktop_sfx::kStart);   // 开局音：确认"已经进游戏了"
    }
    void ExitToLauncher() {
        ResetGames();            // 退回列表 = 本局结束，状态和画布立刻清干净
        screen_ = kLauncher;
        launcher_drawn_ = false;
        SetScreen();
        DrawFrame(lv_tick_get(), true);   // 强制当帧把启动器画回来
    }
    // ---- 四个游戏共用的长按语义 ----
    bool IsDead() const {
        switch (current_) {
            case kSnake: return snake_.dead;
            case kBreakout: return br_.dead;
            case kFlappy: return fl_.dead;
            case kTetris: return tet_.dead;
            default: return false;
        }
    }
    bool IsPaused() const {
        switch (current_) {
            case kSnake: return snake_.paused;
            case kBreakout: return br_.paused;
            case kFlappy: return fl_.paused;
            case kTetris: return tet_.paused;
            default: return false;
        }
    }
    void SetPaused(bool p) {
        switch (current_) {
            case kSnake: snake_.paused = p; break;
            case kBreakout: br_.paused = p; break;
            case kFlappy: fl_.paused = p; break;
            case kTetris: tet_.paused = p; break;
            default: break;
        }
        if (!p) HideMsg();
    }
    void TogglePause() {
        if (IsDead()) return;
        SetPaused(!IsPaused());
    }
    void Restart() {
        if (current_ == kSnake) SnakeReset();
        else if (current_ == kBreakout) BrReset();
        else if (current_ == kFlappy) FlReset();
        else TetReset();
        screen_ = kPlay;
        SetScreen();
        ShowGameHint();
    }
    // D 长按：本局结束，退回列表并直接回主页
    void EndAndHome() {
        ExitToLauncher();
        GameGotoHome();
    }
    // 进游戏后短暂显示该游戏的键位，2 秒后自动消失
    void ShowGameHint() {
        if (!msg_) return;
        const char* t = "";
        switch (current_) {
            case kSnake: t = "A上 B下 C左 D右"; break;
            case kBreakout: t = "A发球 B暂停 C左 D右"; break;
            case kFlappy: t = "任意键拍翅"; break;
            case kTetris: t = "A转 B落 C左 D右"; break;
            default: break;
        }
        lv_label_set_text(msg_, t);
        lv_obj_set_style_text_color(msg_, G_WARM, 0);
        lv_obj_set_style_bg_color(msg_, G_PANEL2, 0);
        lv_obj_set_style_bg_opa(msg_, LV_OPA_90, 0);
        lv_obj_set_style_pad_all(msg_, 2, 0);
        lv_obj_set_style_radius(msg_, 3, 0);
        lv_obj_set_x(msg_, 6); lv_obj_set_y(msg_, 100);
        Hide(msg_, false);
        msg_hint_ = true;
        hint_until_ = lv_tick_get() + 2000;
    }

    // ---------- 贪吃蛇 ----------
    struct { int* seg; int len, dir, ndir, score; int foodx, foody; int step; bool dead, paused; } snake_;
    void SnakeSpawnFood() {
        for (;;) {
            int c = static_cast<int>(esp_random() % 24);
            int r = static_cast<int>(esp_random() % 18);
            bool on = false;
            for (int i = 0; i < snake_.len; ++i)
                if ((snake_.seg[i] & 0xFF) == c && ((snake_.seg[i] >> 8) & 0xFF) == r) { on = true; break; }
            if (!on) { snake_.foodx = c; snake_.foody = r; return; }
        }
    }
    void SnakeReset() {
        snake_.len = 3; snake_.dir = 1; snake_.ndir = 1; snake_.dead = false; snake_.paused = false;
        snake_.score = 0; snake_.step = 0;
        int cx = 12, cy = 9;
        for (int i = 0; i < snake_.len; ++i) snake_.seg[i] = ((cy & 0xFF) << 8) | ((cx - i) & 0xFF);
        SnakeSpawnFood();
        HideMsg();
    }
    void SnakeStep() {
        if (snake_.paused || snake_.dead) return;
        if (snake_.ndir == (snake_.dir + 2) % 4) snake_.ndir = snake_.dir;  // 禁止反向
        snake_.dir = snake_.ndir;
        int head = snake_.seg[0];
        int col = head & 0xFF, row = (head >> 8) & 0xFF;
        int dcol = 0, drow = 0;
        if (snake_.dir == 0) drow = -1; else if (snake_.dir == 1) dcol = 1;
        else if (snake_.dir == 2) drow = 1; else dcol = -1;
        int nc = col + dcol, nr = row + drow;
        if (nc < 0 || nc >= 24 || nr < 0 || nr >= 18) { snake_.dead = true; GameSfx(desktop_sfx::kDie); return; }
        bool eat = (nc == snake_.foodx && nr == snake_.foody);
        // 不吃食时尾巴会前移，所以自检跳过最后一节；吃食时尾巴保留，全检。
        int check_len = snake_.len - (eat ? 0 : 1);
        for (int i = 0; i < check_len; ++i) {
            int sx = snake_.seg[i] & 0xFF, sy = (snake_.seg[i] >> 8) & 0xFF;
            if (sx == nc && sy == nr) { snake_.dead = true; GameSfx(desktop_sfx::kDie); return; }
        }
        if (eat) {
            for (int i = snake_.len; i > 0; --i) snake_.seg[i] = snake_.seg[i - 1];
            ++snake_.len;
        } else {
            for (int i = snake_.len - 1; i > 0; --i) snake_.seg[i] = snake_.seg[i - 1];
        }
        snake_.seg[0] = ((nr & 0xFF) << 8) | (nc & 0xFF);
        if (eat) { ++snake_.score; GameSfx(desktop_sfx::kEat); SnakeSpawnFood(); }
    }
    void SnakeDraw() {
        Clear(G_BG);
        RFrame(4, 10, 152, 114, 5, G_EDGE);   // 圆角外框（只描边，省 1.7 万次像素写）
        RFrame(5, 11, 150, 112, 4, G_PANEL);  // 面板描边，内部即棋盘底
        const lv_color_t dot = Mix(G_BG, 190);  // 极暗格点，增加质感
        for (int gy = 0; gy < 18; ++gy)
            for (int gx = 0; gx < 24; ++gx) Px(6 + gx * 6 + 3, 12 + gy * 6 + 3, dot);
        // 食物：苹果
        const int fx = 6 + snake_.foodx * 6, fy = 12 + snake_.foody * 6;
        Px(fx + 3, fy + 1, Mix(G_GREEN, 110));  // 梗
        Circle(fx + 3, fy + 4, 2, G_RED);
        Px(fx + 2, fy + 2, G_WHITE);            // 高光
        // 蛇：尾→头，圆形串珠 + 渐变 + 眼睛
        for (int i = snake_.len - 1; i >= 0; --i) {
            const int sx = snake_.seg[i] & 0xFF, sy = (snake_.seg[i] >> 8) & 0xFF;
            const int tp = (snake_.len > 1) ? (i * 100) / (snake_.len - 1) : 0;
            const int x = 6 + sx * 6 + 3, y = 12 + sy * 6 + 3;
            if (i == 0) {                       // 头：更大 + 眼睛
                Circle(x, y, 3, Mix(G_GREEN, 130));
                if (snake_.dir == 1)      { Px(x + 2, y - 2, G_WHITE); Px(x + 2, y + 2, G_WHITE); }
                else if (snake_.dir == 3) { Px(x - 2, y - 2, G_WHITE); Px(x - 2, y + 2, G_WHITE); }
                else if (snake_.dir == 0) { Px(x - 2, y - 2, G_WHITE); Px(x + 2, y - 2, G_WHITE); }
                else                      { Px(x - 2, y + 2, G_WHITE); Px(x + 2, y + 2, G_WHITE); }
            } else {
                Circle(x, y, 2, Mix(G_GREEN, 115 - tp * 45 / 100));
            }
        }
        HudLeft(0, snake_.score);  // 苹果图标 + 得分
        if (snake_.dead) { char b[48]; std::snprintf(b, sizeof(b), "结束  吃到 %d", snake_.score); ShowMsg(b); }
        else if (snake_.paused) ShowMsg("已暂停  C 长按继续");
        else HideMsg();
    }

    // ---------- 打砖块 ----------
    struct { int px, py, bx, by, bvx, bvy; int* bricks; int score, lives, level; int spd; bool launched, dead, paused; } br_;
    void BrReset() {
        br_.px = 72; br_.py = 112; br_.bx = 80; br_.by = 108; br_.bvx = 1; br_.bvy = -1;
        br_.launched = false; br_.score = 0; br_.lives = 3; br_.level = 1;
        // 每帧走 spd 个 1px 子步：2 = 60px/s（默认），B 短按可加到 4（120px/s）。
        br_.spd = 2;
        br_.dead = false; br_.paused = false;
        for (int i = 0; i < 24; ++i) br_.bricks[i] = 1;
        HideMsg();
    }
    void BrStep() {
        if (br_.dead) return;
        if (!br_.launched) { br_.bx = br_.px + 13; br_.by = br_.py - 3; return; }
        br_.bx += br_.bvx; br_.by += br_.bvy;
        if (br_.bx < 7) { br_.bx = 7; br_.bvx = -br_.bvx; }
        if (br_.bx > 152) { br_.bx = 152; br_.bvx = -br_.bvx; }
        if (br_.by < 14) { br_.by = 14; br_.bvy = -br_.bvy; }
        if (br_.by >= br_.py - 3 && br_.by <= br_.py + 4 && br_.bx >= br_.px && br_.bx <= br_.px + 26) {
            br_.bvy = -std::abs(br_.bvy); GameSfx(desktop_sfx::kHit);
        }
        for (int r = 0; r < 4; ++r) for (int c = 0; c < 6; ++c) {
            int i = r * 6 + c;
            if (!br_.bricks[i]) continue;
            int bx = 10 + c * 23, by = 16 + r * 9;
            if (br_.bx + 2 >= bx && br_.bx - 2 <= bx + 20 && br_.by >= by && br_.by <= by + 7) {
                br_.bricks[i] = 0; br_.score += 10; br_.bvy = -br_.bvy; GameSfx(desktop_sfx::kEat);
            }
        }
        if (br_.by > 122) {
            --br_.lives; GameSfx(desktop_sfx::kDie);
            if (br_.lives <= 0) { br_.dead = true; return; }
            br_.launched = false; br_.bx = br_.px + 13; br_.by = br_.py - 3;
        }
        // v35：砖块全部清空 → 通关进下一关。
        // 以前完全没有这个判定，24 块打完球还在空场里来回弹，永远不结束，
        // 看起来就是"只有一关、通关也不会停"。
        int left = 0;
        for (int i = 0; i < 24; ++i) if (br_.bricks[i]) ++left;
        if (left == 0) {
            ++br_.level;
            br_.score += 100 + br_.level * 20;          // 过关奖励
            const int sp = br_.level < 2 ? 1 : 2;        // 球速最多升到 2 档，再快接不住
            br_.bvx = br_.bvx >= 0 ? sp : -sp;
            br_.bvy = -sp;
            br_.launched = false;
            br_.bx = br_.px + 13; br_.by = br_.py - 3;
            for (int i = 0; i < 24; ++i) br_.bricks[i] = 1;
            GameSfx(desktop_sfx::kClear);
        }
    }
    void BrDraw() {
        Clear(G_BG);
        RFrame(4, 10, 152, 114, 5, G_EDGE);
        RFrame(5, 11, 150, 112, 4, G_PANEL);
        const lv_color_t rowc[4] = {G_RED, G_ORANGE, G_WARM, G_YELLOW};  // 按行分色
        for (int r = 0; r < 4; ++r) for (int c = 0; c < 6; ++c)
            if (br_.bricks[r * 6 + c]) Block3d(10 + c * 23, 16 + r * 9, 20, 7, 2, rowc[r]);
        Block3d(br_.px, br_.py, 26, 5, 2, G_CYAN);   // 立体圆角挡板
        Circle(br_.bx, br_.by, 2, G_WHITE);          // 白球 + 高光
        Px(br_.bx - 1, br_.by - 1, G_WHITE);
        HudLeft(1, br_.score);                       // 砖块图标 + 得分
        const int lw = HudRightW(br_.lives);         // 右侧：挡板图标 = 剩余命数
        HudRight(lw);
        for (int i = 0; i < br_.lives; ++i) IcoPaddle(154 - lw + 4 + i * 7, 3, G_CYAN);
        if (br_.dead) { char b[48]; std::snprintf(b, sizeof(b), "结束  得分 %d", br_.score); ShowMsg(b); }
        else if (br_.paused) ShowMsg("已暂停  B 长按继续");
        else if (!br_.launched) {
            if (br_.level > 1) { char b[48]; std::snprintf(b, sizeof(b), "第 %d 关  A 发射", br_.level); ShowMsg(b); }
            else ShowMsg("A 发射 B 加速 C/D 移动");
        }
        else HideMsg();
    }

    // ---------- 像素鸟 ----------
    struct { int by, bvy; int px[4], gap[4], scored[4]; int score; bool dead, paused; } fl_;
    void FlReset() {
        fl_.by = 64; fl_.bvy = 0; fl_.score = 0; fl_.dead = false; fl_.paused = false;
        for (int i = 0; i < 4; ++i) { fl_.px[i] = 100 + i * 46; fl_.gap[i] = 20 + static_cast<int>(esp_random() % 48); fl_.scored[i] = 0; }
        HideMsg();
    }
    void FlStep(int64_t dt) {
        if (fl_.dead) return;
        // v28：原来每帧 +1、上限 6，在 25ms 帧率下是 240px/s，半秒就掉到底，
        // 按键根本来不及。现在重力上限砍到 3，并把动画帧降到 33ms。
        fl_.bvy += 1; if (fl_.bvy > 3) fl_.bvy = 3;
        fl_.by += fl_.bvy; if (fl_.by < 10) { fl_.by = 10; fl_.bvy = 0; }
        if (fl_.by > 116) { fl_.dead = true; GameSfx(desktop_sfx::kDie); return; }
        // 管道也放慢到 1px/帧，并且重生时接到最右侧管道后面，保持固定 46px 间距。
        int rightmost = -1000;
        for (int i = 0; i < 4; ++i) rightmost = std::max(rightmost, fl_.px[i]);
        for (int i = 0; i < 4; ++i) {
            fl_.px[i] -= 1;
            if (fl_.px[i] < -14) {
                rightmost += 46;
                fl_.px[i] = rightmost;
                fl_.gap[i] = 20 + static_cast<int>(esp_random() % 48);
                fl_.scored[i] = 0;
            }
            if (!fl_.scored[i] && fl_.px[i] + 12 < 32) { fl_.scored[i] = 1; ++fl_.score; GameSfx(desktop_sfx::kEat); }
            int g = fl_.gap[i];
            if (32 + 5 > fl_.px[i] && 32 - 5 < fl_.px[i] + 12) {
                if (fl_.by - 4 < g || fl_.by + 4 > g + 42) { fl_.dead = true; GameSfx(desktop_sfx::kDie); return; }
            }
        }
        (void)dt;
    }
    void FlDraw() {
        Clear(G_SKY);
        // 远景云
        const lv_color_t cloud = Mix(G_SKY, 155);
        Circle(58, 24, 3, cloud); Circle(62, 23, 4, cloud); Circle(67, 24, 3, cloud);
        Circle(122, 34, 3, cloud); Circle(126, 33, 4, cloud); Circle(131, 34, 3, cloud);
        // 地面：草 + 土
        Rect(0, 120, 160, 8, G_DIRT);
        Rect(0, 120, 160, 2, G_GRASS);
        for (int i = 0; i < 16; ++i) Px(5 + i * 10, 121, G_GRASS);
        // 水管
        for (int i = 0; i < 4; ++i) {
            const int p = fl_.px[i], g = fl_.gap[i];
            DrawPipe(p, 14, 12, g - 14, true);
            DrawPipe(p, g + 42, 12, 120 - (g + 42), false);
        }
        // 小鸟：身 + 翅 + 眼 + 喙
        const int bx = 34, by = fl_.by;
        Circle(bx, by, 5, Mix(G_WARM, 85));
        Circle(bx, by - 1, 4, G_WARM);
        Rect(bx - 4, by, 3, 3, Mix(G_WARM, 62));
        Px(bx + 2, by - 2, G_WHITE);
        Px(bx + 3, by - 2, G_BG);
        Rect(bx + 4, by, 3, 2, G_ORANGE);
        HudLeft(2, fl_.score);  // 小鸟图标 + 得分
        if (fl_.dead) { char b[48]; std::snprintf(b, sizeof(b), "结束  得分 %d", fl_.score); ShowMsg(b); }
        else if (fl_.paused) ShowMsg("已暂停  C 长按继续");
        else HideMsg();
    }

    // ---------- 俄罗斯方块 ----------
    static constexpr int8_t PIECE[7][4][4][2] = {
        {{{1,0},{0,1},{1,1},{2,1}}, {{1,0},{1,1},{2,1},{1,2}}, {{0,1},{1,1},{2,1},{1,2}}, {{1,0},{0,1},{1,1},{1,2}}}, // T
        {{{0,0},{0,1},{1,1},{2,1}}, {{1,0},{2,0},{1,1},{1,2}}, {{0,1},{1,1},{2,1},{2,2}}, {{1,0},{1,1},{0,2},{1,2}}}, // J
        {{{2,0},{0,1},{1,1},{2,1}}, {{1,0},{1,1},{1,2},{2,2}}, {{0,1},{1,1},{2,1},{0,2}}, {{0,0},{1,0},{1,1},{1,2}}}, // L
        {{{1,0},{2,0},{1,1},{2,1}}, {{1,0},{2,0},{1,1},{2,1}}, {{1,0},{2,0},{1,1},{2,1}}, {{1,0},{2,0},{1,1},{2,1}}}, // O
        {{{1,0},{2,0},{0,1},{1,1}}, {{1,0},{1,1},{2,1},{2,2}}, {{1,1},{2,1},{0,2},{1,2}}, {{0,0},{0,1},{1,1},{1,2}}}, // S
        {{{0,0},{1,0},{1,1},{2,1}}, {{2,0},{1,1},{2,1},{1,2}}, {{0,1},{1,1},{1,2},{2,2}}, {{1,0},{0,1},{1,1},{0,2}}}, // Z
        {{{0,0},{1,0},{2,0},{3,0}}, {{2,0},{2,1},{2,2},{2,3}}, {{0,1},{1,1},{2,1},{3,1}}, {{1,0},{1,1},{1,2},{1,3}}}, // I
    };
    struct { uint8_t* well; int cur, curx, cury, rot, next; int score, lines; bool dead, paused; int fall; } tet_;
    bool TetHit(int type, int x, int y, int r) {
        for (int i = 0; i < 4; ++i) {
            int wx = x + PIECE[type][r][i][0], wy = y + PIECE[type][r][i][1];
            if (wx < 0 || wx >= 10 || wy >= 18) return true;
            if (wy >= 0 && tet_.well[wy * 10 + wx]) return true;
        }
        return false;
    }
    void TetSpawn() {
        tet_.cur = tet_.next; tet_.next = static_cast<int>(esp_random() % 7);
        tet_.curx = 3; tet_.cury = 0; tet_.rot = 0;
        if (TetHit(tet_.cur, tet_.curx, tet_.cury, 0)) { tet_.dead = true; GameSfx(desktop_sfx::kDie); }
    }
    void TetReset() {
        // well 是堆指针，sizeof(指针) 只有 4~8 字节，必须按真实尺寸清
        if (tet_.well) std::memset(tet_.well, 0, 10 * 18);
        tet_.score = 0; tet_.lines = 0; tet_.dead = false; tet_.paused = false; tet_.fall = 0;
        tet_.next = static_cast<int>(esp_random() % 7);
        TetSpawn();
        HideMsg();
    }
    void TetLock() {
        for (int i = 0; i < 4; ++i) {
            int wx = tet_.curx + PIECE[tet_.cur][tet_.rot][i][0];
            int wy = tet_.cury + PIECE[tet_.cur][tet_.rot][i][1];
            if (wy >= 0 && wy < 18 && wx >= 0 && wx < 10) tet_.well[wy * 10 + wx] = static_cast<uint8_t>(tet_.cur + 1);
        }
        int cleared = 0;
        for (int y = 17; y >= 0; --y) {
            bool full = true;
            for (int x = 0; x < 10; ++x) if (!tet_.well[y * 10 + x]) { full = false; break; }
            if (full) {
                for (int yy = y; yy > 0; --yy) for (int x = 0; x < 10; ++x) tet_.well[yy * 10 + x] = tet_.well[(yy - 1) * 10 + x];
                for (int x = 0; x < 10; ++x) tet_.well[x] = 0;
                ++cleared; ++y;
            }
        }
        if (cleared) { tet_.lines += cleared; tet_.score += (cleared == 1 ? 100 : cleared == 2 ? 300 : cleared == 3 ? 500 : 800); GameSfx(desktop_sfx::kClear); }
        TetSpawn();
    }
    void TetStep() {
        if (tet_.dead) return;
        if (!TetHit(tet_.cur, tet_.curx, tet_.cury + 1, tet_.rot)) ++tet_.cury;
        else TetLock();
    }
    void TetMove(int dx) {
        if (tet_.dead) return;
        if (!TetHit(tet_.cur, tet_.curx + dx, tet_.cury, tet_.rot)) {
            tet_.curx += dx;
            GameSfx(desktop_sfx::kMove);   // 移动也有轻音，按键才有"手感"
        }
    }
    void TetRotate() {
        if (tet_.dead) return;
        int nr = (tet_.rot + 1) % 4;
        if (!TetHit(tet_.cur, tet_.curx, tet_.cury, nr)) {
            tet_.rot = nr;
            GameSfx(desktop_sfx::kTurn);
        }
    }
    void TetSoftDrop() {
        if (tet_.dead) return;
        if (!TetHit(tet_.cur, tet_.curx, tet_.cury + 1, tet_.rot)) { ++tet_.cury; tet_.score += 1; }
        else TetLock();
    }
    // B 单击 = 硬降：一路落到底再锁定，省掉长按软降的操作
    void TetHardDrop() {
        if (tet_.dead) return;
        int guard = 0;  // 防御：即使 TetHit 边界判断将来被改坏，也不会在 UI 任务里死循环
        while (!TetHit(tet_.cur, tet_.curx, tet_.cury + 1, tet_.rot) && ++guard < 40) {
            ++tet_.cury; tet_.score += 1;
        }
        GameSfx(desktop_sfx::kHit);
        TetLock();
    }
    void TetDraw() {
        Clear(G_BG);
        // 井格：圆角外框 + 深内底
        RFrame(18, 10, 68, 112, 5, G_EDGE);
        RRect(19, 11, 66, 110, 4, Mix(G_PANEL, 72));
        // 井格网格点：给空井一点质感
        const lv_color_t gdot = Mix(G_PANEL, 135);
        for (int gy = 0; gy <= 18; ++gy)
            for (int gx = 0; gx <= 10; ++gx) Px(21 + gx * 6, 13 + gy * 6, gdot);
        // 已落方块 + 当前方块（立体）
        for (int y = 0; y < 18; ++y) for (int x = 0; x < 10; ++x)
            if (tet_.well[y * 10 + x]) Block3d(21 + x * 6, 13 + y * 6, 6, 6, 1, PCOL[tet_.well[y * 10 + x] - 1]);
        for (int i = 0; i < 4; ++i) {
            const int wx = tet_.curx + PIECE[tet_.cur][tet_.rot][i][0];
            const int wy = tet_.cury + PIECE[tet_.cur][tet_.rot][i][1];
            if (wy >= 0) Block3d(21 + wx * 6, 13 + wy * 6, 6, 6, 1, PCOL[tet_.cur]);
        }
        // 预览窗：圆角
        RFrame(96, 16, 54, 44, 4, G_EDGE);
        RRect(97, 17, 52, 42, 3, Mix(G_PANEL, 86));
        for (int i = 0; i < 4; ++i) {
            const int ox = PIECE[tet_.next][0][i][0], oy = PIECE[tet_.next][0][i][1];
            Block3d(104 + ox * 8, 25 + oy * 8, 7, 7, 1, PCOL[tet_.next]);
        }
        HudLeft(3, tet_.score);                    // 方块图标 + 得分
        const int lw2 = 14 + Digits(tet_.lines) * 4;  // 右侧：叠行图标 + 消行数
        HudRight(lw2);
        IcoBars(154 - lw2 + 4, 3);
        DrawNum(154 - lw2 + 11, 2, tet_.lines, G_WHITE);
        if (tet_.dead) { char b[48]; std::snprintf(b, sizeof(b), "结束 %d分 %d行", tet_.score, tet_.lines); ShowMsg(b); }
        else if (tet_.paused) ShowMsg("已暂停  C 长按继续");
        else HideMsg();
    }

    // 状态提示：每帧都会调一次，文字没变就不重复 set_text（否则 LVGL 每帧重排标签）
    void ShowMsg(const char* m) {
        if (!msg_) return;
        msg_hint_ = false;
        if (msg_shown_ && std::strcmp(msg_last_, m) == 0) { Hide(msg_, false); return; }
        std::strncpy(msg_last_, m, sizeof(msg_last_) - 1);
        msg_last_[sizeof(msg_last_) - 1] = '\0';
        msg_shown_ = true;
        lv_label_set_text(msg_, m);
        lv_obj_set_style_text_color(msg_, G_WARM, 0);
        lv_obj_set_style_bg_opa(msg_, LV_OPA_TRANSP, 0);
        lv_obj_set_style_pad_all(msg_, 0, 0);
        lv_obj_set_x(msg_, 8); lv_obj_set_y(msg_, 56);
        Hide(msg_, false);
    }
    void HideMsg() {
        if (!msg_) return;
        Hide(msg_, true);
        msg_shown_ = false;
        msg_hint_ = false;
    }

    // ---------- 成员 ----------
    const lv_font_t* font_ = nullptr;
    DesktopRuntime* rt_ = nullptr;
    lv_obj_t* canvas_ = nullptr;
    lv_obj_t* title_ = nullptr;
    lv_obj_t* gname_[4] = {};
    lv_obj_t* msg_ = nullptr;
    lv_obj_t* hint_ = nullptr;
    Screen screen_ = kLauncher;
    Game selected_ = kSnake;
    Game current_ = kSnake;
    int64_t tick_ms_ = 0;
    int64_t last_draw_ms_ = 0;
    bool pending_draw_ = false;
    uint32_t tick_count_ = 0;
    int launcher_key_ = -1;
    bool launcher_drawn_ = false;
    bool msg_hint_ = false;      // 当前显示的是"键位提示"（会自动消失）
    int64_t hint_until_ = 0;
    bool msg_shown_ = false;
    char msg_last_[32] = {};
};

}  // namespace dui
