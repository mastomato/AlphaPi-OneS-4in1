#include "desktop_keys.h"

#include "driver/gpio.h"

#include "board_config.h"

namespace radio {

DesktopKeys& DesktopKeys::Instance() {
    static DesktopKeys instance;
    return instance;
}

bool DesktopKeys::Init() {
    if (ready_) {
        return true;
    }
    gpio_config_t keys = {};
    keys.pin_bit_mask = (1ULL << board::kKeyA) | (1ULL << board::kKeyB) |
                        (1ULL << board::kKeyC) | (1ULL << board::kKeyD);
    keys.mode = GPIO_MODE_INPUT;
    keys.pull_up_en = GPIO_PULLUP_DISABLE;
    keys.pull_down_en = GPIO_PULLDOWN_ENABLE;
    keys.intr_type = GPIO_INTR_DISABLE;
    if (gpio_config(&keys) != ESP_OK) {
        return false;
    }
    ready_ = true;
    cached_.store(0);
    return true;
}

uint8_t DesktopKeys::Read() {
    if (!ready_) {
        return 0xFF;
    }
    const uint8_t keys =
        static_cast<uint8_t>(
            (gpio_get_level(board::kKeyA) ? board::kKeyMaskA : 0) |
            (gpio_get_level(board::kKeyB) ? board::kKeyMaskB : 0) |
            (gpio_get_level(board::kKeyC) ? board::kKeyMaskC : 0) |
            (gpio_get_level(board::kKeyD) ? board::kKeyMaskD : 0));
    cached_.store(keys);
    polls_.fetch_add(1);
    return keys;
}

}  // namespace radio
