#include "desktop_radio.h"

namespace radio {

bool DesktopRadio::Start() {
    // Init() is idempotent and never aborts: a board without PSRAM reports
    // kError and the UI shows "电台暂不可用" instead of rebooting.
    return RadioPlayer::Instance().Init();
}

void DesktopRadio::Stop() { RadioPlayer::Instance().Stop(); }

void DesktopRadio::Play() {
    if (!Start()) {
        return;
    }
    RadioPlayer::Instance().Play(RadioPlayer::Instance().index());
}

void DesktopRadio::Pause() { RadioPlayer::Instance().Pause(); }

// 暂停状态只存在于 RadioPlayer 一处：这里若再存一份，两边漂移就会出现
// 「UI 显示暂停但流还在跑」这种只能靠实机才能发现的问题。
void DesktopRadio::TogglePlayPause() { RadioPlayer::Instance().Toggle(); }

// Station changes keep the transport state: a running stream restarts on the
// new station, a stopped one just moves the index. This is the v54 behaviour
// the radio page's key table was written against.
void DesktopRadio::NextStation() { RadioPlayer::Instance().Next(); }

void DesktopRadio::PreviousStation() { RadioPlayer::Instance().Previous(); }

void DesktopRadio::SelectStation(int index) { RadioPlayer::Instance().Select(index); }

void DesktopRadio::SetStationList(const Station* list, int count) {
    RadioPlayer::Instance().SetList(list, count);
}

void DesktopRadio::SetVolume(int volume) { RadioPlayer::Instance().SetVolume(volume); }

}  // namespace radio