#pragma once
#include <string>
#include <mutex>
#include <atomic>
#include <functional>
#include <vector>
#include "display.h"
#include "desktop_codec.h"
#include "desktop_radio.h"
#include "desktop_countdown.h"
#include "desktop_metro.h"
#include "desktop_stopwatch.h"
#include "st7789.h"
#include "esp_http_server.h"
#include "board.h"
class DesktopRuntime;
class DesktopDisplay final : public Display {
public:
 radio::Display lcd;
 std::recursive_mutex mutex;
 std::string status,chat,activation,emotion="neutral";
 std::atomic<bool> changed{true};
 DesktopDisplay(){width_=160;height_=128;lcd.Init();}
 void SetStatus(const char* s)override{std::lock_guard<std::recursive_mutex>l(mutex);status=s?s:"";changed=true;}
 void ShowNotification(const char* s,int duration=3000)override{SetStatus(s);}
 void SetChatMessage(const char*,const char* s)override{std::lock_guard<std::recursive_mutex>l(mutex);chat=s?s:"";changed=true;}
 bool SetEmotion(const char* value)override{std::lock_guard<std::recursive_mutex>l(mutex);emotion=value?value:"neutral";changed=true;return true;}
 void ClearChatMessages()override{SetChatMessage("","");}
 void SetupUI()override;
 void LvglPump();
 lv_display_t* lvgl_disp_=nullptr;
 std::atomic<bool> fb_dirty{false};
 // Tick bookkeeping for LVGL. Only the UI task drives LVGL, so no lock is
 // needed around the render path.
 int64_t last_tick_us_=0;
 int64_t last_flush_ms_=0;   // 整屏 DMA 提交节流，防止 SPI 队列积压拖死 UI 任务
 int64_t last_force_redraw_ms_=0;  // 每秒强制整屏重绘/提交的心跳，杜绝界面永久冻结
 // v34：最近一次「成功提交到面板」的时刻。draw_bitmap 返回错误时不再假装
 // 一切正常，而是交给 Recover() 重发面板命令自救。
 int64_t last_ok_flush_ms_=0;
 // v35：面板自救必须限频。不加限制时一次链路抖动会连续触发 Recover，
 // 而 Recover 里又要整屏重推，等于把 UI 任务按在重发命令上出不来
 // （表现就是按键全无反应、屏幕一点点变色）。
 int64_t last_recover_ms_=0;
protected:
 bool Lock(int=0)override{mutex.lock();return true;}
 void Unlock()override{mutex.unlock();}
};
class DesktopRuntime {
public:
 static DesktopRuntime* instance;
 DesktopDisplay display;
 DesktopCodec codec;
 radio::DesktopRadio radio;
 desktop_countdown::Timer countdown;
 // v39：节拍器。和倒计时一样是"纯软件工具页"，不碰网络，只是多一条音效通道。
 desktop_metro::Metro metro;
 // v47：计时器（秒表，正计时）。状态全由时间戳推导，切页不丢。
 desktop_stopwatch::Clock stopwatch;
 // v47：计时页改成一个目录，含三项：定时器（倒计时）/ 节拍器 / 计时器（秒表）。
 // 0 = 目录，1 = 倒计时，2 = 节拍器，3 = 秒表。以前节拍器只是倒计时页
 // 里"长按 B 切换"的隐藏子界面，藏得太深，等于没有入口。
 int timer_view=0;
 // 目录里当前选中的项（0 定时器 / 1 节拍器 / 2 计时器）。
 int timer_menu_sel=0;
 // 进目录或切子界面后的几秒里，底部提示先说清怎么返回。
 int64_t timer_hint_until=0;
 bool auto_chat=false,auto_play=false;
 // v56：进小智页就自动开一轮对话。ActivateDesktopVoice() 之后设备通常还在
 // kDeviceStateActivating（等服务器登录/激活），这时 ToggleChatState() 只会把
 // 状态拨回 Idle 并被忽略，所以真正起听要等状态落到 Idle 再补一次。
 // voice_auto_next = 下一次尝试时刻，voice_auto_deadline = 放弃时刻（5 秒）。
 bool voice_auto=false;
 bool voice_auto_sent=false;
 int64_t voice_auto_next=0;
 int64_t voice_auto_deadline=0;
 NetworkEventCallback network_callback;
 std::mutex state_mutex;
 std::string city="武汉",description="未更新",ssid,pass;
 double latitude=30.59,longitude=114.30;
 double temperature=0;int humidity=-1;
 bool have_weather=false;
 std::atomic<bool> weather_refresh{true};
 std::atomic<bool> dirty{true};
 // 切页按键守卫：一次按压导致切页后，松手/长按的残留事件不能被新页面解释成
 // 另一个功能键（v30 的「游戏目录单击 D 触发倒计时」就是这个原因）。
 std::atomic<int64_t> key_guard_until_ms_{0};
 std::atomic<bool> key_taps_reset_{false};
 std::atomic<uint32_t> ui_loops{0},ui_gap_us{0},ui_max_gap_us{0},render_us{0};
 std::atomic<bool> ap_enabled{false};
 std::atomic<bool> wifi_scan_active{false};
 // Set when the board boots without a saved network: the home screen then tells
 // the user to long press A. Opening the hotspot is always user initiated.
 std::atomic<bool> ap_advise{false};
 // True while a background task is bringing the hotspot up/down, so key presses
 // never queue up a second switch.
 std::atomic<bool> ap_busy{false};
 // Set by the WIFI_EVENT_AP_START handler. ap_enabled only means "we asked the
 // driver to run an AP"; ap_live means the beacon is actually on air. The two
 // differ when esp_wifi_set_mode() quietly refuses, which is exactly the case
 // that used to leave the screen showing a dead hotspot.
 std::atomic<bool> ap_live{false};
 int64_t ap_started_at=0;
 // Requested state, flipped the instant a key or the web page asks for a change.
 // The switch on screen follows THIS, not ap_enabled: the driver calls take
 // hundreds of milliseconds (and can fail), and waiting for them made every tap
 // look dead. A single long lived worker reconciles the driver to this flag.
 std::atomic<bool> ap_desired{false};
 std::atomic<bool> ap_failed{false};
 // Encoded driver failure for the config page: 10+code = set_mode, 20+code =
 // set_config, 30+code = start, 99 = started but no AP_START event. The board's
 // console is not on the USB port, so the screen has to carry the diagnosis.
 std::atomic<int> ap_err{0};
// True when the AP netif's DHCP server reports STARTED. Without it the phone
// associates but never gets an address, which looks exactly like "won't connect".
 std::atomic<bool> ap_dhcp{false};
// What the AP netif really holds, read back after the bring-up instead of being
// assumed. If the address stays 0.0.0.0 the DHCP server has nothing to hand out,
// and no amount of reconnecting from the phone will help.
 std::atomic<uint32_t> ap_ip{0};
 std::atomic<int> ap_chan{0};
// esp_err_t from the last esp_netif_dhcps_start(), so a failure names itself.
 std::atomic<int> ap_dhcp_err{0};
// Whether lwip considers the AP netif up. The DHCP server cannot exist while it
// is down, and dhcps_start() reports success anyway - so this is the state that
// explains an otherwise inexplicable "no address".
 std::atomic<bool> ap_netif_up{false};
// Set by WIFI_EVENT_AP_STAIPASSIGNED: the DHCP server really handed out a lease.
// Device count alone cannot tell a healthy link from one where the phone
// associates but never gets an address.
 std::atomic<bool> ap_lease{false};
// Station address on the home network, if any. Used by the web diagnostics.
 std::atomic<uint32_t> sta_ip{0};
// esp_netif_t* of the provisioning AP, created in OpenAP() and destroyed in
// CloseAP(). Kept as void* so this header does not have to pull in esp_netif.h.
 void* ap_netif=nullptr;
 std::atomic<int64_t> ap_apply_at{0};
 // Why the board last restarted. The console is not on the USB port, so this is
 // the only way the user can report "it rebooted" with any detail: ESP_RST_PANIC
 // means a crash, ESP_RST_BROWNOUT means the supply sagged when the radio keyed.
 int boot_reset=0;
 std::atomic<bool> ap_worker_up{false};
 void EnsureApWorker();
 void ApWorker();
 void OpenAPAsync(bool enable);
 // Forgets the network stored on the device and stops the driver from retrying
 // it. While a saved network is unreachable the station retries on every
 // disconnect, and on a single antenna those retries keep pulling the radio out
 // of the AP channel - the phone associates but never finishes DHCP. With the
 // config erased the station has nothing to retry, which is exactly the state
 // the vendor provisioning component runs in.
 void ResetSavedWifi();
 std::atomic<int64_t> wifi_reset_at{0};
 // Portal detection evidence, readable on the screen: D = DNS probes answered
 // over the AP, W = result of a loopback HTTP GET to 192.168.4.1/ping from the
 // board itself. W0 means the httpd is not reachable even locally; W1 with a
 // phone that still cannot load the page means the phone is using mobile data.
 std::atomic<int> portal_dns{0};
 std::atomic<bool> web_self_ok{false};
 // esp_err_t from the last httpd_start(). With no console this is the only way
 // to tell "the page is not being served" from "the phone sent it elsewhere".
 std::atomic<int> web_start_err{0};
 bool radio_started=false;
 // v56：电台改成「单一可编辑列表」——内置台和自定义台在同一张表里，网页
 // 可以逐条改名/改址/删除。持久化是 NVS 键 desk_radio/list，一整段多行文本
 // （每行 `名称|地址`，最多 radio::kMaxStations 条）。
 //
 // 旧模型（desk_radio/extras 只存自定义台，内置台追加在后面）保留为迁移
 // 输入：没有 list 但有 extras 时，一次性展开成完整列表并写回 list。
 //
 // 列表本体放 PSRAM：一条 Station 是 264 B，64 条约 17 KB，放内部 RAM 会
 // 挤掉本就很紧的 DIRAM。写列表（网页）和读列表（进收音机页）会同时发生，
 // 所以这张表有独立互斥锁——以前没有，因为写入口只有一个文本框。
 std::string radio_custom_url;    // 列表里第一条非内置默认台的地址（兼容旧接口）
 std::string radio_custom_name;
 std::string radio_edit_error;    // 最近一次列表写入失败的原因，给网页回 error
 std::vector<std::string> radio_list_urls;   // 当前完整列表（含内置台）
 std::vector<std::string> radio_list_names;
 // 递归锁：写入路径会互相调用（保存 -> 判断是否内置 -> 读当前表）。
 // mutable：GET /api/radio 在 const 查询里也要读这张表，写入路径随时可能
 // 正在替换它（网页 POST 跑在同一个 httpd 任务上，但 UI 任务也会读）。
 mutable std::recursive_mutex radio_list_mutex;
 radio::Station* radio_pool=nullptr;
 int radio_pool_count=0;
 void RebuildRadioList();
 void LoadRadioList();
 // 同步 radio_custom_url/name 这两个兼容旧接口的字段。调用方须已持有
 // radio_list_mutex（递归锁，内部再次加锁也安全）。
 void RadioListRefreshAlias();
 void SetRadioCustomUrl(const std::string& url,const std::string& name);
 // 整段替换完整列表（多行 `名称|地址`）。空串 = 恢复内置默认。
 void SetRadioExtras(const std::string& text);
 // v56：逐条编辑接口。失败返回 false，原因写在 radio_edit_error。
 bool RadioStationUpdate(int index,const std::string& name,const std::string& url);
 bool RadioStationDelete(int index);
 bool RadioStationAdd(const std::string& name,const std::string& url);
 bool RadioStationReset();
 bool RadioStationIsBuiltin(int index) const;
 int RadioStationCustomCount() const;
 // 停流 -> 等任务退 -> 换表 -> 夹索引。所有列表写入都必须走它。
 void ApplyRadioListChange();
 // 落盘（NVS 键 desk_radio/list）。超长（NVS 单串上限 4000 B）返回 false。
 bool RadioListSaveLocked(const std::vector<std::string>& urls,
                          const std::vector<std::string>& names);
 static constexpr size_t kRadioListMaxBytes = 3800;
 std::string RadioStationUrl() const;

 bool voice_pending=false;
 bool voice_cleanup_pending=false;
 bool radio_pending=false;
 int64_t radio_ready_at=0;
 int64_t voice_ready_at=0;
 // v35：语音页"一直挂在聆听中"的兜底计时。AutoStop 要等服务端检测到静音后
 // 下发停止，网络或服务端慢一点就会永远停在聆听状态。超过阈值就主动收一轮。
 int64_t listen_started_ms_=0;
 int selected=0;
 int64_t volume_overlay_until=0;
 int64_t volume_save_at=0;
 // Short press D on the radio page mutes / restores, like the standalone radio.
 // -1 means "not muted"; otherwise it holds the volume to come back to.
 int mute_saved_volume_=-1;
 void SetVolume(int value);
 void ToggleMute();
 httpd_handle_t server=nullptr;
 // Provisioning diagnostics. Everything here is visible on the device screen and
 // in /api/status, because this board's console is not wired to the USB port.
 std::atomic<int> web_error{0};
 std::atomic<uint32_t> http_requests{0};
 std::string http_last_path;
 DesktopRuntime();
 void StartNetwork();
 void OpenAP();
 void ConnectWifi(const std::string& name,const std::string& password);
 void StartWeb();
 void UiTask();
 void StartUiTask();
 std::atomic<bool> ui_started_{false};
 void WeatherTask();
 void Render();
 void Key(uint8_t key,int gesture);
 void Apply(int action);
 void GoTo(int page,bool quick=false);
 void CloseAP();
 void UseRadioList();
 bool SaveRegion(const char* json);
 std::string RegionJson();
 std::string SearchRegions(const std::string& query);
 std::string ScanWifi();
 static void WifiEvent(void*,const char*,int32_t,void*);
};
