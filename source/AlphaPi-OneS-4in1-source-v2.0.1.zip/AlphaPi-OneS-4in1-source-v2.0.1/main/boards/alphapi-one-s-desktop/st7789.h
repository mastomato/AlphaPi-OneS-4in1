#pragma once

// ST7789 160x128 屏幕驱动 —— AlphaPi One (ESP32-S3) 独立版
//
// 引脚与初始化参数取自 xiaozhi-esp32 boards/alphapi/alphapi-s3/config.h
// （已实机验证）：
//   SPI2: SCK=41, MOSI=42, MISO=47, CS=38, DC=40, RST=39, BL=37(背光 PWM)
//   ST7789: pclk=31.25MHz, swap_xy=true, mirror(true,false) => MADCTL 0x60
//   物理 128x160 -> 逻辑 160x128（横屏），RGB565
//
// 文本渲染：
//   - ASCII 用 8x16 点阵（ascii_font.h，95 字符）
//   - 中文用 16x16 点阵子集（cn_font.h，电台名用字）
//   - 未收录的中文显示为 □

#include <cstdint>
#include <cstddef>

namespace radio {

class Display {
public:
    Display() = default;
    // v54：临时实例（开机诊断页）用完就销毁，必须把帧缓冲/条带缓冲还给堆，
    // 否则内部 RAM 会白白少掉 5KB（这块板只剩 ~50KB 内部 RAM）。
    // 桌面那个实例是长生命周期成员，析构不会被执行，行为不受影响。
    ~Display();

    bool Init();

    void FillScreen(uint16_t color);
    void FillRect(int x, int y, int w, int h, uint16_t color);
    void DrawPixel(int x, int y, uint16_t color);

    // Copy an RGB565 rectangle into the framebuffer (LVGL flush path).
    void Blit(int x, int y, int w, int h, const uint16_t* pixels);

    // 坐标基准：逻辑横屏 160x128（x 向右, y 向下）
    int width() const { return 160; }
    int height() const { return 128; }

    // 文本渲染（UTF-8 混合：ASCII + 已收录汉字）
    // 返回下一个可用的 x 坐标
    int DrawText(int x, int y, const char* text, uint16_t color,
                 uint16_t bg_color);
    int DrawChar(int x, int y, uint32_t codepoint, uint16_t color,
                 uint16_t bg_color);

    // 放大的 ASCII 字符（8x16 点阵按 scale 倍绘制，如 scale=2 -> 16x32）。
    // 用于大号台号等图形化元素；仅支持 ASCII（0x20..0x7E）。
    int DrawCharScaled(int x, int y, char c, uint16_t color,
                       uint16_t bg_color, int scale);

    // 整行清屏（指定高度）
    void ClearRow(int y, int height);

    // 把帧缓冲分条带输出到 LCD（内部 160x128 RGB565）
    // 返回 false 表示这一帧没能完整提交出去（SPI/DMA 层报错）。
    bool Flush();

    // v47：只推送“真正被改过”的行。LVGL 是局部渲染的：表情动画一帧只脏
    // 一块几十像素的区域，但旧 Flush() 无条件把整屏 40 KB 重新推一遍，
    // 160x128 @26MHz 串行约 12.6 ms。小智说话时这个代价和 TTS 的 UART
    // 喂流直接抢同一个核。现在按行范围换算成条带，只发命中的那几条。
    void InvalidateRows(int y0, int y1);
    void InvalidateAll() { full_flush_ = true; }

    // v35：面板自救。只重发显存寻址与显示开命令，**不再重发 MADCTL**
    // （MADCTL 一旦被改成 0xc8，和 Init 时 swap_xy/mirror 算出的 0x60 不一致，
    //  画面会变成竖屏错位 + 整体偏色，越救越坏）。
    void Recover();

    // 最近一次 draw_bitmap 的错误码与失败计数，供 UI 泵判断是否需要自救
    int last_error() const { return last_error_; }
    int flush_fail_count() const { return flush_fail_count_; }

    void SetBacklight(int percent);  // 0-100

private:
    void DrawGlyph(int x, int y, const uint8_t* data, int width, int height,
                   uint16_t color, uint16_t bg_color);

    void* panel_ = nullptr;   // esp_lcd_panel_handle_t
    void* io_ = nullptr;      // esp_lcd_panel_io_handle_t（Recover 用）
    uint16_t* fb_ = nullptr;  // 帧缓冲（PSRAM，160*128，恒为标准 RGB565 小端）
    // 条带 DMA 缓冲，**必须放在内部 RAM**。
    // 之前是把整屏 40KB 从 PSRAM 直接交给 SPI DMA。ESP32-S2 的 PSRAM 与
    // 片内 SRAM 共用一路控制器：收音机解码任务持续读写 PSRAM 时，DMA 读
    // PSRAM 会被抢占，轻则像素错位（用户看到的"整体细微变色"），重则
    // 传输卡住让 draw_bitmap 一直等（"画面冻住、按键无反应"）。
    // 改成每次只搬 kBandRows 行到内部 RAM 再发，DMA 源与 PSRAM 完全无关。
    //
    // v36：**必须两块乒乓**。trans_queue_depth=1 时，esp_lcd 是「先把事务排进
    // 队列就返回」，要等到下一次调用才会 get_trans_result 阻塞等待上一笔完成。
    // 也就是说：填第 N 条带的缓冲时，第 N-1 条带的 DMA 还在读同一块内存
    // —— 结果是每条带都被"下一带的像素"覆盖一半，整屏文字上下重影、错位、
    // 颜色发花。两块缓冲交替使用后，被写的那块永远是两条带之前用完的，
    // 其传输在排队下一块时已经阻塞等待过了，绝对安全。
    uint16_t* band_buf_[2] = {nullptr, nullptr};
    // 8 行一条带：整屏 16 条；两条缓冲合计 160*8*2*2 = 5120 B，与原来单块
    // 16 行的占用量完全相同。条带越小，单次 DMA 占用时间越短。
    static constexpr int kBandRows = 8;
    bool initialized_ = false;
    int last_error_ = 0;
    int flush_fail_count_ = 0;
    // v47：待推送的行范围（含端点）。全屏重绘走 full_flush_。
    int dirty_y0_ = -1;
    int dirty_y1_ = -1;
    bool full_flush_ = true;
};

}  // namespace radio
