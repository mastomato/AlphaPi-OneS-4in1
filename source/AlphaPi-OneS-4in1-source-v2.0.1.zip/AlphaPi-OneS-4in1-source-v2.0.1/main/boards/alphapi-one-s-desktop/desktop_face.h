#pragma once
#include <string>
#include <cmath>
#include <algorithm>
#include <cstdlib>
#include "st7789.h"
#include "desktop_gfx.h"

// Redesigned vector face for the dark theme. No GIF decoder, no image buffers,
// no assets partition: everything is drawn per frame inside the UI task.
namespace desktop_face {
inline uint16_t C(int r,int g,int b){return ((r>>3)<<11)|((g>>2)<<5)|(b>>3);}
inline void Oval(radio::Display& lcd,int cx,int cy,int rx,int ry,uint16_t color){
 for(int y=cy-ry-1;y<=cy+ry+1;y++)for(int x=cx-rx-1;x<=cx+rx+1;x++){
  float dx=(x-cx)/static_cast<float>(rx),dy=(y-cy)/static_cast<float>(ry);
  float d=std::sqrt(dx*dx+dy*dy);
  int a=static_cast<int>((1.0f-d)*static_cast<float>(std::min(rx,ry))+127);
  if(a>0)gfx::Pixel(lcd,x,y,color,std::min(255,a));
 }
}
inline void Line(radio::Display& lcd,int x0,int y0,int x1,int y1,uint16_t c,int w=1){
 gfx::Line(lcd,x0,y0,x1,y1,w,c);
}
inline void Draw(radio::Display& lcd,const std::string& emotion,int state,int64_t ms){
 const uint16_t bg=C(14,20,32),ink=C(14,20,32),face=C(255,210,122),rim=C(143,227,240),
                blush=C(255,154,138),cool=C(143,227,240),dim=C(113,134,160),love=C(255,120,140);
 const std::string& e=emotion;
 const bool happy=e=="happy"||e=="laughing"||e=="funny"||e=="loving"||e=="winking"||e=="cool"||e=="delicious";
 const bool sad=e=="sad"||e=="crying"||e=="embarrassed";
 const bool angry=e=="angry";
 const bool sleepy=e=="sleepy";
 const bool surprised=e=="surprised"||e=="shocked";
 const bool thinking=state==4||e=="thinking"||e=="confused";
 const bool blink=(ms%4300)>4100;
 const bool speaking=state==6;
 const bool listening=state==5;

 Oval(lcd,80,50,21,21,rim);
 Oval(lcd,80,49,20,20,face);

 // eyes
 for(int cx:{72,88}){
  if(sleepy){Line(lcd,cx-3,46,cx+3,46,ink,2);Line(lcd,cx-3,47,cx+3,47,dim);}
  else if(e=="loving"){
   Oval(lcd,cx-2,45,2,2,love);Oval(lcd,cx+2,45,2,2,love);
   Line(lcd,cx-4,46,cx,50,love);Line(lcd,cx+4,46,cx,50,love);
  }
  else if(e=="winking"&&cx==88){Line(lcd,cx-3,46,cx+3,46,ink,2);}
  else if(angry){Line(lcd,cx-3,43,cx+3,46,ink,2);Oval(lcd,cx,47,2,2,ink);}
  else if(happy&&!blink){for(int x=-3;x<=3;++x)gfx::RoundRect(lcd,cx+x,45+x*x/4,1,2,0.5f,ink);}
  else if(blink){Line(lcd,cx-3,46,cx+3,46,ink,2);}
  else {Oval(lcd,cx+(thinking?1:0),46,2,3,ink);}
 }
 if(e=="cool"){
  gfx::RoundRect(lcd,64,42,15,6,2.0f,ink);gfx::RoundRect(lcd,81,42,15,6,2.0f,ink);
  gfx::RoundRect(lcd,79,44,2,2,1.0f,rim);
 }

 // mouth
 if(speaking){Oval(lcd,80,58,4,2+(ms/140)%4,ink);}
 else if(surprised){Oval(lcd,80,58,3,4,ink);}
 else if(e=="laughing"){Oval(lcd,80,59,6,4,ink);gfx::RoundRect(lcd,75,56,10,2,1.0f,face);}
 else if(e=="crying"||e=="sad"||e=="embarrassed"){
  for(int x=-6;x<=6;++x)gfx::RoundRect(lcd,80+x,62-(36-x*x)/10,1,2,0.5f,ink);
 }
 else if(angry){Line(lcd,75,60,85,60,ink,2);}
 else if(sleepy){Oval(lcd,80,58,2,1,ink);}
 else if(thinking){for(int i=0;i<3;++i)Oval(lcd,75+i*5,58,1,1,(ms/250)%3==i?ink:dim);}
 else {for(int x=-6;x<=6;++x)gfx::RoundRect(lcd,80+x,(sad?61:57)+(sad?-1:1)*(36-x*x)/10,1,2,0.5f,ink);}

 // decorations
 if(e=="happy"||e=="loving"||e=="embarrassed"||e=="delicious"){
  Oval(lcd,66,54,3,2,blush);Oval(lcd,94,54,3,2,blush);
 }
 if(e=="crying"){Oval(lcd,68,55,2,4,cool);Oval(lcd,92,55,2,4,cool);}
 if(e=="shocked"||e=="confused"){Oval(lcd,98,38,2,3,cool);}
 if(e=="angry"){
  Line(lcd,58,34,62,38,love,2);Line(lcd,62,34,58,38,love,2);
 }
 if(sleepy){
  int z=(ms/400)%3;
  gfx::RoundRect(lcd,100,34-z*6,6,1,0.5f,cool);gfx::RoundRect(lcd,100,40-z*6,6,1,0.5f,cool);Line(lcd,100,34-z*6,106,40-z*6,cool);
 }
 if(e=="delicious"){Oval(lcd,104,52,3,3,love);Line(lcd,104,55,104,60,love);}
 if(e=="loving"){
  for(int i=0;i<2;i++){
   int hy=28-((ms/300+i*20)%20);
   Oval(lcd,104+i*6,hy,2,2,love);Oval(lcd,107+i*6,hy,2,2,love);
   Line(lcd,102+i*6,hy+1,106+i*6,hy+5,love);
  }
 }
 if(listening){
  int h=2+(ms/180)%3;
  gfx::RoundRect(lcd,55,47-h,2,h*2,1.0f,cool);gfx::RoundRect(lcd,103,47-h,2,h*2,1.0f,cool);
 }
}
}
