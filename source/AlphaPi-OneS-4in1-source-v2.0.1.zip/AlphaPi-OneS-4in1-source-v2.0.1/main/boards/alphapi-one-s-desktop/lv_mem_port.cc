// LVGL 内存分配器移植：把 LVGL 的对象/样式/文本缓冲全部放到 PSRAM。
//
// 为什么要这么做（2026-11-14，v25）：
//   这块板子的内部 DRAM（dram0_0_seg 168 KB）被 .data + .bss 吃到 99.88%，
//   `idf.py size` 报 DIRAM 只剩 199 字节。其中最大的一块静态开销就是 LVGL
//   默认 builtin 分配器的 48 KB 静态池（lv_mem_core_builtin.c 的 work_mem_int）。
//   内部 RAM 归零的后果：httpd_start() 申请不到 8 KB 任务栈 + socket 表，
//   配网页永远显示「服务未启动」，而热点本身照旧能连、能发 IP——因为 WiFi
//   驱动的缓冲区是静态分配的，不受堆影响。这正是「手机能连、打不开 192.168.4.1」
//   的真正根因，和手机端设置无关。
//
//   板子上 2 MB PSRAM 一直闲着，所以这里把 LVGL 的分配整体改走 PSRAM，
//   换回约 48 KB 内部 DRAM 给 WiFi / lwip / httpd。
//
// 启用方式：sdkconfig 里 CONFIG_LV_USE_CUSTOM_MALLOC=y（LV_USE_STDLIB_MALLOC
// 变成 LV_STDLIB_CUSTOM）。此时 LVGL 不再链接自己的 builtin/clib 分配器，
// 而是调用下面这几个函数。
//
// 注意：LVGL 的块普遍很小（对象 ~200 B、样式几十 B），走 heap_caps 会比
// TLSF 略慢，但 160x128 的界面完全无感；PSRAM 拿不到时才回退内部堆。

#include "lvgl.h"

#if LV_USE_STDLIB_MALLOC == LV_STDLIB_CUSTOM

#include <cstddef>

#include "esp_heap_caps.h"

namespace {
// 优先 PSRAM（2 MB，几乎全空）；失败再回退默认堆，避免整屏直接黑掉。
constexpr uint32_t kLvMemCaps = MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT;
}  // namespace

void lv_mem_init(void) {}
void lv_mem_deinit(void) {}

lv_mem_pool_t lv_mem_add_pool(void* mem, size_t bytes) {
    (void)mem;
    (void)bytes;
    return nullptr;  // 池式接口在自定义分配器下不支持
}

void lv_mem_remove_pool(lv_mem_pool_t pool) { (void)pool; }

void* lv_malloc_core(size_t size) {
    if (size == 0) return nullptr;
    void* p = heap_caps_malloc(size, kLvMemCaps);
    if (p == nullptr) p = heap_caps_malloc(size, MALLOC_CAP_DEFAULT);
    return p;
}

void* lv_realloc_core(void* p, size_t new_size) {
    void* q = heap_caps_realloc(p, new_size, kLvMemCaps);
    if (q == nullptr) q = heap_caps_realloc(p, new_size, MALLOC_CAP_DEFAULT);
    return q;
}

void lv_free_core(void* p) { heap_caps_free(p); }

void lv_mem_monitor_core(lv_mem_monitor_t* mon) {
    if (mon == nullptr) return;
    const size_t total = heap_caps_get_total_size(kLvMemCaps);
    const size_t free_size = heap_caps_get_free_size(kLvMemCaps);
    const size_t biggest = heap_caps_get_largest_free_block(kLvMemCaps);
    *mon = {};
    mon->total_size = total;
    mon->free_size = free_size;
    mon->free_biggest_size = biggest;
    mon->max_used = total > free_size ? total - free_size : 0;
    mon->used_pct = total ? static_cast<uint8_t>(100 - (free_size * 100 / total)) : 0;
    mon->frag_pct = free_size ? static_cast<uint8_t>(100 - (biggest * 100 / free_size)) : 0;
}

lv_result_t lv_mem_test_core(void) { return LV_RESULT_OK; }

#endif  // LV_USE_STDLIB_MALLOC == LV_STDLIB_CUSTOM
