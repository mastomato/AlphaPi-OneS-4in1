#pragma once

// 网络收音机播放器 —— AlphaPi OneS 桌面版
//
// 三段流水线，每段一个任务，段间用定长环连接：
//
//   radio_net  ──compressed 64KB (PSRAM)──>  radio_decode  ──pcm 6s (PSRAM)──>  radio_feed
//   (HTTP 收流)                              (MP3 解码 + 48 抽头重采样)          (写 N32 UART)
//
// 只由 Board 层持有：本类不碰 UI、不碰 LVGL、不发任何回调。UI 通过
// radio::DesktopRadio（desktop_radio.h）读状态。
//
// 与旧版的差异（B4 重构）：
//   - 队列用 StreamQueue（定长环）而不是 FreeRTOS StreamBuffer：PSRAM 块用
//     heap_caps_malloc 显式申请，失败就 Init() 返回 false，绝不 abort()。
//   - 状态机保留 radio_config.h 的 7 值枚举（UI 直接 switch）。
//   - 代数（generation）在所有任务里校验，旧流残留数据不会串到新台。
//   - 播放只在 PCM 真被 N32 接受之后才报 kPlaying。

#include <atomic>
#include <cstddef>
#include <cstdint>
#include <mutex>
#include <string>

#include "audio_resampler.h"
#include "desktop_audio.h"
#include "radio_config.h"
#include "stream_queue.h"

namespace radio {

class RadioPlayer {
public:
    static RadioPlayer& Instance();

    // 只建队列与任务，不联网。PSRAM 或任务创建失败时返回 false（不 abort）。
    bool Init();
    void Shutdown();

    // 换台表：内容被复制进本模块自己的 PSRAM 池，调用方的表可以随即释放。
    // 必须在 Stop() 之后调用。
    void SetList(const Station* list, int count);

    // 列表索引 + 开始拉流（kConnecting）。
    void Play(int index);
    // 从头拉流，不动索引。
    void Start();
    // 代数失效 + 停止喂数据。不 join（任务自己看 generation 退出这一段）。
    void Stop();
    void Pause();
    void Toggle();

    void Next();
    void Previous();
    // 只改索引：正在播就跟着换台，停着就等下一次 Play()。
    void Select(int index);

    PlayerState state() const { return state_.load(); }
    const char* status_text() const;
    int index() const { return index_.load(); }
    int count() const { return count_.load(); }
    const char* name() const { return name_at(index_.load()); }
    const char* url() const { return url_at(index_.load()); }
    const char* name_at(int i) const;
    const char* url_at(int i) const;

    // v54 的 Next/Previous/Select 只在「没暂停」时换台；暂停中换台只动索引，
    // 等 UI 补一个 Play()。paused_ 就是这条语义的载体（不复用 running_：
    // running_ 在 kError 等状态下也应为 false，不能表示"用户想不想听"）。
    bool paused() const { return paused_.load(); }
    bool running() const { return running_.load(); }
    int active_tasks() const { return active_tasks_.load(); }

    // PCM 环里当前可用的**样本**数（不是字节）。
    size_t pcm_available() const;
    size_t pcm_capacity() const { return kPcmCapacity; }

    // UART 侧真实响度（0..100），供 UI 波形用。
    int Level();

    void SetVolume(int volume);
    int volume() const { return volume_.load(); }

    // 迁就旧调用点：缓冲一次性申请、长期复用，本函数恒为空。
    void ReleaseStoppedBuffers() {}

    struct Stats {
        uint32_t rebuffers = 0;      // 进入 kBuffering 的次数
        uint32_t recv_timeouts = 0;  // Feed 拿不到 PCM
        uint32_t write_fails = 0;    // AudioUart::Write 返回 0
        uint32_t net_errors = 0;     // HTTP 失败 / 非 2xx / 无进展
        uint32_t decode_errors = 0;
        uint32_t pcm_now = 0;        // 样本数
        uint32_t pcm_min = 0;        // 样本数，历史最低水位
        uint32_t starve_ms = 0;
    };
    Stats stats() const;

private:
    RadioPlayer() = default;
    ~RadioPlayer() = default;
    RadioPlayer(const RadioPlayer&) = delete;
    RadioPlayer& operator=(const RadioPlayer&) = delete;

    static void NetEntry(void* arg);
    static void DecodeEntry(void* arg);
    static void FeedEntry(void* arg);

    void Run();     // radio_net
    void Decode();  // radio_decode
    void Feed();    // radio_feed

    void PumpStream(uint32_t generation, int index);
    bool Active(uint32_t generation) const;
    bool PushCompressed(const uint8_t* data, size_t count, uint32_t generation);
    bool PushSamples(const int16_t* data, size_t count, uint32_t generation);
    void SetState(PlayerState state, const char* detail, uint32_t generation);
    void ReleaseBuffers();

    // 队列 + 队列锁（Push/Pop/大小都在这把锁下面）
    mutable std::mutex queue_mutex_;
    StreamQueue<uint8_t> compressed_;
    StreamQueue<int16_t> pcm_;
    int16_t* pcm_storage_ = nullptr;
    uint8_t* decode_input_ = nullptr;
    uint8_t* decode_output_ = nullptr;
    size_t decode_output_capacity_ = 0;
    int16_t* decode_mono_ = nullptr;
    size_t mono_capacity_ = 0;
    int16_t* decode_resampled_ = nullptr;
    size_t resampled_capacity_ = 0;

    std::atomic<bool> ready_{false};
    std::atomic<bool> running_{false};
    // 用户意图（暂停/播放），与 running_（当前是否真在拉流）区分开。
    std::atomic<bool> paused_{true};
    std::atomic<int> active_tasks_{0};
    std::atomic<PlayerState> state_{PlayerState::kIdle};
    std::atomic<uint32_t> generation_{0};
    std::atomic<uint32_t> network_finished_{0};
    std::atomic<int> index_{0};
    std::atomic<int> count_{0};
    std::atomic<int> volume_{kDefaultVolume};

    // 电台表：本模块自己的 PSRAM 副本，由 SetList 覆盖写入。
    Station* stations_ = nullptr;
    int station_slots_ = 0;

    // 状态文本：setter 在 state_mutex_ 下写，reader 拷贝成线程内的静态快照，
    // 所以 UI 永远读不到半句。字符串本身固定 24 字节。
    mutable std::mutex state_mutex_;
    char status_text_[24] = "WAITING";

    std::atomic<uint32_t> rebuffers_{0};
    std::atomic<uint32_t> recv_timeouts_{0};
    std::atomic<uint32_t> write_fails_{0};
    std::atomic<uint32_t> net_errors_{0};
    std::atomic<uint32_t> decode_errors_{0};
    // 初值取最大，第一次采样就落到真实值。Feed 用 CAS 只降不升。
    std::atomic<uint32_t> pcm_min_{0xFFFFFFFFu};
    std::atomic<uint32_t> starve_ms_{0};
};

}  // namespace radio