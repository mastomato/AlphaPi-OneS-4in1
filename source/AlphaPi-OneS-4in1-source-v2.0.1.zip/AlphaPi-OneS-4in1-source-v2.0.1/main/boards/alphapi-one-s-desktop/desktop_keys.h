#pragma once

// The four front-panel keys, read straight from GPIO.
//
// The v54 firmware read them through the audio coprocessor's register 0x00,
// which shares the half-duplex UART with PCM: every poll cost roughly 1 ms of
// audio and could not run while a stream was in flight. The hardware has always
// wired these as plain GPIOs, so this reads them directly.
//
// Electrical contract (verified on the real board, do not "fix" it): the four
// pins are inputs with pull-downs and a HIGH level means pressed.

#include <atomic>
#include <cstdint>

namespace radio {

class DesktopKeys {
public:
    static DesktopKeys& Instance();

    // Idempotent. Configures the four pins; safe to call before Wi-Fi is up.
    bool Init();
    bool ready() const { return ready_; }

    // A=0x04 B=0x08 C=0x02 D=0x01, one bit per key, pressed = 1.
    // Returns 0xFF only if Init() never succeeded.
    uint8_t Read();
    uint32_t polls() const { return polls_.load(); }
    uint8_t cached() const { return cached_.load(); }

private:
    DesktopKeys() = default;

    bool ready_ = false;
    std::atomic<uint32_t> polls_{0};
    std::atomic<uint8_t> cached_{0};
};

}  // namespace radio
