#include "esp_timer.h"
#include <atomic>
#include <algorithm>
#include <cmath>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#pragma once
#include "audio_codec.h"
#include "desktop_audio.h"
#include "desktop_state.h"

// AudioCodec adapter for the N32 coprocessor on AlphaPi OneS Desktop.
//
// The link is half duplex: the coprocessor either streams the microphone up or
// plays 8-bit PCM down, never both. Exactly one audio owner exists at any time:
//
//   radio_mode_ == false  -> xiaozhi (TTS / prompts) and the sfx channel own it
//   radio_mode_ == true   -> RadioPlayer owns it
//
// SetRadioMode() is the only place that switches ownership, and GoTo() is the
// only caller. Write() therefore never inspects the UI page: that would be a
// second source of truth, and it used to make /api/status report output_samples
// growing while the speaker was silent.
class DesktopCodec final : public AudioCodec {
public:
 radio::AudioBus audio;
 std::atomic<uint32_t> mic_frames{0},mic_errors{0};
 std::atomic<int64_t> mic_frame_us{0};
 std::atomic<int> mic_peak{0};
 std::atomic<uint32_t> mic_samples{0},output_samples{0};
 std::atomic<int> output_peak{0};
 // Supplied original firmware 0x4202b235 passes 24000 for BOTH codec rates.
 // AudioService resamples the hardware's 24kHz capture to 16kHz for Opus.
 DesktopCodec(){input_sample_rate_=24000;output_sample_rate_=24000;input_channels_=output_channels_=1;duplex_=false;input_gain_=0.0f;audio.Init();}
 // v48: expose the N32 link counters to AudioService so a stalled playback can
 // be split into "decode/network starved" (starve_ms high) versus "the UART
 // write path itself is reopening sessions" (ackfail/gaps/resets > 0).
 IoStats GetIoStats()const override{IoStats s;s.ack_failures=audio.ack_failures();s.stream_gaps=audio.stream_gaps();s.stream_resets=audio.stream_resets();s.stalls=audio.stream_stalls();return s;}
 // Persist once after the user releases the volume keys, not in the audio path.
 void SetOutputVolume(int value)override{output_volume_=std::clamp(value,0,100);audio.SetVolume(output_volume_);}
 // v35: these two used to call audio.Stop() whenever the enable flag flipped.
 // AudioService flips EnableOutput on every turn, so that tore down the freshly
 // warmed playback link and swallowed the start of the TTS. Now playback is only
 // stopped before capture actually begins (the N32 is half duplex), and the
 // output side is left to GoTo()'s page cleanup.
 void EnableInput(bool enabled)override{if(enabled!=input_enabled_){if(enabled&&!radio_mode_)audio.Stop();input_enabled_=enabled;}}
 void EnableOutput(bool enabled)override{output_enabled_=enabled;}
 // Half-duplex ownership switch. true = the radio owns the link.
 void SetRadioMode(bool radio_mode){
  radio_mode_=radio_mode;
  if(radio_mode_){
   audio.Stop();       // stop capture and any playing stream
   audio.InvalidateStream();
  }else{
   audio.InvalidateStream();  // the next write re-sends the 44-byte header
  }
 }
 bool radio_mode()const{return radio_mode_;}
protected:
 bool radio_mode_=false;
 float dc_=0;
 TickType_t capture_cadence_=0;
 bool cadence_active_=false;
 int Write(const int16_t* data,int samples)override{
  // The radio drives the link directly through AudioUart. Silently consume
  // xiaozhi's output here so the audio service's output queue never blocks.
  if(radio_mode_||!output_enabled_)return samples;
  int peak=0;for(int i=0;i<samples;i++)peak=std::max(peak,std::abs(static_cast<int>(data[i])));
  output_peak=peak;output_samples+=samples;
  return audio.Write(data,samples);
 }
 int Read(int16_t* data,int samples)override{
  // Capture is only meaningful while xiaozhi owns the link. The audio input task
  // is not even running otherwise, but a late call must not block.
  if(radio_mode_||!input_enabled_){cadence_active_=false;vTaskDelay(pdMS_TO_TICKS(20));return 0;}
  int64_t capture_start=esp_timer_get_time();
  if(!cadence_active_){capture_cadence_=xTaskGetTickCount();cadence_active_=true;}
  int total=0;
  while(total<samples){
   int n=audio.ReadMic(data+total,samples-total);
   if(n<0){mic_errors++;break;}
   if(n==0){vTaskDelay(std::max<TickType_t>(1,pdMS_TO_TICKS(2)));}
   else total+=n;
   // The FIFO's returned count decides availability; never invent samples and
   // never discard a valid short packet. Budget is 80 ms, not 200 ms: 320
   // samples at 24 kHz only take 13 ms, so a 200 ms ceiling just parks the audio
   // task for the rest of the round when the link misbehaves.
   if(esp_timer_get_time()-capture_start>80000)break;
  }
  if(total<samples){mic_errors++;cadence_active_=false;vTaskDelay(1);return 0;}
  const float gain=std::pow(10.0f,input_gain_/20.0f);
  int peak=0;
  for(int i=0;i<total;i++){
   dc_+=(static_cast<float>(data[i])-dc_)/512.0f;
   float value=(data[i]-dc_)*gain;
   data[i]=static_cast<int16_t>(std::clamp(value,-32000.0f,32000.0f));
   peak=std::max(peak,std::abs(static_cast<int>(data[i])));
  }
  mic_peak=peak;mic_frame_us=esp_timer_get_time()-capture_start;mic_frames++;mic_samples+=total;
  // Input runs at priority 8. Release CPU until the next real capture deadline
  // instead of immediately polling again ahead of the lower priority UI.
  const TickType_t period=std::max<TickType_t>(1,pdMS_TO_TICKS(total*1000/input_sample_rate_));
  if(xTaskGetTickCount()-capture_cadence_>period*4)capture_cadence_=xTaskGetTickCount();
  vTaskDelayUntil(&capture_cadence_,period);
  return total;
 }
};
