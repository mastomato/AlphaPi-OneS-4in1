#pragma once

#include <algorithm>
#include <cstddef>
#include <vector>

namespace radio {

// Fixed-capacity FIFO. The player holds its queue mutex around every access.
// A full queue applies backpressure instead of discarding audio. Reading only
// advances an index; it never moves the remaining samples.
//
// Storage is either owned (Init) or borrowed (Attach). The PCM ring borrows a
// PSRAM block from the player so a failed allocation can be handled by
// degrading to "radio unavailable" instead of throwing out of std::vector.
template <typename T>
class StreamQueue {
public:
    void Init(size_t capacity) {
        owned_.assign(capacity, T{});
        storage_ = owned_.data();
        capacity_ = owned_.size();
        head_ = size_ = 0;
    }

    void Attach(T* storage, size_t capacity) {
        owned_.clear();
        storage_ = storage;
        capacity_ = storage == nullptr ? 0 : capacity;
        head_ = size_ = 0;
    }

    void Clear() { head_ = size_ = 0; }
    size_t size() const { return size_; }
    size_t capacity() const { return capacity_; }
    bool ready() const { return storage_ != nullptr && capacity_ > 0; }

    size_t Push(const T* data, size_t count) {
        if (!ready()) return 0;
        count = std::min(count, capacity_ - size_);
        if (count == 0) {
            return 0;
        }
        const size_t tail = (head_ + size_) % capacity_;
        const size_t first = std::min(count, capacity_ - tail);
        std::copy_n(data, first, storage_ + tail);
        std::copy_n(data + first, count - first, storage_);
        size_ += count;
        return count;
    }

    size_t Pop(T* data, size_t count) {
        if (!ready()) return 0;
        count = std::min(count, size_);
        if (count == 0) {
            return 0;
        }
        const size_t first = std::min(count, capacity_ - head_);
        std::copy_n(storage_ + head_, first, data);
        std::copy_n(storage_, count - first, data + first);
        head_ = (head_ + count) % capacity_;
        size_ -= count;
        return count;
    }

private:
    std::vector<T> owned_;
    T* storage_ = nullptr;
    size_t capacity_ = 0;
    size_t head_ = 0;
    size_t size_ = 0;
};

}  // namespace radio