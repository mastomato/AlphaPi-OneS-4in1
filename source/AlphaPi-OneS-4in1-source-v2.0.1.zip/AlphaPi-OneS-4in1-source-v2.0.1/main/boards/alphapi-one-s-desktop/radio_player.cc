#include "radio_player.h"

#include <algorithm>
#include <array>
#include <cstdlib>
#include <cstring>
#include <new>
#include <strings.h>

#include <esp_crt_bundle.h>
#include <esp_err.h>
#include <esp_heap_caps.h>
#include <esp_http_client.h>
#include <esp_log.h>
#include <esp_timer.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>

#include "audio_uart.h"
#include "desktop_state.h"
#include "decoder/impl/esp_mp3_dec.h"
#include "simple_dec/esp_audio_simple_dec.h"
#include "simple_dec/esp_audio_simple_dec_default.h"

namespace radio {
namespace {

constexpr char kTag[] = "RadioPlayer";

constexpr size_t kNetworkRead = 2048;
constexpr size_t kDecodeInput = 8192;
constexpr size_t kDecodeOutput = 12288;
// 1.5 s to start, 0.5 s if the source is slow. The 6 s ring (kPcmCapacity) then
// absorbs several seconds of source stalls before the UART runs dry.
constexpr size_t kPrimeSamples = kOutputSampleRate * 3 / 2;
constexpr size_t kPrimeFallbackSamples = kOutputSampleRate / 2;
constexpr int64_t kPrimeTimeoutUs = 5 * 1000 * 1000;
constexpr int64_t kFeedWaitUs = 150 * 1000;
constexpr size_t kChunkSamples = 480;

// PSRAM first, then the default heap. Returns nullptr instead of aborting: a
// device without PSRAM must degrade to "radio unavailable", not reboot.
void* PsramOrHeap(size_t bytes) {
    void* p = heap_caps_malloc(bytes, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (p == nullptr) {
        p = heap_caps_malloc(bytes, MALLOC_CAP_DEFAULT);
    }
    return p;
}

struct StreamHeaders {
    int metaint = 0;
    bool wrong_type = false;
};

esp_err_t OnStreamHeader(esp_http_client_event_t* event) {
    if (event->event_id != HTTP_EVENT_ON_HEADER) return ESP_OK;
    auto* headers = static_cast<StreamHeaders*>(event->user_data);
    if (headers == nullptr) return ESP_OK;
    if (strcasecmp(event->header_key, "icy-metaint") == 0) {
        headers->metaint = std::max(0, std::atoi(event->header_value));
    } else if (strcasecmp(event->header_key, "Content-Type") == 0) {
        headers->wrong_type =
            strncasecmp(event->header_value, "text/", 5) == 0 ||
            std::strstr(event->header_value, "mpegurl") != nullptr;
    }
    return ESP_OK;
}

}  // namespace

RadioPlayer& RadioPlayer::Instance() {
    static RadioPlayer instance;
    return instance;
}

// ---------------------------------------------------------------------------
// 生命周期
// ---------------------------------------------------------------------------
bool RadioPlayer::Init() {
    if (ready_.load()) {
        return true;
    }
    // The default registry of the prebuilt simple_dec library has no MP3
    // decoder; without this call open() returns ESP_AUDIO_ERR_NOT_SUPPORT.
    esp_audio_simple_dec_register_default();
    esp_mp3_dec_register();

    const size_t compressed_bytes = kCompressedCapacityBytes;
    const size_t pcm_bytes = kPcmCapacity * sizeof(int16_t);
    uint8_t* compressed = static_cast<uint8_t*>(PsramOrHeap(compressed_bytes));
    int16_t* pcm = static_cast<int16_t*>(PsramOrHeap(pcm_bytes));
    decode_input_ = static_cast<uint8_t*>(PsramOrHeap(kDecodeInput));
    decode_output_ = static_cast<uint8_t*>(PsramOrHeap(kDecodeOutput));
    decode_output_capacity_ = decode_output_ ? kDecodeOutput : 0;
    mono_capacity_ = decode_output_capacity_ / sizeof(int16_t);
    decode_mono_ = static_cast<int16_t*>(PsramOrHeap(mono_capacity_ * sizeof(int16_t)));
    // Worst case for the fixed-capacity resampler output: the slowest MP3 rate
    // (8 kHz) upsamples by 3x into 24 kHz.
    resampled_capacity_ = mono_capacity_ * kOutputSampleRate / 8000 + 4;
    decode_resampled_ =
        static_cast<int16_t*>(PsramOrHeap(resampled_capacity_ * sizeof(int16_t)));

    if (compressed == nullptr || pcm == nullptr || decode_input_ == nullptr ||
        decode_output_ == nullptr || decode_mono_ == nullptr ||
        decode_resampled_ == nullptr) {
        ESP_LOGE(kTag, "audio buffers unavailable");
        heap_caps_free(compressed);
        heap_caps_free(pcm);
        heap_caps_free(decode_input_);
        heap_caps_free(decode_output_);
        heap_caps_free(decode_mono_);
        heap_caps_free(decode_resampled_);
        decode_input_ = decode_output_ = nullptr;
        decode_output_capacity_ = mono_capacity_ = resampled_capacity_ = 0;
        decode_mono_ = decode_resampled_ = nullptr;
        return false;
    }
    compressed_.Attach(compressed, compressed_bytes);
    pcm_storage_ = pcm;
    pcm_.Attach(pcm, kPcmCapacity);

    // The 48-tap coefficient set is read on every decoded frame, so keep it in
    // fast internal RAM when possible (about 6.6 KB).
    const BaseType_t net = xTaskCreate(NetEntry, "radio_net", 6144, this, 5, nullptr);
    const BaseType_t dec = xTaskCreate(DecodeEntry, "radio_decode", 8192, this, 6, nullptr);
    const BaseType_t feed = xTaskCreate(FeedEntry, "radio_feed", 4096, this, 7, nullptr);
    if (net != pdPASS || dec != pdPASS || feed != pdPASS) {
        ESP_LOGE(kTag, "task create failed");
        // 部分创建成功时任务仍在跑，running_ 保持 false，它们只会空转。
        return false;
    }
    ready_.store(true);
    return true;
}

void RadioPlayer::Shutdown() {
    Stop();
    if (!ready_.load()) return;
    ready_.store(false);
    // 任务本身是常驻的，只在重启/销毁路径上走到这里；缓冲不复用即泄漏，
    // 因此本函数只在整机重新初始化时调用。
}

void RadioPlayer::ReleaseBuffers() {
    compressed_.Attach(nullptr, 0);
    pcm_.Attach(nullptr, 0);
    if (pcm_storage_) heap_caps_free(pcm_storage_);
    pcm_storage_ = nullptr;
    if (decode_input_) heap_caps_free(decode_input_);
    if (decode_output_) heap_caps_free(decode_output_);
    if (decode_mono_) heap_caps_free(decode_mono_);
    if (decode_resampled_) heap_caps_free(decode_resampled_);
    decode_input_ = decode_output_ = nullptr;
    decode_mono_ = decode_resampled_ = nullptr;
    decode_output_capacity_ = mono_capacity_ = resampled_capacity_ = 0;
}

// ---------------------------------------------------------------------------
// 电台表
// ---------------------------------------------------------------------------
void RadioPlayer::SetList(const Station* list, int count) {
    if (list == nullptr || count <= 0) return;
    if (stations_ == nullptr) {
        const size_t bytes = sizeof(Station) * kMaxStations;
        stations_ = static_cast<Station*>(PsramOrHeap(bytes));
        if (stations_ == nullptr) {
            ESP_LOGE(kTag, "station pool unavailable");
            return;
        }
        station_slots_ = kMaxStations;
    }
    const int n = std::min(count, station_slots_);
    for (int i = 0; i < n; ++i) {
        stations_[i] = list[i];
        stations_[i].name[sizeof(stations_[i].name) - 1] = '\0';
        stations_[i].url[sizeof(stations_[i].url) - 1] = '\0';
    }
    count_.store(n);
    index_.store(0);
    pcm_min_.store(0xFFFFFFFFu);
}

const char* RadioPlayer::name_at(int i) const {
    if (stations_ == nullptr || i < 0 || i >= count_.load()) return "";
    return stations_[i].name;
}

const char* RadioPlayer::url_at(int i) const {
    if (stations_ == nullptr || i < 0 || i >= count_.load()) return "";
    return stations_[i].url;
}

const char* RadioPlayer::status_text() const {
    // The UI task reads this directly, so hand it a per-thread snapshot that the
    // state setter cannot rewrite while it is being rendered.
    static thread_local char snapshot[sizeof(status_text_)];
    std::lock_guard<std::mutex> lock(state_mutex_);
    std::memcpy(snapshot, status_text_, sizeof(snapshot));
    snapshot[sizeof(snapshot) - 1] = '\0';
    return snapshot;
}

void RadioPlayer::SetState(PlayerState state, const char* detail, uint32_t generation) {
    if (generation_.load() != generation) {
        return;
    }
    std::lock_guard<std::mutex> lock(state_mutex_);
    if (state_.load() == state) {
        if (detail == nullptr) {
            return;
        }
        if (std::strncmp(status_text_, detail, sizeof(status_text_) - 1) == 0) {
            return;
        }
    }
    state_.store(state);
    if (detail != nullptr) {
        std::strncpy(status_text_, detail, sizeof(status_text_) - 1);
        status_text_[sizeof(status_text_) - 1] = '\0';
    }
}

// ---------------------------------------------------------------------------
// 控制
// ---------------------------------------------------------------------------
void RadioPlayer::Start() {
    if (!Init()) {
        SetState(PlayerState::kError, "RADIO UNAVAILABLE", generation_.load());
        return;
    }
    if (count_.load() <= 0) {
        SetState(PlayerState::kError, "NO STATION", generation_.load());
        return;
    }
    uint32_t generation;
    {
        std::lock_guard<std::mutex> lock(queue_mutex_);
        generation = generation_.fetch_add(1) + 1;
        compressed_.Clear();
        pcm_.Clear();
        running_.store(true);
        active_tasks_.store(3);
        network_finished_.store(0);
        pcm_min_.store(0xFFFFFFFFu);
    }
    SetState(PlayerState::kConnecting, "CONNECTING", generation);
}

void RadioPlayer::Play(int index) {
    if (count_.load() <= 0) {
        SetState(PlayerState::kError, "NO STATION", generation_.load());
        return;
    }
    const int next = std::clamp(index, 0, count_.load() - 1);
    index_.store(next);
    paused_.store(false);
    Start();
}

void RadioPlayer::Stop() {
    uint32_t generation;
    {
        std::lock_guard<std::mutex> lock(queue_mutex_);
        generation = generation_.fetch_add(1) + 1;
        running_.store(false);
        paused_.store(true);
        active_tasks_.store(0);
        compressed_.Clear();
        pcm_.Clear();
    }
    // Feed sees the new generation and leaves its UART session on its own; the
    // caller's page switch must not block on an ACK.
    SetState(PlayerState::kIdle, "STOPPED", generation);
}

void RadioPlayer::Pause() {
    uint32_t generation;
    {
        std::lock_guard<std::mutex> lock(queue_mutex_);
        generation = generation_.fetch_add(1) + 1;
        running_.store(false);
        paused_.store(true);
        active_tasks_.store(0);
        compressed_.Clear();
        pcm_.Clear();
    }
    SetState(PlayerState::kPaused, "PAUSED", generation);
}

void RadioPlayer::Toggle() {
    if (paused_.load()) {
        Start();
    } else {
        Pause();
    }
}

void RadioPlayer::Next() {
    if (count_.load() <= 0) return;
    index_.store((index_.load() + 1) % count_.load());
    // v54: 只有"用户想听"时才随换台重开流；暂停中只动索引。
    if (!paused_.load() && running_.load()) Start();
}

void RadioPlayer::Previous() {
    if (count_.load() <= 0) return;
    index_.store((index_.load() + count_.load() - 1) % count_.load());
    // v54: 只有"用户想听"时才随换台重开流；暂停中只动索引。
    if (!paused_.load() && running_.load()) Start();
}

void RadioPlayer::Select(int index) {
    const int total = count_.load();
    if (total <= 0) return;
    const int next = std::clamp(index, 0, total - 1);
    index_.store(next);
    if (!paused_.load() && running_.load()) {
        Start();
    }
}

void RadioPlayer::SetVolume(int volume) {
    const int v = std::clamp(volume, kVolumeMin, kVolumeMax);
    volume_.store(v);
    AudioUart::Instance().SetVolume(v);
}

int RadioPlayer::Level() { return AudioUart::Instance().Level(); }

size_t RadioPlayer::pcm_available() const {
    std::lock_guard<std::mutex> lock(queue_mutex_);
    return pcm_.size();
}

RadioPlayer::Stats RadioPlayer::stats() const {
    Stats s;
    s.rebuffers = rebuffers_.load();
    s.recv_timeouts = recv_timeouts_.load();
    s.write_fails = write_fails_.load();
    s.net_errors = net_errors_.load();
    s.decode_errors = decode_errors_.load();
    s.pcm_now = static_cast<uint32_t>(pcm_available());
    // 0xFFFFFFFF means "never sampled yet"; reporting the current level is more
    // honest than claiming the ring bottomed out.
    const uint32_t low = pcm_min_.load();
    s.pcm_min = (low == 0xFFFFFFFFu) ? s.pcm_now : low;
    s.starve_ms = starve_ms_.load();
    return s;
}

bool RadioPlayer::Active(uint32_t generation) const {
    return running_.load() && generation_.load() == generation;
}

bool RadioPlayer::PushCompressed(const uint8_t* data, size_t count, uint32_t generation) {
    size_t sent = 0;
    while (sent < count) {
        size_t n;
        {
            std::lock_guard<std::mutex> lock(queue_mutex_);
            if (!Active(generation)) {
                return false;
            }
            n = compressed_.Push(data + sent, count - sent);
        }
        sent += n;
        if (n == 0) {
            vTaskDelay(pdMS_TO_TICKS(5));
        }
    }
    return true;
}

bool RadioPlayer::PushSamples(const int16_t* data, size_t count, uint32_t generation) {
    size_t sent = 0;
    while (sent < count) {
        size_t n;
        {
            std::lock_guard<std::mutex> lock(queue_mutex_);
            if (!Active(generation)) {
                return false;
            }
            n = pcm_.Push(data + sent, count - sent);
        }
        sent += n;
        if (n == 0) {
            vTaskDelay(pdMS_TO_TICKS(5));
        }
    }
    return true;
}

// ---------------------------------------------------------------------------
// 任务入口
// ---------------------------------------------------------------------------
void RadioPlayer::NetEntry(void* arg) { static_cast<RadioPlayer*>(arg)->Run(); }
void RadioPlayer::DecodeEntry(void* arg) { static_cast<RadioPlayer*>(arg)->Decode(); }
void RadioPlayer::FeedEntry(void* arg) { static_cast<RadioPlayer*>(arg)->Feed(); }

// ---------------------------------------------------------------------------
// radio_net：HTTP 拉流 -> compressed_
// ---------------------------------------------------------------------------
void RadioPlayer::Run() {
    for (;;) {
        if (!running_.load()) {
            vTaskDelay(pdMS_TO_TICKS(50));
            continue;
        }
        const uint32_t generation = generation_.load();
        if (!desktop_network.load()) {
            SetState(PlayerState::kConnecting, "WAITING NETWORK", generation);
            vTaskDelay(pdMS_TO_TICKS(300));
            continue;
        }
        PumpStream(generation, index_.load());
        if (Active(generation)) {
            // Keep draining the buffers that are already filled while the HTTP
            // side reconnects; the UART session stays warm until PCM runs out.
            SetState(PlayerState::kReconnecting, "RECONNECTING", generation);
            vTaskDelay(pdMS_TO_TICKS(1000));
        }
    }
}

void RadioPlayer::PumpStream(uint32_t generation, int index) {
    char name[kStationNameBytes];
    char url[kStationUrlBytes];
    {
        const char* src_name = name_at(index);
        const char* src_url = url_at(index);
        std::snprintf(name, sizeof(name), "%s", src_name == nullptr ? "" : src_name);
        std::snprintf(url, sizeof(url), "%s", src_url == nullptr ? "" : src_url);
    }
    if (url[0] == '\0') {
        net_errors_.fetch_add(1);
        SetState(PlayerState::kError, "BAD URL", generation);
        return;
    }
    if (state_.load() != PlayerState::kPlaying) {
        SetState(PlayerState::kConnecting, "CONNECTING", generation);
    }
    network_finished_.store(0);

    esp_http_client_config_t cfg = {};
    StreamHeaders headers;
    cfg.url = url;
    cfg.crt_bundle_attach = esp_crt_bundle_attach;
    cfg.event_handler = OnStreamHeader;
    cfg.user_data = &headers;
    cfg.timeout_ms = 7000;
    cfg.buffer_size = 4096;
    cfg.buffer_size_tx = 1024;
    cfg.keep_alive_enable = true;
    cfg.user_agent = "AlphaPi-OneS-Radio/1.0";
    esp_http_client_handle_t client = esp_http_client_init(&cfg);
    if (client == nullptr) {
        net_errors_.fetch_add(1);
        SetState(PlayerState::kError, "HTTP INIT FAILED", generation);
        network_finished_.store(generation);
        return;
    }
    esp_http_client_set_header(client, "Icy-MetaData", "0");

    bool opened = false;
    bool valid = false;
    int http_status = 0;
    for (int redirect = 0; redirect <= 4 && Active(generation); ++redirect) {
        headers = {};
        opened = esp_http_client_open(client, 0) == ESP_OK;
        if (!opened) break;
        // A live stream need not carry Content-Length; only the status decides
        // whether the connection is usable.
        esp_http_client_fetch_headers(client);
        const int status = esp_http_client_get_status_code(client);
        http_status = status;
        valid = status >= 200 && status < 300 && !headers.wrong_type;
        if (valid || status < 300 || status >= 400) break;
        if (esp_http_client_set_redirection(client) != ESP_OK) break;
        esp_http_client_close(client);
        opened = false;
    }
    if (!valid) {
        if (opened) {
            esp_http_client_close(client);
        }
        esp_http_client_cleanup(client);
        net_errors_.fetch_add(1);
        network_finished_.store(generation);
        if (state_.load() != PlayerState::kPlaying) {
            if (http_status >= 400) {
                char detail[24];
                std::snprintf(detail, sizeof(detail), "HTTP %d", http_status);
                SetState(PlayerState::kError, detail, generation);
            } else {
                SetState(PlayerState::kError, opened ? "NO RESPONSE" : "CONNECT FAILED",
                         generation);
            }
        }
        return;
    }

    const int metaint = headers.metaint;
    // Headers keep the 7 s deadline; body reads use a short one so a station
    // change never waits on the previous stream. EAGAIN is temporary starvation,
    // not a reason to tear the socket down.
    esp_http_client_set_timeout_ms(client, 500);
    int64_t last_progress_us = esp_timer_get_time();
    auto read_stream = [&](uint8_t* target, int want) {
        while (Active(generation) && desktop_network.load()) {
            const int n = esp_http_client_read(client, reinterpret_cast<char*>(target), want);
            if (n > 0) {
                last_progress_us = esp_timer_get_time();
                return n;
            }
            if (n != -ESP_ERR_HTTP_EAGAIN &&
                (n < 0 || esp_http_client_is_complete_data_received(client))) {
                return n;
            }
            if (esp_timer_get_time() - last_progress_us >= 7 * 1000000LL) return -1;
            vTaskDelay(1);
        }
        return -1;
    };

    size_t countdown = metaint > 0 ? static_cast<size_t>(metaint) : 0;
    std::array<uint8_t, kNetworkRead> bytes = {};
    while (Active(generation) && desktop_network.load()) {
        const int want = static_cast<int>(metaint > 0 ? std::min(bytes.size(), countdown)
                                                     : bytes.size());
        const int got = read_stream(bytes.data(), want);
        if (!Active(generation)) break;
        if (got <= 0) break;
        if (!PushCompressed(bytes.data(), static_cast<size_t>(got), generation)) break;
        if (metaint > 0) {
            countdown -= static_cast<size_t>(got);
            if (countdown == 0) {
                uint8_t length = 0;
                if (read_stream(&length, 1) != 1) break;
                size_t left = static_cast<size_t>(length) * 16;
                while (left > 0 && Active(generation)) {
                    const int n =
                        read_stream(bytes.data(), static_cast<int>(std::min(left, bytes.size())));
                    if (n <= 0) break;
                    left -= static_cast<size_t>(n);
                }
                if (left > 0) break;
                countdown = static_cast<size_t>(metaint);
            }
        }
    }
    esp_http_client_close(client);
    esp_http_client_cleanup(client);
    network_finished_.store(generation);
}

// ---------------------------------------------------------------------------
// radio_decode：MP3 -> mono -> resample 24 kHz -> pcm_
// ---------------------------------------------------------------------------
void RadioPlayer::Decode() {
    // The FIR working set lives in internal RAM (about 6.6 KB) because it is
    // touched for every decoded frame; the large scratch buffers stay in PSRAM.
    void* memory = heap_caps_malloc(sizeof(AudioResampler), MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    if (memory == nullptr) memory = heap_caps_malloc(sizeof(AudioResampler), MALLOC_CAP_8BIT);
    if (memory == nullptr) {
        ESP_LOGE(kTag, "resampler allocation failed");
        // Without a resampler only streams already at 24 kHz would play, so park
        // this task instead of aborting the boot chain.
        for (;;) {
            vTaskDelay(pdMS_TO_TICKS(1000));
        }
    }
    auto* resampler = new (memory) AudioResampler();
    auto destroy = [](AudioResampler* p) {
        p->~AudioResampler();
        heap_caps_free(p);
    };
    struct Guard {
        AudioResampler* p;
        void (*fn)(AudioResampler*);
        ~Guard() { fn(p); }
    } guard{resampler, destroy};

    esp_audio_simple_dec_handle_t decoder = nullptr;
    uint32_t active_generation = 0;
    uint32_t previous_rate = 0;
    size_t buffered = 0;

    for (;;) {
        const uint32_t generation = generation_.load();
        if (generation != active_generation) {
            active_generation = generation;
            buffered = 0;
            previous_rate = 0;
            if (decoder != nullptr) {
                esp_audio_simple_dec_close(decoder);
                decoder = nullptr;
            }
        }
        if (!Active(generation) || decode_input_ == nullptr) {
            vTaskDelay(pdMS_TO_TICKS(20));
            continue;
        }
        if (decode_output_capacity_ < kDecodeOutput && decode_output_ != nullptr) {
            uint8_t* grown = static_cast<uint8_t*>(PsramOrHeap(kDecodeOutput));
            if (grown != nullptr) {
                heap_caps_free(decode_output_);
                decode_output_ = grown;
                decode_output_capacity_ = kDecodeOutput;
                mono_capacity_ = decode_output_capacity_ / sizeof(int16_t);
            }
        }
        if (decoder == nullptr) {
            esp_audio_simple_dec_cfg_t cfg = {};
            cfg.dec_type = ESP_AUDIO_SIMPLE_DEC_TYPE_MP3;
            cfg.use_frame_dec = false;
            if (esp_audio_simple_dec_open(&cfg, &decoder) != ESP_AUDIO_ERR_OK) {
                decode_errors_.fetch_add(1);
                SetState(PlayerState::kError, "DECODER ERROR", generation);
                vTaskDelay(pdMS_TO_TICKS(1000));
                continue;
            }
        }
        size_t added = 0;
        {
            std::lock_guard<std::mutex> lock(queue_mutex_);
            if (Active(generation)) {
                added = compressed_.Pop(decode_input_ + buffered, kDecodeInput - buffered);
            }
        }
        buffered += added;
        if (!Active(generation)) {
            continue;
        }
        if (buffered == 0) {
            vTaskDelay(pdMS_TO_TICKS(5));
            continue;
        }

        esp_audio_simple_dec_raw_t in = {};
        in.buffer = decode_input_;
        in.len = static_cast<uint32_t>(buffered);
        esp_audio_simple_dec_out_t out = {};
        out.buffer = decode_output_;
        out.len = static_cast<uint32_t>(decode_output_capacity_);
        const esp_audio_err_t result = esp_audio_simple_dec_process(decoder, &in, &out);
        if (result == ESP_AUDIO_ERR_BUFF_NOT_ENOUGH && out.needed_size > decode_output_capacity_) {
            // Grow the PCM scratch up to a hard ceiling instead of looping
            // forever on the same frame.
            const size_t want = std::min<size_t>(out.needed_size, 64 * 1024);
            if (want > decode_output_capacity_) {
                uint8_t* grown = static_cast<uint8_t*>(PsramOrHeap(want));
                if (grown != nullptr) {
                    heap_caps_free(decode_output_);
                    decode_output_ = grown;
                    decode_output_capacity_ = want;
                    mono_capacity_ = want / sizeof(int16_t);
                } else {
                    buffered = 0;
                }
            }
            continue;
        }
        if (result != ESP_AUDIO_ERR_OK && result != ESP_AUDIO_ERR_DATA_LACK) {
            decode_errors_.fetch_add(1);
        }
        if (in.consumed > 0 && in.consumed <= buffered) {
            buffered -= in.consumed;
            std::memmove(decode_input_, decode_input_ + in.consumed, buffered);
        }
        if (out.decoded_size == 0) {
            if (in.consumed == 0) {
                if (buffered == kDecodeInput) {
                    buffered = 0;
                }
                // Give the lower-priority HTTP task the core while waiting.
                vTaskDelay(pdMS_TO_TICKS(5));
            }
            continue;
        }
        esp_audio_simple_dec_info_t info = {};
        if (esp_audio_simple_dec_get_info(decoder, &info) != ESP_AUDIO_ERR_OK ||
            info.bits_per_sample != 16 || info.channel == 0 || info.channel > 2 ||
            info.sample_rate == 0) {
            decode_errors_.fetch_add(1);
            continue;
        }
        const auto* samples = reinterpret_cast<const int16_t*>(decode_output_);
        const size_t frames = out.decoded_size / sizeof(int16_t) / info.channel;
        if (frames == 0) {
            continue;
        }
        if (frames > mono_capacity_) {
            // Should be impossible: decoded_size <= decode_output_capacity_.
            continue;
        }
        if (info.channel == 1) {
            std::memcpy(decode_mono_, samples, frames * sizeof(int16_t));
        } else {
            for (size_t i = 0; i < frames; ++i) {
                decode_mono_[i] = static_cast<int16_t>(
                    (static_cast<int32_t>(samples[i * 2]) + samples[i * 2 + 1]) / 2);
            }
        }
        if (previous_rate != info.sample_rate) {
            previous_rate = info.sample_rate;
            resampler->Reset(info.sample_rate, kOutputSampleRate, [] { vTaskDelay(1); });
        }
        const int16_t* feed = decode_mono_;
        size_t feed_frames = frames;
        if (info.sample_rate != kOutputSampleRate) {
            const size_t capacity =
                std::min(resampled_capacity_, resampler->OutputCapacity(frames));
            if (capacity == 0) {
                continue;
            }
            feed_frames = resampler->Process(decode_mono_, frames, decode_resampled_, capacity);
            feed = decode_resampled_;
        }
        if (feed_frames > 0) {
            PushSamples(feed, feed_frames, generation);
        }
        // The decoder sits above the UI in priority; don't monopolise the single
        // core while filling the PCM reserve from already-cached data.
        vTaskDelay(1);
    }
}

// ---------------------------------------------------------------------------
// radio_feed：pcm_ -> N32
// ---------------------------------------------------------------------------
void RadioPlayer::Feed() {
    std::array<int16_t, kChunkSamples> block = {};
    auto& audio = AudioUart::Instance();
    uint32_t active_generation = 0;
    bool primed = false;
    int64_t prime_started_us = esp_timer_get_time();
    int64_t empty_since_us = 0;

    for (;;) {
        const uint32_t generation = generation_.load();
        if (generation != active_generation) {
            active_generation = generation;
            // A station change (or a stop) ends the coprocessor's playback
            // session here, never from the caller's task: Stop() must not block
            // on an ACK.
            audio.StopRecord();
            audio.InvalidateStream();
            primed = false;
            prime_started_us = esp_timer_get_time();
            empty_since_us = 0;
        }
        // Volume is applied between PCM blocks, including while paused or
        // buffering; a failed ACK leaves the latest request pending.
        if (!audio.ApplyPendingVolume()) {
            vTaskDelay(pdMS_TO_TICKS(20));
            continue;
        }
        if (!Active(generation)) {
            vTaskDelay(pdMS_TO_TICKS(20));
            continue;
        }

        size_t available;
        {
            std::lock_guard<std::mutex> lock(queue_mutex_);
            available = pcm_.size();
        }
        const int64_t now = esp_timer_get_time();
        if (!primed) {
            if (available == 0) {
                prime_started_us = now;
            }
            const size_t target =
                now - prime_started_us >= kPrimeTimeoutUs ? kPrimeFallbackSamples : kPrimeSamples;
            if (available < target) {
                const bool first_enter = state_.load() != PlayerState::kBuffering;
                if (first_enter) {
                    rebuffers_.fetch_add(1);
                }
                if (state_.load() != PlayerState::kError || available > 0) {
                    SetState(PlayerState::kBuffering,
                             network_finished_.load() == generation ? "RECONNECTING" : "BUFFERING",
                             generation);
                }
                starve_ms_.fetch_add(20);
                vTaskDelay(pdMS_TO_TICKS(20));
                continue;
            }
            audio.InvalidateStream();
            primed = true;
            empty_since_us = 0;
        }

        // The lowest PCM level ever seen is the most direct evidence of an
        // underfed pipeline; keep it with a CAS so it only ever goes down.
        {
            uint32_t seen = pcm_min_.load();
            const uint32_t now_samples = static_cast<uint32_t>(available);
            while (now_samples < seen && !pcm_min_.compare_exchange_weak(seen, now_samples)) {
            }
        }

        size_t count;
        {
            std::lock_guard<std::mutex> lock(queue_mutex_);
            count = Active(generation) ? pcm_.Pop(block.data(), block.size()) : 0;
        }
        if (!Active(generation)) {
            continue;
        }
        if (count == 0) {
            if (empty_since_us == 0) {
                empty_since_us = now;
            } else if (now - empty_since_us >= kFeedWaitUs) {
                recv_timeouts_.fetch_add(1);
                primed = false;
                prime_started_us = now;
                audio.StopRecord();
                audio.InvalidateStream();
            }
            vTaskDelay(pdMS_TO_TICKS(5));
            continue;
        }
        empty_since_us = 0;

        size_t sent = 0;
        bool failed = false;
        while (sent < count && Active(generation)) {
            const int written =
                audio.Write(block.data() + sent, static_cast<int>(count - sent));
            if (written <= 0) {
                failed = true;
                break;
            }
            sent += static_cast<size_t>(written);
        }
        if (!Active(generation)) {
            continue;
        }
        if (failed) {
            write_fails_.fetch_add(1);
            audio.StopRecord();
            audio.InvalidateStream();
            primed = false;
            prime_started_us = esp_timer_get_time();
            SetState(PlayerState::kReconnecting, "AUDIO RETRY", generation);
            vTaskDelay(pdMS_TO_TICKS(100));
            continue;
        }
        // Announce playback only once the coprocessor accepted PCM, never after
        // an HTTP read.
        SetState(PlayerState::kPlaying, nullptr, generation);
    }
}

}  // namespace radio