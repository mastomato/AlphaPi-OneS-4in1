#include "audio_uart.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstring>

#include "esp_log.h"
#include "esp_timer.h"
#include "freertos/task.h"

namespace radio {
namespace {

constexpr char kTag[] = "AudioUart";

constexpr uint8_t kControlPrefix = 0x90;
constexpr uint8_t kControlAckPrefix = 0x91;
constexpr uint8_t kRecordControlCommand = 0x10;
constexpr uint8_t kRecordReadCommand = 0x11;
constexpr uint8_t kVolumeCommand = 0x14;
constexpr uint8_t kPcmWriteCommand = 0x15;
constexpr uint8_t kReadPrefix = 0x80;
constexpr uint8_t kReadAckPrefix = 0x81;

uint8_t Checksum(const uint8_t* data, size_t length) {
    uint8_t sum = 0;
    for (size_t i = 0; i < length; ++i) {
        sum = static_cast<uint8_t>(sum + data[i]);
    }
    return sum;
}

}  // namespace

AudioUart& AudioUart::Instance() {
    static AudioUart instance;
    return instance;
}

bool AudioUart::Init() {
    if (ready_.load()) {
        return true;
    }
    if (mutex_ == nullptr) {
        mutex_ = xSemaphoreCreateMutex();
        if (mutex_ == nullptr) {
            ESP_LOGE(kTag, "mutex alloc failed");
            return false;
        }
    }

    // Boot order matters: the driver must exist before any byte is written, and
    // the coprocessor needs its power-on delay before the first frame, otherwise
    // that frame is lost and leaves stale bytes in the receive path.
    uart_config_t config = {};
    config.baud_rate = board::kAudioUartBaud;
    config.data_bits = UART_DATA_8_BITS;
    config.parity = UART_PARITY_DISABLE;
    config.stop_bits = UART_STOP_BITS_1;
    config.flow_ctrl = UART_HW_FLOWCTRL_DISABLE;
    config.rx_flow_ctrl_thresh = 0;
    config.source_clk = UART_SCLK_APB;

    esp_err_t err = uart_param_config(port_, &config);
    if (err != ESP_OK) {
        ESP_LOGE(kTag, "param config failed: %s", esp_err_to_name(err));
        return false;
    }
    err = uart_set_pin(port_, board::kAudioUartTx, board::kAudioUartRx,
                       UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE);
    if (err != ESP_OK) {
        ESP_LOGE(kTag, "pin setup failed: %s", esp_err_to_name(err));
        return false;
    }
    err = uart_driver_install(port_, 8192, 8192, 0, nullptr, 0);
    if (err != ESP_OK) {
        ESP_LOGE(kTag, "driver install failed: %s", esp_err_to_name(err));
        return false;
    }
    uart_flush_input(port_);
    ready_.store(true);
    vTaskDelay(pdMS_TO_TICKS(kBootWaitMs));

    // One hardware write at the loudest step. Register 0x14 is not reliable
    // while a stream runs, and the PCM gain in Write() is what actually tracks
    // the user's percentage; keeping the step at its maximum stops the two
    // attenuators from stacking (4/6 hardware x 67% software would be ~45%).
    volume_.Set(kHardwarePercent);
    bool ok = ApplyVolumeLocked(true);
    if (!ok) {
        vTaskDelay(pdMS_TO_TICKS(300));
        uart_flush_input(port_);
        ok = ApplyVolumeLocked(true);
    }
    if (!ok) {
        ESP_LOGW(kTag, "volume command got no answer");
    }
    StopRecord();
    ESP_LOGI(kTag, "uart%d ready at %d baud (tx=%d rx=%d)",
             static_cast<int>(port_), board::kAudioUartBaud,
             static_cast<int>(board::kAudioUartTx),
             static_cast<int>(board::kAudioUartRx));
    return ok;
}

void AudioUart::StopRecord() {
    if (!ready_.load() || mutex_ == nullptr) {
        return;
    }
    if (xSemaphoreTake(mutex_, pdMS_TO_TICKS(500)) != pdTRUE) {
        return;
    }
    if (StopRecordLocked()) {
        stream_configured_.store(false);
    }
    xSemaphoreGive(mutex_);
}

bool AudioUart::StopRecordLocked() {
    const uint8_t stop = 0;
    if (!SendLocked(kRecordControlCommand, &stop, 1, nullptr)) {
        return false;
    }
    recording_ = false;
    return true;
}

void AudioUart::SetVolume(int percent) {
    requested_percent_.store(std::clamp(percent, 0, 100));
}

bool AudioUart::ApplyPendingVolume() {
    if (!ready_.load() || mutex_ == nullptr) return false;
    if (xSemaphoreTake(mutex_, 0) != pdTRUE) return false;
    const bool ok = ApplyVolumeLocked();
    xSemaphoreGive(mutex_);
    return ok;
}

void AudioUart::InvalidateStream() {
    if (!ready_.load() || mutex_ == nullptr) return;
    if (xSemaphoreTake(mutex_, pdMS_TO_TICKS(500)) != pdTRUE) return;
    stream_configured_.store(false);
    // Drop stale answer bytes: after a stall or a station change the receive
    // buffer can still hold acks of frames nobody waits for, and every later
    // command would read the wrong ack and look rejected.
    uart_flush_input(port_);
    last_write_us_ = 0;
    xSemaphoreGive(mutex_);
}

bool AudioUart::stream_configured() const {
    return stream_configured_.load();
}

int AudioUart::Level() {
    // Called from the UI task at ~25 Hz: fold in the peak since the last call,
    // then decay so the meter falls back on silence.
    const int peak = peak_.exchange(0);
    const int decayed = level_ - (level_ + 3) / 4;
    level_ = peak > decayed ? peak : decayed;
    return level_;
}
int AudioUart::Write(const int16_t* samples, int count) {
    if (!ready_.load() || samples == nullptr || count <= 0 || mutex_ == nullptr) {
        return 0;
    }
    if (xSemaphoreTake(mutex_, pdMS_TO_TICKS(500)) != pdTRUE) {
        return 0;
    }

    // A long gap ends the coprocessor's playback session: the cached header is
    // stale and the receive path may hold an ack nobody will read. Both are
    // cheap to reset. Never reopen the session here -- v51 showed that doing a
    // cold handshake inside Write() audibly swallows the first 100-150 ms of
    // every buffer refill.
    const int64_t now_us = esp_timer_get_time();
    if (last_write_us_ != 0 && (now_us - last_write_us_) > kStreamGapUs) {
        stream_gaps_.fetch_add(1);
        stream_configured_.store(false);
        uart_flush_input(port_);
    }
    if (recording_) {
        recording_ = false;
    }
    if (!stream_configured_.load() && !SendWavHeaderLocked()) {
        stream_resets_.fetch_add(1);
        xSemaphoreGive(mutex_);
        return 0;
    }

    const int vol = requested_percent_.load();
    const size_t total = static_cast<size_t>(count);
    size_t written = 0;
    std::array<uint8_t, kMaxPayload> chunk = {};
    // Measure every other block. The RMS uses the SCALED samples, so the meter
    // follows the speaker exactly instead of animating independently.
    const bool measure = (++level_tick_ >= 2);
    if (measure) level_tick_ = 0;
    uint64_t sum_sq = 0;
    uint64_t measured = 0;
    while (written < total) {
        const size_t n = std::min(total - written, kMaxPayload);
        // Software gain: the coprocessor's 0x14 register may not respond while
        // a stream is running, so scaling the samples is what guarantees the
        // user's percentage is audible. 100 is a bypass.
        for (size_t i = 0; i < n; ++i) {
            int32_t s = samples[written + i];
            if (vol != 100) {
                s = (s * vol) / 100;
            }
            if (measure) {
                sum_sq += static_cast<uint64_t>(static_cast<int64_t>(s) * s);
                ++measured;
            }
            // 16-bit signed -> 8-bit unsigned, rounding rather than truncating
            // (truncation adds a permanent half-LSB DC offset), then clamped:
            // s=32767 would otherwise wrap to 0 and turn a peak into silence.
            const int rounded = (s + 32768 + 128) >> 8;
            chunk[i] = static_cast<uint8_t>(
                rounded < 0 ? 0 : (rounded > 255 ? 255 : rounded));
        }

        size_t sent = 0;
        // accepted == 0 is the coprocessor's receive buffer being full: normal
        // backpressure, not a fault. Its DAC clock and esp_timer drift by ppm,
        // so a long stream always ends up here eventually.
        const int64_t stall_deadline = esp_timer_get_time() + kStallBudgetUs;
        while (sent < n) {
            uint8_t accepted = 0;
            if (!SendLocked(kPcmWriteCommand, chunk.data() + sent, n - sent,
                            &accepted)) {
                stream_configured_.store(false);
                stream_resets_.fetch_add(1);
                xSemaphoreGive(mutex_);
                return static_cast<int>(written + sent);
            }
            if (accepted == 0) {
                if (esp_timer_get_time() > stall_deadline) {
                    stream_configured_.store(false);
                    stream_resets_.fetch_add(1);
                    xSemaphoreGive(mutex_);
                    return static_cast<int>(written + sent);
                }
                stalls_.fetch_add(1);
                // 5 ms matches the known-good driver: 2 ms would hammer the
                // coprocessor with 500 useless frames per second and slow the
                // drain it is waiting for.
                vTaskDelay(pdMS_TO_TICKS(5));
                continue;
            }
            sent += std::min<size_t>(accepted, n - sent);
        }
        written += n;
        last_write_us_ = esp_timer_get_time();
        // The whole block stays under the lock. Splitting it let audio_input(8)
        // and game_beep(6) grab the half-duplex link mid-frame, which tore down
        // the playback session this block was feeding.
        taskYIELD();
    }
    if (measure && measured > 0) {
        const double rms =
            std::sqrt(static_cast<double>(sum_sq) / measured) / 32768.0;
        int percent = static_cast<int>(rms * 330.0);
        if (percent > 100) percent = 100;
        int seen = peak_.load();
        while (percent > seen && !peak_.compare_exchange_weak(seen, percent)) {
        }
    }
    xSemaphoreGive(mutex_);
    return count;
}

int AudioUart::WriteU8(const uint8_t* samples, int count) {
    if (!ready_.load() || samples == nullptr || count <= 0 || mutex_ == nullptr) {
        return 0;
    }
    if (xSemaphoreTake(mutex_, pdMS_TO_TICKS(500)) != pdTRUE) {
        return 0;
    }
    const int64_t now_us = esp_timer_get_time();
    if (last_write_us_ != 0 && (now_us - last_write_us_) > kStreamGapUs) {
        stream_gaps_.fetch_add(1);
        stream_configured_.store(false);
        uart_flush_input(port_);
    }
    if (!stream_configured_.load() && !SendWavHeaderLocked()) {
        stream_resets_.fetch_add(1);
        xSemaphoreGive(mutex_);
        return 0;
    }

    int offset = 0;
    while (offset < count) {
        const int chunk = std::min(count - offset, static_cast<int>(kMaxPayload));
        size_t sent = 0;
        const int64_t stall_deadline = esp_timer_get_time() + kStallBudgetUs;
        while (sent < static_cast<size_t>(chunk)) {
            uint8_t accepted = 0;
            if (!SendLocked(kPcmWriteCommand, samples + offset + sent,
                            static_cast<size_t>(chunk) - sent, &accepted)) {
                stream_configured_.store(false);
                stream_resets_.fetch_add(1);
                xSemaphoreGive(mutex_);
                return offset;
            }
            if (accepted == 0) {
                if (esp_timer_get_time() > stall_deadline) {
                    stream_configured_.store(false);
                    stream_resets_.fetch_add(1);
                    xSemaphoreGive(mutex_);
                    return offset;
                }
                stalls_.fetch_add(1);
                vTaskDelay(pdMS_TO_TICKS(5));
                continue;
            }
            sent += std::min<size_t>(accepted, static_cast<size_t>(chunk) - sent);
            last_write_us_ = esp_timer_get_time();
        }
        offset += chunk;
    }
    xSemaphoreGive(mutex_);
    return count;
}
int AudioUart::Read(int16_t* samples, int count) {
    if (!ready_.load() || samples == nullptr || count <= 0 || mutex_ == nullptr) {
        return 0;
    }
    if (xSemaphoreTake(mutex_, pdMS_TO_TICKS(500)) != pdTRUE) {
        return 0;
    }

    // Half duplex: capture and playback cannot coexist. Dropping the cached
    // header makes the next Write() reopen the playback session.
    if (stream_configured_.load()) {
        stream_configured_.store(false);
        last_write_us_ = 0;
        uart_flush_input(port_);
    }
    if (!recording_) {
        const uint8_t start = 1;
        uint8_t accepted = 0;
        if (!SendLocked(kRecordControlCommand, &start, 1, &accepted) ||
            accepted == 0) {
            xSemaphoreGive(mutex_);
            return 0;
        }
        recording_ = true;
        vTaskDelay(1);
    }

    // A half-read frame leaves every later transaction misaligned (the checksum
    // keeps failing), so any error drops the whole capture stream and lets the
    // caller reopen it.
    auto fail = [&]() -> int {
        uart_flush_input(port_);
        recording_ = false;
        last_write_us_ = 0;
        xSemaphoreGive(mutex_);
        return -1;
    };

    int produced = 0;
    while (produced < count) {
        const int want = std::min<int>(count - produced,
                                       static_cast<int>(kMaxPayload));
        const std::array<uint8_t, 3> request = {
            kReadPrefix, kRecordReadCommand, static_cast<uint8_t>(want)};
        uart_flush_input(port_);
        if (uart_write_bytes(port_, request.data(), request.size()) !=
            static_cast<int>(request.size())) {
            return fail();
        }
        std::array<uint8_t, 3> head = {};
        if (!ReadExactLocked(head.data(), head.size(), 80)) return fail();
        if (head[0] != kReadAckPrefix || head[1] != kRecordReadCommand) {
            return fail();
        }
        const int actual = head[2];
        if (actual <= 0 || actual > want) return fail();

        std::array<uint8_t, kMaxPayload + 1> payload = {};
        if (!ReadExactLocked(payload.data(), static_cast<size_t>(actual) + 1,
                             120)) {
            return fail();
        }
        uint8_t sum = static_cast<uint8_t>(head[0] + head[1] + head[2]);
        for (int i = 0; i < actual; ++i) {
            sum = static_cast<uint8_t>(sum + payload[i]);
        }
        if (sum != payload[actual]) return fail();
        for (int i = 0; i < actual; ++i) {
            samples[produced++] =
                static_cast<int16_t>((static_cast<int>(payload[i]) - 128) * 256);
        }
        if (actual < want) break;  // nothing more buffered right now
    }
    xSemaphoreGive(mutex_);
    return produced;
}
AudioUart::Stats AudioUart::stats() const {
    Stats s;
    s.ack_failures = ack_failures_.load();
    s.stream_gaps = stream_gaps_.load();
    s.stream_resets = stream_resets_.load();
    s.stalls = stalls_.load();
    return s;
}

bool AudioUart::SendLocked(uint8_t command, const uint8_t* payload, size_t size,
                           uint8_t* accepted) {
    if (size > kMaxPayload) {
        return false;
    }
    std::array<uint8_t, kMaxPayload + 4> frame = {};
    frame[0] = kControlPrefix;
    frame[1] = command;
    frame[2] = static_cast<uint8_t>(size);
    if (size > 0 && payload != nullptr) {
        std::memcpy(frame.data() + 3, payload, size);
    }
    frame[size + 3] = Checksum(frame.data(), size + 3);
    const size_t frame_size = size + 4;

    // No flush on the happy path: a frame already in flight would otherwise be
    // masked and the next transaction would read its ack.
    if (uart_write_bytes(port_, frame.data(), frame_size) !=
        static_cast<int>(frame_size)) {
        uart_flush_input(port_);
        ack_failures_.fetch_add(1);
        return false;
    }
    // uart_write_bytes only queues the bytes; reading the ack without waiting
    // for TX to drain picks up the previous frame's answer or half a frame.
    if (uart_wait_tx_done(port_, pdMS_TO_TICKS(20)) != ESP_OK) {
        uart_flush_input(port_);
        ack_failures_.fetch_add(1);
        return false;
    }
    std::array<uint8_t, 3> reply = {};
    if (!ReadExactLocked(reply.data(), reply.size(), kCommandTimeoutMs) ||
        reply[0] != kControlAckPrefix || reply[1] != command) {
        // Never resend the frame: the coprocessor may already have taken it and
        // only lost the ack, so a resend would play the same PCM twice and fill
        // its receive buffer further.
        uart_flush_input(port_);
        ack_failures_.fetch_add(1);
        return false;
    }
    if (accepted != nullptr) {
        *accepted = reply[2];
    }
    return true;
}

bool AudioUart::ReadExactLocked(uint8_t* data, size_t length, int timeout_ms) {
    // Total budget, not per-read: when bytes trickle in, a per-read timeout can
    // stretch one "50 ms" transaction to hundreds of milliseconds while still
    // holding the mutex.
    size_t got = 0;
    const int64_t deadline =
        esp_timer_get_time() + static_cast<int64_t>(timeout_ms) * 1000;
    while (got < length) {
        const int64_t left_us = deadline - esp_timer_get_time();
        if (left_us <= 0) {
            return false;
        }
        TickType_t ticks = pdMS_TO_TICKS((left_us + 999) / 1000);
        if (ticks == 0) {
            ticks = 1;
        }
        const int result = uart_read_bytes(port_, data + got, length - got, ticks);
        if (result <= 0) {
            return false;
        }
        got += static_cast<size_t>(result);
    }
    return true;
}
bool AudioUart::ApplyVolumeLocked(bool force) {
    return volume_.Apply(
        [this](uint8_t step) {
            uint8_t accepted = 0;
            if (SendLocked(kVolumeCommand, &step, 1, &accepted) && accepted == 1) {
                return true;
            }
            // Keep the target pending; drop a stale or partial ack first.
            uart_flush_input(port_);
            return false;
        },
        force);
}

bool AudioUart::SendWavHeaderLocked() {
    // Same bring-up order as the working driver: volume, stop the record stream
    // (half duplex link), then the 44 byte header that opens playback. The
    // reverse order lets the 0x10 write reset the audio path and swallow the
    // volume command that follows it.
    if (!ApplyVolumeLocked(true)) {
        ESP_LOGW(kTag, "volume before header rejected");
    }
    if (!StopRecordLocked()) {
        ESP_LOGW(kTag, "record stop before header rejected");
    }

    constexpr uint32_t rate = board::kAudioSampleRate;
    const std::array<uint8_t, 44> header = {
        'R', 'I', 'F', 'F', 0xff, 0xff, 0xff, 0xff,
        'W', 'A', 'V', 'E', 'f', 'm', 't', ' ',
        0x10, 0x00, 0x00, 0x00,        // fmt chunk size = 16
        0x01, 0x00,                    // PCM
        0x01, 0x00,                    // mono
        static_cast<uint8_t>(rate), static_cast<uint8_t>(rate >> 8),
        static_cast<uint8_t>(rate >> 16), static_cast<uint8_t>(rate >> 24),
        static_cast<uint8_t>(rate), static_cast<uint8_t>(rate >> 8),
        static_cast<uint8_t>(rate >> 16), static_cast<uint8_t>(rate >> 24),
        0x01, 0x00,                    // block align = 1
        0x08, 0x00,                    // 8 bits per sample
        'd', 'a', 't', 'a', 0xff, 0xff, 0xff, 0xff,
    };
    if (!SendLocked(kPcmWriteCommand, header.data(), header.size(), nullptr)) {
        return false;
    }
    stream_configured_.store(true);
    // A freshly opened session starts its own clock; the gap test must not fire
    // on the very first PCM frame written after this.
    last_write_us_ = esp_timer_get_time();
    return true;
}


bool AudioUart::session_stale() const {
    if (!stream_configured_.load()) {
        return true;
    }
    const int64_t last = last_write_us_.load();
    return last == 0 || (esp_timer_get_time() - last) > kStreamGapUs;
}

}  // namespace radio

