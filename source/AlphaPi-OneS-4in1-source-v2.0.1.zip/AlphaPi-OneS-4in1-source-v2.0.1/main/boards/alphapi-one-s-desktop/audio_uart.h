#pragma once

// Half-duplex link to the board's audio co-processor (N32).
//
// Frame: 0x90 | CMD | LEN | PAYLOAD[LEN] | CHK   (LEN <= 200)
// Ack:   0x91 | CMD | accepted
// CHK is an 8-bit sum over every preceding byte of the frame.
//
// The co-processor only accepts 8-bit unsigned mono PCM, streamed as a 44 byte
// WAV header followed by raw samples. Sending the header is what (re)configures
// its playback sample rate, and a gap of more than half a second ends the
// session, so the header has to be re-sent after such a gap but never inside a
// running stream (those 44 bytes would be played as PCM).
//
// This is the only object in the firmware that owns the UART1 driver.

#include <atomic>
#include <cstddef>
#include <cstdint>

#include "driver/uart.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"

#include "audio_volume.h"
#include "board_config.h"

namespace radio {

class AudioUart {
public:
    struct Stats {
        uint32_t ack_failures = 0;   // frame write / TX wait / ACK read failed
        uint32_t stream_gaps = 0;    // >500 ms gap invalidated the cached header
        uint32_t stream_resets = 0;  // link judged dead, header cache dropped
        uint32_t stalls = 0;         // accepted == 0 backpressure (not a fault)
    };

    static AudioUart& Instance();

    // Idempotent. Installs the UART driver, waits for the co-processor to boot,
    // applies the initial volume and stops the microphone stream.
    bool Init();
    bool ready() const { return ready_.load(); }

    // 0x10 with a zero payload. The link is half duplex, so this must run before
    // playback and again after any stall.
    void StopRecord();

    // Drops the cached WAV header; the next Write() re-sends it.
    void InvalidateStream();
    bool stream_configured() const;
    // True when the next Write() will reopen the playback session, i.e. the
    // audio owner should pad lead-in silence before real content (the
    // coprocessor swallows roughly the first 100-150 ms of a new session).
    bool session_stale() const;

    // Publishes the target percentage. The hardware step is only written when a
    // playback session opens (see SetVolume's comment in the .cc); the PCM gain
    // below carries the fine-grained value.
    void SetVolume(int percent);
    bool ApplyPendingVolume();
    int volume() const { return requested_percent_.load(); }  // unquantised, for UI
    int volume_step() const { return volume_.applied_step(); }
    uint32_t volume_failures() const { return volume_.failures(); }

    // Returns the number of frames the co-processor accepted; 0 means none of
    // this block went out. A 0 return is not proof the link is gone.
    int Write(const int16_t* samples, int count);
    int WriteU8(const uint8_t* samples, int count);
    // Microphone read; calling it yields playback (half duplex).
    int Read(int16_t* samples, int count);
    // Smoothed 0..100 loudness, decays on every call.
    int Level();

    Stats stats() const;

private:
    AudioUart() = default;

    bool SendLocked(uint8_t command, const uint8_t* payload, size_t size,
                    uint8_t* accepted);
    bool StopRecordLocked();
    bool SendWavHeaderLocked();
    bool ApplyVolumeLocked(bool force = false);
    bool ReadExactLocked(uint8_t* data, size_t length, int timeout_ms);

    // Headroom for the software gain below: 6 is the coprocessor's loudest
    // step, so the PCM gain stays the only attenuator and the fallback still
    // works if register 0x14 is ignored while a stream is running.
    static constexpr int kHardwarePercent = 100;
    // Default user-visible level, four of six steps.
    static constexpr int kDefaultVolume = 67;
    // Protocol hard limit for one frame payload.
    static constexpr size_t kMaxPayload = 200;
    // 200 bytes at 460800 baud is about 3.5 ms and the 3 byte ack about 65 us,
    // so this keeps roughly 10x headroom while bounding how long a lost ack can
    // hold the mutex. Matches the known-good driver on purpose.
    static constexpr int kCommandTimeoutMs = 120;
    // A gap this long makes the co-processor close the playback session.
    static constexpr int64_t kStreamGapUs = 500 * 1000;
    // Time the backpressure wait may spend on one block before giving up.
    static constexpr int64_t kStallBudgetUs = 1500 * 1000;
    // The co-processor boots slower than the ESP32; the first frame sent during
    // that window is lost and leaves junk in the receive path.
    static constexpr int kBootWaitMs = 2000;

    uart_port_t port_ = board::kAudioUart;
    SemaphoreHandle_t mutex_ = nullptr;  // created in Init(), never destroyed
    std::atomic<bool> ready_{false};
    std::atomic<bool> stream_configured_{false};
    std::atomic<bool> recording_{false};
    std::atomic<int64_t> last_write_us_{0};
    AudioVolume volume_;
    std::atomic<int> requested_percent_{kDefaultVolume};
    std::atomic<int> peak_{0};
    int level_ = 0;
    int level_tick_ = 0;
    std::atomic<uint32_t> ack_failures_{0};
    std::atomic<uint32_t> stream_gaps_{0};
    std::atomic<uint32_t> stream_resets_{0};
    std::atomic<uint32_t> stalls_{0};
};

}  // namespace radio
