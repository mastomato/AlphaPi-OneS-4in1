#if __has_include("wifi_profile.private.h")
#include "wifi_profile.private.h"
#else
#define DESKTOP_INITIAL_SSID ""
#define DESKTOP_INITIAL_PASSWORD ""
#endif
#include "desktop_runtime.h"
#include "settings.h"
#include "esp_wifi.h"
#include "esp_wifi_default.h"
#include "esp_timer.h"
#include "esp_netif.h"
#include "esp_event.h"
#include "esp_netif_sntp.h"
#include "esp_crt_bundle.h"
#include "esp_http_client.h"
#include "esp_spiffs.h"
#include "cJSON.h"
#include <cmath>
#include <cstring>
#include <ctime>
#include <cstdio>
namespace {
std::string JsonString(cJSON* j){char* s=cJSON_PrintUnformatted(j);std::string result=s?s:"{}";free(s);cJSON_Delete(j);return result;}
std::string HttpGet(const std::string& url){
 struct Response {std::string data;bool overflow=false;} response;
 esp_http_client_config_t cfg={};cfg.url=url.c_str();cfg.timeout_ms=15000;cfg.crt_bundle_attach=esp_crt_bundle_attach;cfg.buffer_size=2048;cfg.addr_type=HTTP_ADDR_TYPE_INET;cfg.user_agent="AlphaPiDesktop/1.0";cfg.max_redirection_count=3;cfg.user_data=&response;
 cfg.event_handler=[](esp_http_client_event_t* event)->esp_err_t{
  if(event->event_id==HTTP_EVENT_ON_DATA && event->data_len>0 && esp_http_client_get_status_code(event->client)==200){
   auto result=static_cast<Response*>(event->user_data);
   if(result->data.size()+event->data_len>32768){result->overflow=true;return ESP_FAIL;}
   result->data.append(static_cast<const char*>(event->data),event->data_len);
  }
  return ESP_OK;
 };
 auto client=esp_http_client_init(&cfg);if(!client)return {};
 esp_http_client_set_header(client,"Accept","application/json");esp_http_client_set_header(client,"Accept-Encoding","identity");
 auto error=esp_http_client_perform(client);int status=esp_http_client_get_status_code(client);
 if(error!=ESP_OK||status!=200||response.overflow){printf("DESKTOP_HTTP error=%s status=%d url=%s\n",esp_err_to_name(error),status,url.c_str());response.data.clear();}
 esp_http_client_cleanup(client);return response.data;
}
const char* WeatherName(int code){if(code<2)return "晴";if(code==2)return "多云";if(code==3)return "阴";if(code<50)return "雾";if(code<70)return "雨";if(code<80)return "雪";if(code<90)return "阵雨";return "雷雨";}
}
void DesktopRuntime::StartNetwork(){
 esp_vfs_spiffs_conf_t fs={};fs.base_path="/data";fs.partition_label="storage";fs.max_files=5;fs.format_if_mount_failed=true;esp_vfs_spiffs_register(&fs);
 {Settings config("desk_weather",false);auto saved=config.GetString("region","");if(!saved.empty())SaveRegion(saved.c_str());}
 {Settings config("desk_wifi",false);ssid=config.GetString("ssid","");pass=config.GetString("password","");}
 if(ssid.empty() && strlen(DESKTOP_INITIAL_SSID)>0){ssid=DESKTOP_INITIAL_SSID;pass=DESKTOP_INITIAL_PASSWORD;Settings saved("desk_wifi",true);saved.SetString("ssid",ssid);saved.SetString("password",pass);}
 {Settings volume("desk_audio",false);SetVolume(volume.GetInt("volume",85));}
 // Do not bail out on a non-fatal event-loop result: the UI task already runs
 // independently, but we still want WiFi/HTTPD to come up.
 esp_netif_init();
 auto err=esp_event_loop_create_default();
 if(err!=ESP_OK&&err!=ESP_ERR_INVALID_STATE)printf("DESKTOP_NET event loop error=%s\n",esp_err_to_name(err));
 // Back to the pre-provisioning-work baseline (v6): both netifs exist for the
 // whole session, created here, and the hotspot is nothing more than a mode
 // switch to APSTA. Every rewrite after that (AP netif per session, manual
 // DHCP/IP handling, pure AP, default netif juggling) is reverted - none of it
 // helped, and each step moved further away from stock IDF behaviour.
 esp_netif_create_default_wifi_sta();esp_netif_create_default_wifi_ap();
 wifi_init_config_t cfg=WIFI_INIT_CONFIG_DEFAULT();
 // No ESP_ERROR_CHECK anywhere in the boot path: an abort here panics and
 // reboots, which on this screen looks exactly like a frozen UI.
 auto wifi_err=esp_wifi_init(&cfg);
 if(wifi_err!=ESP_OK){
  printf("DESKTOP_NET wifi init error=%s\n",esp_err_to_name(wifi_err));
  return;
 }
 esp_wifi_set_storage(WIFI_STORAGE_RAM);
 esp_event_handler_register(WIFI_EVENT,ESP_EVENT_ANY_ID,WifiEvent,this);esp_event_handler_register(IP_EVENT,IP_EVENT_STA_GOT_IP,WifiEvent,this);
 // Lease events are the only proof that the DHCP server really handed out an
 // address; the AP station list alone cannot tell that apart from a phone whose
 // packets never make it through.
 esp_event_handler_register(IP_EVENT,IP_EVENT_AP_STAIPASSIGNED,WifiEvent,this);
 auto mode_err=esp_wifi_set_mode(WIFI_MODE_STA);
 if(mode_err!=ESP_OK)printf("DESKTOP_NET mode error=%s\n",esp_err_to_name(mode_err));
 if(!ssid.empty()){wifi_config_t station={};strncpy((char*)station.sta.ssid,ssid.c_str(),sizeof(station.sta.ssid));strncpy((char*)station.sta.password,pass.c_str(),sizeof(station.sta.password));esp_wifi_set_config(WIFI_IF_STA,&station);}
 auto start_err=esp_wifi_start();
 if(start_err!=ESP_OK)printf("DESKTOP_NET start error=%s\n",esp_err_to_name(start_err));
 esp_wifi_set_ps(WIFI_PS_NONE);
 // The hotspot worker MUST be created before httpd. v18/v19 started httpd
 // first: its 8 KB task stack plus the socket table consumed the contiguous
 // internal RAM that ap_switch needs, xTaskCreate failed, and the config page
 // then sat on "正在开启热点" forever with no beacon at all - ap_desired was
 // set but nobody ever executed OpenAP(). This is the v16/v17 order, which is
 // the one that actually produced a working hotspot on this board.
 EnsureApWorker();
 StartWeb();
 // Do not open the hotspot automatically on boot. Bringing the AP up flips the
 // radio into APSTA and blocks for a moment; doing that in the middle of the
 // boot sequence is what made the UI look frozen. The user opens it explicitly
 // with a long press of A, from a dedicated task.
 if(ssid.empty())ap_advise=true;
 StartUiTask();
 xTaskCreate([](void* p){static_cast<DesktopRuntime*>(p)->WeatherTask();},"desktop_weather",8192,this,1,nullptr);
}
namespace {
}
void DesktopRuntime::WifiEvent(void* arg, const char* base, int32_t id, void* data) {
    auto& self = *static_cast<DesktopRuntime*>(arg);
    if (base == IP_EVENT && id == IP_EVENT_STA_GOT_IP) {
        desktop_network = true;
        self.weather_refresh = true;
        auto got = static_cast<ip_event_got_ip_t*>(data);
        if (got) self.sta_ip = got->ip_info.ip.addr;
        if (self.network_callback)
            self.network_callback(NetworkEvent::Connected, self.ssid);
    }
    if (base == WIFI_EVENT && id == WIFI_EVENT_STA_START && !self.ssid.empty())
        esp_wifi_connect();
    if (base == WIFI_EVENT && id == WIFI_EVENT_AP_START) {
        // Only now is the SSID really on air. The UI switch and the web page both
        // read this instead of trusting the request we sent to the driver.
        self.ap_live = true;
        printf("DESKTOP_AP live, ssid=AlphaPi-Desk\n");
    }
    if (base == WIFI_EVENT && id == WIFI_EVENT_AP_STOP) {
        self.ap_live = false;
    }
    if (base == IP_EVENT && id == IP_EVENT_AP_STAIPASSIGNED) {
        // Proof that the DHCP server really handed out a lease. Without this the
        // screen can only show "a phone is associated", which is also what a
        // half-broken data path looks like.
        self.ap_lease = true;
        printf("DESKTOP_AP lease assigned\n");
    }
    if (base == WIFI_EVENT && id == WIFI_EVENT_STA_DISCONNECTED) {
        desktop_network = false;
        self.sta_ip = 0;   // 掉线后别再拿旧地址骗人（配网页会显示这一行）
        auto event = static_cast<wifi_event_sta_disconnected_t*>(data);
        printf("DESKTOP_WIFI disconnected reason=%u scanning=%d\n", event ? event->reason : 0,
               self.wifi_scan_active.load());
        if (self.network_callback)
            self.network_callback(NetworkEvent::Disconnected, "");
        // Back to the baseline behaviour: keep reconnecting even while the
        // hotspot is up. The station share of APSTA is what the clock, weather
        // and radio rely on, and the softAP shares the same radio anyway.
        if (!self.ssid.empty() && !self.wifi_scan_active.load())
            esp_wifi_connect();
    }
    self.dirty = true;
}
#include "lwip/sockets.h"
#include <unistd.h>
#include "freertos/task.h"
namespace {
// A phone on a Wi-Fi with no internet probes its own DNS server
// (connectivitycheck.gstatic.com, captive.apple.com, connect.rom.miui.com ...).
// DHCP hands out 192.168.4.1 as that DNS server; when nothing listens on 53 the
// OS declares the Wi-Fi dead, switches to mobile data, and a manually typed
// 192.168.4.1 goes out over LTE - so the page can never load. Answering those
// probes with the AP address keeps the Wi-Fi selected and produces the system
// "sign in to network" sheet. Only A queries get an address; everything else is
// NXDOMAIN, so we do not pretend to have a real internet connection.
bool ServeProbeDns(int sock,std::atomic<int>& hits){
 char q[256];
 sockaddr_in from={};socklen_t flen=sizeof(from);
 int n=recvfrom(sock,q,sizeof(q),0,reinterpret_cast<sockaddr*>(&from),&flen);
 if(n<17)return false;
 int p=12;
 while(p<n&&q[p]){
  int l=static_cast<unsigned char>(q[p]);
  if(l>63||p+1+l>=n)return false;
  p+=l+1;
 }
 const int qend=p+5;
 if(qend>n)return false;
 const int qtype=(static_cast<unsigned char>(q[p+1])<<8)|static_cast<unsigned char>(q[p+2]);
 char reply[300];
 int rlen=qend;
 memcpy(reply,q,rlen);
 reply[2]|=0x80;                              // QR = response
 reply[3]=(q[3]&0x80)|(qtype==1?0:3);        // NXDOMAIN for non-A
 reply[6]=0;reply[7]=0;reply[8]=0;reply[9]=0;reply[10]=0;reply[11]=0;
 if(qtype==1){
  reply[7]=1;                                // ANCOUNT = 1
  reply[rlen++]=0xc0;reply[rlen++]=0x0c;    // name pointer to the question
  reply[rlen++]=0;reply[rlen++]=1;          // A
  reply[rlen++]=0;reply[rlen++]=1;          // IN
  reply[rlen++]=0;reply[rlen++]=0;reply[rlen++]=0;reply[rlen++]=30; // TTL
  reply[rlen++]=0;reply[rlen++]=4;
  reply[rlen++]=192;reply[rlen++]=168;reply[rlen++]=4;reply[rlen++]=1;
  hits++;
 }
 sendto(sock,reply,rlen,0,reinterpret_cast<sockaddr*>(&from),flen);
 return true;
}
// Proves the web server is reachable on the AP address from the board itself.
// If this is OK and the phone still cannot load the page, the phone is sending
// the request over mobile data instead of the Wi-Fi.
bool WebSelfTest(){
 int s=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
 if(s<0)return false;
 timeval tv={};tv.tv_sec=1;
 setsockopt(s,SOL_SOCKET,SO_RCVTIMEO,&tv,sizeof(tv));
 setsockopt(s,SOL_SOCKET,SO_SNDTIMEO,&tv,sizeof(tv));
 sockaddr_in a={};a.sin_family=AF_INET;a.sin_port=htons(80);
 a.sin_addr.s_addr=htonl(0xC0A80401UL); // 192.168.4.1
 bool ok=false;
 if(connect(s,reinterpret_cast<sockaddr*>(&a),sizeof(a))==0){
  static const char kReq[]="GET /ping HTTP/1.0\r\nHost: 192.168.4.1\r\n\r\n";
  if(send(s,kReq,sizeof(kReq)-1,0)>0){
   char b[96]={};int n=recv(s,b,sizeof(b)-1,0);
   if(n>0){b[n]=0;ok=strstr(b,"pong")!=nullptr;}
  }
 }
 close(s);
 return ok;
}
}

void DesktopRuntime::ResetSavedWifi(){
 // Erase NVS, clear the driver's station config, and drop any in-flight attempt.
 // All three matter: erasing NVS alone leaves the driver happily retrying the
 // network it was initialised with until the next boot.
 {
  Settings saved("desk_wifi",true);
  saved.EraseAll();
 }
 ssid.clear();pass.clear();
 wifi_config_t empty={};
 auto cerr=esp_wifi_set_config(WIFI_IF_STA,&empty);
 if(cerr!=ESP_OK)printf("DESKTOP_WIFI clear config=%s\n",esp_err_to_name(cerr));
 esp_wifi_disconnect();
 ap_advise=true;
 wifi_reset_at=esp_timer_get_time()/1000;
 dirty=true;
 printf("DESKTOP_WIFI saved network erased\n");
}
// Brings the provisioning hotspot up. MUST NOT be called from the UI task:
// esp_wifi_set_mode() blocks for a while and would freeze the screen.
void DesktopRuntime::OpenAP(){
 // Baseline (v6) bring-up, restored verbatim. Nothing here touches the AP
 // netif's address, the DHCP server, the default netif or the station link:
 // esp_netif_create_default_wifi_ap() already set 192.168.4.1/24 and started
 // dhcps long ago, and APSTA can be entered live. Every "fix" that went beyond
 // this made the phone's experience worse, so the extra writes are gone.
 if(ap_enabled&&ap_live.load()){StartWeb();dirty=true;return;}
 ap_enabled=false;
 ap_live=false;
 ap_lease=false;
 ap_err=0;
 ap_started_at=0;
 ap_ip=0;ap_chan=0;ap_dhcp=false;ap_dhcp_err=0;ap_netif_up=false;
 if(ap_netif==nullptr)ap_netif=esp_netif_get_handle_from_ifkey("WIFI_AP_DEF");
 if(ap_netif==nullptr){
  ap_netif=esp_netif_create_default_wifi_ap();
  if(ap_netif==nullptr)printf("DESKTOP_AP netif create failed\n");
 }
 // The station half of APSTA is the one condition the vendor's provisioning
 // never has: it starts with no saved network at all. If the saved network is
 // not actually connected right now, forget it here - an unreachable station
 // retries on every disconnect, and each retry pulls the single antenna off the
 // AP channel, which is what a phone sees as "keeps connecting, never gets an
 // address". The user re-enters the network on the page anyway.
 if(!ssid.empty()&&!desktop_network.load())ResetSavedWifi();
 wifi_config_t ap={};
 strcpy(reinterpret_cast<char*>(ap.ap.ssid),"AlphaPi-Desk");
 ap.ap.ssid_len=static_cast<uint8_t>(strlen(reinterpret_cast<char*>(ap.ap.ssid)));
 ap.ap.password[0]=0;
 ap.ap.max_connection=4;
 ap.ap.authmode=WIFI_AUTH_OPEN;
 // No channel: single antenna, the AP has to follow the STA channel.
 // No esp_wifi_stop() either: stopping the driver kills the in-flight station
 // link and stalls anything waiting on it. APSTA can be entered live.
 int stage=1;
 auto mode=esp_wifi_set_mode(WIFI_MODE_APSTA);
 if(mode!=ESP_OK){ap_err=10+(mode&0xFF);printf("DESKTOP_AP mode error=%s\n",esp_err_to_name(mode));}
 auto conf=esp_wifi_set_config(WIFI_IF_AP,&ap);
 if(conf!=ESP_OK){if(!ap_err.load())ap_err=20+(conf&0xFF);printf("DESKTOP_AP config error=%s\n",esp_err_to_name(conf));}
 auto started=esp_wifi_start();
 if(started!=ESP_OK&&started!=ESP_ERR_WIFI_STATE){if(!ap_err.load())ap_err=30+(started&0xFF);printf("DESKTOP_AP start error=%s\n",esp_err_to_name(started));}
 esp_wifi_set_ps(WIFI_PS_NONE);
 ap_started_at=esp_timer_get_time()/1000;
 ap_enabled=true;
 // Wait for WIFI_EVENT_AP_START. If the beacon never comes up, the mode switch
 // was ignored (it can happen while the station is mid-connect); cycle the mode
 // once. This task is dedicated to the switch, so blocking here costs nothing
 // and the UI keeps running.
 for(int attempt=0;attempt<2;attempt++){
  for(int i=0;i<30&&!ap_live.load();i++)vTaskDelay(pdMS_TO_TICKS(100));
  if(ap_live.load())break;
  printf("DESKTOP_AP not live, retry %d\n",attempt+1);
  esp_wifi_set_mode(WIFI_MODE_STA);
  vTaskDelay(pdMS_TO_TICKS(150));
  stage=2;
  esp_wifi_set_mode(WIFI_MODE_APSTA);
  esp_wifi_set_config(WIFI_IF_AP,&ap);
  esp_wifi_start();
  esp_wifi_set_ps(WIFI_PS_NONE);
 }
 if(!ap_live.load()){
  if(!ap_err.load())ap_err=99;
  web_error=100+stage;
  printf("DESKTOP_AP failed stage=%d\n",stage);
 }else{
  web_error=0;
  // Read-only: what the driver actually ended up with, for the screen. No
  // stop/start/set here - just observation.
  auto* netif=static_cast<esp_netif_t*>(ap_netif);
  if(netif){
   esp_netif_dhcp_status_t st=ESP_NETIF_DHCP_INIT;
   esp_netif_dhcps_get_status(netif,&st);
   ap_dhcp=(st==ESP_NETIF_DHCP_STARTED);
   ap_netif_up=esp_netif_is_netif_up(netif);
   esp_netif_ip_info_t got={};
   esp_netif_get_ip_info(netif,&got);
   ap_ip=got.ip.addr;
  }
  uint8_t chan=0;wifi_second_chan_t second=WIFI_SECOND_CHAN_NONE;
  if(esp_wifi_get_channel(&chan,&second)==ESP_OK)ap_chan=chan;
  printf("DESKTOP_AP live dhcp=%d up=%d ch=%d\n",ap_dhcp.load()?1:0,
         ap_netif_up.load()?1:0,ap_chan.load());
 }
 StartWeb();dirty=true;
}
// Records what the user wants. The driver work happens on a long lived worker
// task instead of a task spawned per press: xTaskCreate on every key press also
// meant a failed allocation silently swallowed the press, and the one-shot task
// could leave ap_busy stuck forever if the bring-up blocked.
void DesktopRuntime::OpenAPAsync(bool enable){
 ap_desired=enable;
 ap_failed=false;
 EnsureApWorker();
}
// Idempotent. Prefer calling it once early (boot) while the heap is untouched;
// a press that arrives first creates it on demand.
void DesktopRuntime::EnsureApWorker(){
 if(ap_worker_up.load())return;
 auto entry=[](void* p){
  auto* self=static_cast<DesktopRuntime*>(p);
  self->ApWorker();
  vTaskDelete(nullptr);
 };
 // 8 KB, not 3 KB: OpenAP() goes esp_wifi_set_mode -> set_config -> start and
 // prints between them, and a short stack overflow panics and reboots the board
 // right when the config page is opened. Fall back once if the heap is tight.
 if(xTaskCreate(entry,"ap_switch",8192,this,3,nullptr)==pdPASS){ap_worker_up=true;return;}
 if(xTaskCreate(entry,"ap_switch",5120,this,3,nullptr)==pdPASS){ap_worker_up=true;return;}
 printf("DESKTOP_AP worker create failed\n");
}
// Reconciles the driver with ap_desired. Runs forever at 150 ms so a request is
// picked up even if it arrived while a previous switch was still in flight.
void DesktopRuntime::ApWorker(){
 bool applied=false;
 int attempts=0;
 int64_t last_try=0;
 int64_t last_web_test=0;
 // One UDP socket for the whole session, bound to port 53 on all interfaces.
 // It only answers while the hotspot is live, so it cannot interfere with DNS
 // on the home network. No extra task and no 4 KB stack: this worker already
 // has 8 KB and internal RAM on this board is nearly exhausted.
 int dns_sock=socket(AF_INET,SOCK_DGRAM,IPPROTO_UDP);
 if(dns_sock>=0){
  int yes=1;setsockopt(dns_sock,SOL_SOCKET,SO_REUSEADDR,&yes,sizeof(yes));
  sockaddr_in a={};a.sin_family=AF_INET;a.sin_port=htons(53);a.sin_addr.s_addr=htonl(INADDR_ANY);
  if(bind(dns_sock,reinterpret_cast<sockaddr*>(&a),sizeof(a))<0){close(dns_sock);dns_sock=-1;}
  else{
   timeval tv={};tv.tv_usec=20000;
   setsockopt(dns_sock,SOL_SOCKET,SO_RCVTIMEO,&tv,sizeof(tv));
  }
 }else printf("DESKTOP_PORTAL dns socket failed\n");
 for(;;){
  const bool want=ap_desired.load();
  const int64_t now=esp_timer_get_time()/1000;
  bool need=(want!=applied);
  // Wanted on but the beacon never came up: retry a few times rather than leave
  // a switch that reads "on" with nothing on air.
  if(!need&&want&&!ap_live.load()&&attempts<3&&now-last_try>5000)need=true;
  if(need){
   ap_busy=true;
   last_try=now;
   ap_apply_at=now;
   if(want){
    attempts++;
    // Force the fresh bring-up path: OpenAP() short circuits when ap_enabled is
    // already true, which is exactly the state a failed previous attempt left.
    if(ap_enabled.load())ap_enabled=false;
    OpenAP();
   }else{
    attempts=0;
    CloseAP();
   }
   applied=want;
   ap_busy=false;
   ap_failed=(want&&!ap_live.load());
  }
  // Portal detection: answer the phone's DNS probes so the OS keeps this Wi-Fi
  // selected (instead of falling back to mobile data) and offers its sign-in
  // sheet. Only while the beacon is really on air.
  if(dns_sock>=0&&ap_live.load()){
   for(int i=0;i<4&&ServeProbeDns(dns_sock,portal_dns);i++){}
  }
  // No periodic httpd_start() retries: each failed attempt can leak the
  // partially-built server and, with ~4 KB of internal RAM left, slowly starve
  // the heap until something panics. StartWeb() is called once at boot (before
  // the big tasks, when the heap is fattest) and once per hotspot open - if it
  // failed, the screen says "服务未启动 E<code>" instead of rebooting.
  // Every 10 s, ask our own httpd on the AP address. This is the on-screen proof
  // that the page is being served at 192.168.4.1 at all.
  if(ap_live.load()&&now-last_web_test>10000){
   last_web_test=now;
   web_self_ok=server?WebSelfTest():false;
   dirty=true;
  }
  vTaskDelay(pdMS_TO_TICKS(150));
 }
}
void DesktopRuntime::ConnectWifi(const std::string& name,const std::string& password){
 {Settings saved("desk_wifi",true);saved.SetString("ssid",name);saved.SetString("password",password);}
 ssid=name;pass=password;esp_wifi_disconnect();wifi_config_t station={};strncpy((char*)station.sta.ssid,name.c_str(),sizeof(station.sta.ssid));strncpy((char*)station.sta.password,password.c_str(),sizeof(station.sta.password));esp_wifi_set_config(WIFI_IF_STA,&station);esp_wifi_connect();dirty=true;
}
bool DesktopRuntime::SaveRegion(const char* json){
 auto root=cJSON_Parse(json);if(!root)return false;
 auto n=cJSON_GetObjectItem(root,"name"),la=cJSON_GetObjectItem(root,"latitude"),lo=cJSON_GetObjectItem(root,"longitude");
 bool valid=cJSON_IsString(n)&&strlen(n->valuestring)>0&&strlen(n->valuestring)<=60&&cJSON_IsNumber(la)&&cJSON_IsNumber(lo)&&std::isfinite(la->valuedouble)&&std::isfinite(lo->valuedouble)&&fabs(la->valuedouble)<=90&&fabs(lo->valuedouble)<=180;
 if(valid){std::lock_guard<std::mutex> lock(state_mutex);city=n->valuestring;latitude=la->valuedouble;longitude=lo->valuedouble;have_weather=false;description="正在更新";Settings saved("desk_weather",true);saved.SetString("region",json);weather_refresh=true;dirty=true;}
 cJSON_Delete(root);return valid;
}
std::string DesktopRuntime::RegionJson(){
 std::lock_guard<std::mutex> lock(state_mutex);auto root=cJSON_CreateObject();auto r=cJSON_AddObjectToObject(root,"region");cJSON_AddStringToObject(r,"name",city.c_str());cJSON_AddNumberToObject(r,"latitude",latitude);cJSON_AddNumberToObject(r,"longitude",longitude);return JsonString(root);
}
std::string DesktopRuntime::SearchRegions(const std::string& q){
 if(!desktop_network.load())return "{\"ok\":false,\"error\":\"设备尚未联网\"}";
 auto data=HttpGet("https://geocoding-api.open-meteo.com/v1/search?count=8&language=zh&format=json&name="+q);
 if(data.empty())return "{\"ok\":false,\"error\":\"城市搜索暂不可用\"}";
 return data;
}
std::string DesktopRuntime::ScanWifi() {
    if (wifi_scan_active.exchange(true))
        return "{\"ok\":false,\"error\":\"正在扫描，请稍候重试\"}";
    // A failing station connection otherwise keeps the driver busy and rejects scans.
    bool paused = !desktop_network.load();
    if (paused) {
        esp_wifi_disconnect();
        vTaskDelay(pdMS_TO_TICKS(150));
    }
    wifi_scan_config_t cfg = {};
    cfg.show_hidden = false;
    auto error = esp_wifi_scan_start(&cfg, true);
    wifi_scan_active = false;
    if (paused && !ssid.empty())
        esp_wifi_connect();
    if (error != ESP_OK) {
        printf("DESKTOP_WIFI scan error=%s\n", esp_err_to_name(error));
        return "{\"ok\":false,\"error\":\"扫描暂不可用，请直接输入 Wi-Fi 名称和密码\"}";
    }
    uint16_t count = 24;
    wifi_ap_record_t records[24] = {};
    if (esp_wifi_scan_get_ap_records(&count, records) != ESP_OK)
        return "{\"ok\":false,\"error\":\"读取扫描结果失败，请重试\"}";
    auto root = cJSON_CreateObject();
    auto list = cJSON_AddArrayToObject(root, "networks");
    for (int i = 0; i < count; i++) {
        auto item = cJSON_CreateObject();
        cJSON_AddStringToObject(item, "ssid", (char*)records[i].ssid);
        cJSON_AddNumberToObject(item, "rssi", records[i].rssi);
        cJSON_AddBoolToObject(item, "secure", records[i].authmode != WIFI_AUTH_OPEN);
        cJSON_AddItemToArray(list, item);
    }
    return JsonString(root);
}
void DesktopRuntime::WeatherTask() {
    bool ntp = false;
    time_t last = 0;
    for (;;) {
        if (desktop_network.load()) {
            if (!ntp) {
                setenv("TZ", "CST-8", 1);
                tzset();
                esp_sntp_config_t cfg = ESP_NETIF_SNTP_DEFAULT_CONFIG("ntp.aliyun.com");
                esp_netif_sntp_init(&cfg);
                ntp = true;
            }
            time_t now = time(nullptr);
            if (weather_refresh.exchange(false) || now - last > 1800) {
                double lat, lon;
                {std::lock_guard<std::mutex> lock(state_mutex);lat=latitude;lon=longitude;}
    char url[256];snprintf(url,sizeof(url),"https://api.open-meteo.com/v1/forecast?latitude=%.5f&longitude=%.5f&current=temperature_2m,relative_humidity_2m,weather_code",lat,lon);
    auto text=HttpGet(url);auto root=cJSON_Parse(text.c_str());auto current=cJSON_GetObjectItem(root,"current");auto temp=cJSON_GetObjectItem(current,"temperature_2m"),hum=cJSON_GetObjectItem(current,"relative_humidity_2m"),code=cJSON_GetObjectItem(current,"weather_code");
    {std::lock_guard<std::mutex> lock(state_mutex);if(lat==latitude&&lon==longitude&&cJSON_IsNumber(temp)&&cJSON_IsNumber(code)){temperature=temp->valuedouble;humidity=cJSON_IsNumber(hum)?hum->valueint:-1;description=WeatherName(code->valueint);have_weather=true;}else if(!have_weather)description="暂不可用";}
    cJSON_Delete(root);last=now;dirty=true;
   }
  }
  vTaskDelay(pdMS_TO_TICKS(1000));
 }
}
