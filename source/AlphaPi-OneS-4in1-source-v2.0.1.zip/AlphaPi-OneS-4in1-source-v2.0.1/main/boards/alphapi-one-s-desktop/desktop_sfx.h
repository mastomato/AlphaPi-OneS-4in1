#pragma once
// 音效表（v40）—— 音效不再是固件里"按频率和毫秒数合成"，而是 assets 分区
// 里的音频文件（8-bit unsigned / 24000Hz / 单声道）。
//
// 为什么换成文件：
//   1. N32 要先攒够一段缓冲才开播，短流会在出声之前就结束。文件长度是看得见
//      的字节数，不用再靠"补多少毫秒静音"的参数去猜；
//   2. 包络、音高、音量都能在 PC 上生成并导出 WAV 试听（见 gh-publish/sfx/
//      gen_sfx.py），改一个参数重新跑一遍就行，不用每次都烧板子试；
//   3. assets 分区是 mmap 的，播放时拿到的是 Flash 指针，零 RAM 占用——
//      这台机器内部 DRAM 只剩几百字节，这点很关键。
//
// 资源缺失（只刷了 app 没刷资源包）时自动退回原来的合成音，不会变成静音。
//
// 生成与打包：
//   python sfx/gen_sfx.py         # 合成 pcm/ 与 wav/（wav 可直接试听）
//   python sfx/pack_assets.py     # 追加进 generated_assets_v40.bin
#include <cstddef>
#include <cstdint>

namespace desktop_sfx {

enum Id : int {
    kMove = 0,  // 方块平移 / 蛇转向
    kTurn,      // 方块旋转 / 拍翅
    kHit,       // 碰撞 / 挡板反弹 / 砖块
    kEat,       // 吃豆 / 得分
    kClear,     // 消行 / 过关
    kDie,       // 死亡 / 失败
    kStart,     // 开局
    kTick,      // 倒计时读秒
    kTickHi,    // 最后 3 秒
    kAlarm,     // 倒计时结束
    kKey,       // UI 确认
    kClick,     // 节拍器弱拍
    kClickHi,   // 节拍器每小节第一拍
    kCount,
};

// 一条音效：文件名 + 资源缺失时的兜底合成参数（freq/ms/type 同 N32Audio::Beep）
struct Clip {
    const char* name;
    int freq;
    int ms;
    int type;
};

inline const Clip* Table() {
    static const Clip kC[kCount] = {
        {"sfx_move", 520, 45, 2},
        {"sfx_turn", 720, 45, 2},
        {"sfx_hit", 150, 95, 2},
        {"sfx_eat", 880, 50, 2},
        {"sfx_clear", 1320, 90, 2},
        {"sfx_die", 360, 220, 0},
        {"sfx_start", 900, 110, 2},
        {"sfx_tick", 1200, 40, 2},
        {"sfx_tick_hi", 1700, 50, 2},
        {"sfx_alarm", 880, 170, 0},
        {"sfx_key", 900, 35, 2},
        {"sfx_click", 1047, 55, 2},
        {"sfx_click_hi", 1568, 65, 2},
    };
    return kC;
}

// 解析资源名 -> mmap 指针（实现见 desktop_board.cc）。
// 返回 nullptr 表示资源包里没有这个文件，调用方应退回合成音。
const uint8_t* Data(Id id, size_t* bytes);

// 播放一条音效（异步投递，立即返回）。实现见 desktop_board.cc。
// tail_ms：音效之后补的静音（默认 60ms），只是避免流断在波形中间；
// 真正决定"短音能不能听到"的是会话开头那 150ms，由 N32Audio::KeepAlive()
// 与 PlayPcmBlock() 的垫静音负责，见 n32_audio.h。
void Play(Id id, int tail_ms = 60);

}  // namespace desktop_sfx
