#pragma once
#include <algorithm>
#include <atomic>
#include <cstdint>

namespace radio {

inline int VolumeStep(int percent) {
    return (std::clamp(percent, 0, 100) * 6 + 50) / 100;
}
inline int VolumePercent(int step) {
    return (std::clamp(step, 0, 6) * 100 + 3) / 6;
}

// Control publishes the latest target without waiting for the UART. Only the
// audio owner applies/acknowledges it; a newer request remains pending even
// when it arrives during the preceding command's ACK wait.
class AudioVolume {
public:
    void Set(int percent) { requested_ = VolumeStep(percent); }
    int requested() const { return VolumePercent(requested_.load()); }
    int applied_step() const { return applied_.load(); }
    uint32_t failures() const { return failures_.load(); }
    template <typename Sender> bool Apply(Sender send, bool force = false) {
        const int step = requested_.load();
        if (!force && step == applied_.load()) return true;
        if (!send(static_cast<uint8_t>(step))) {
            failures_.fetch_add(1);
            return false;
        }
        applied_ = step;
        return true;
    }
private:
    std::atomic<int> requested_{4}, applied_{-1};
    std::atomic<uint32_t> failures_{0};
};

}  // namespace radio
