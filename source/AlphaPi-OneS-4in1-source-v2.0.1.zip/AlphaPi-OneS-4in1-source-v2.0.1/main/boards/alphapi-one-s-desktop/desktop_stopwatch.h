#pragma once
// v47：计时器（秒表 / 正计时）。
//
// 与倒计时（desktop_countdown）相反：从 0 往上走，没有目标时间。
// 状态全部用时间戳推导，不在 UI 循环里累加——UI 任务偶发停顿、切页、
// 甚至去别的页面待一会儿，回来显示的仍是真实经过时间，不会“走慢”。
//
// 键位（page 4 · 视图 3）：
//   A 起停 · B 计次（记一圈）· C 复位 · D 返回目录
//   长按 A 复位 · 长按 D 回主页

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <cstdio>

namespace desktop_stopwatch {

// 上限 99:59，和倒计时的 5999 秒对齐：再长就超出两个数字位的显示宽度。
constexpr int64_t kMaxMs = (99 * 60 + 59) * 1000;

struct Clock {
    int64_t start_ms = 0;   // 本轮起跑时刻（running 时有效）
    int64_t base_ms = 0;    // 之前已经累计的毫秒（暂停时就是总时长）
    bool running = false;
    int lap_count = 0;
    int64_t lap_mark_ms = 0;   // 上一次计次时的总时长
    int64_t last_lap_ms = 0;   // 最近一圈用时

    int64_t Elapsed(int64_t now) const {
        const int64_t ms = running ? base_ms + (now - start_ms) : base_ms;
        return std::clamp<int64_t>(ms, 0, kMaxMs);
    }
    bool HasTime() const { return running || base_ms > 0 || lap_count > 0; }

    void Start(int64_t now) {
        if (running) return;
        start_ms = now;
        running = true;
    }
    void Pause(int64_t now) {
        if (!running) return;
        base_ms = Elapsed(now);
        running = false;
    }
    void Toggle(int64_t now) {
        if (running) Pause(now);
        else Start(now);
    }
    void Reset() {
        running = false;
        start_ms = 0;
        base_ms = 0;
        lap_count = 0;
        lap_mark_ms = 0;
        last_lap_ms = 0;
    }
    // 计次只在跑表时有效：停下之后再按 B 没有意义（圈速全是同一个值）。
    void Lap(int64_t now) {
        if (!running) return;
        const int64_t ms = Elapsed(now);
        last_lap_ms = ms - lap_mark_ms;
        lap_mark_ms = ms;
        ++lap_count;
    }

    // "MM:SS" 与百分秒分开返回：28px 字体只放得下 MM:SS，
    // 百分位放小字另起一行，读起来比三位挤在一起清楚。
    static void Format(int64_t ms, char* mmss, size_t mmss_size, int* hundredths) {
        const int total = static_cast<int>(std::clamp<int64_t>(ms, 0, kMaxMs) / 1000);
        std::snprintf(mmss, mmss_size, "%02d:%02d", total / 60, total % 60);
        if (hundredths) *hundredths = static_cast<int>((ms % 1000) / 10);
    }
};

}  // namespace desktop_stopwatch
