#pragma once

// Hardware facts for the AlphaPi OneS desktop board. Plain constants only:
// no executable code, nothing that pulls in a concrete board class.

#include <driver/gpio.h>
#include <driver/uart.h>

namespace board {

// ---- ST7789 128x160 panel, driven landscape as 160x128 ----
constexpr int kDisplaySck = 37;
constexpr int kDisplayMosi = 38;
constexpr int kDisplayMiso = 45;
constexpr int kDisplayCs = 34;
constexpr int kDisplayDc = 36;
constexpr int kDisplayReset = 35;
constexpr int kDisplayBacklight = 33;
constexpr int kDisplayWidth = 160;
constexpr int kDisplayHeight = 128;
constexpr int kDisplaySpiHz = 26 * 1000 * 1000;

// ---- Audio co-processor link (half duplex) ----
constexpr uart_port_t kAudioUart = UART_NUM_1;
constexpr int kAudioUartBaud = 460800;
constexpr gpio_num_t kAudioUartTx = GPIO_NUM_3;
// GPIO0 is also the BOOT strap; it must not be driven before Init().
constexpr gpio_num_t kAudioUartRx = GPIO_NUM_0;
constexpr uint32_t kAudioSampleRate = 24000;

// ---- Four keys, wired with pull-downs: high level means pressed ----
constexpr gpio_num_t kKeyA = GPIO_NUM_13;
constexpr gpio_num_t kKeyB = GPIO_NUM_12;
constexpr gpio_num_t kKeyC = GPIO_NUM_11;
constexpr gpio_num_t kKeyD = GPIO_NUM_10;
constexpr uint8_t kKeyMaskA = 0x04;  // bit2
constexpr uint8_t kKeyMaskB = 0x08;  // bit3
constexpr uint8_t kKeyMaskC = 0x02;  // bit1, left
constexpr uint8_t kKeyMaskD = 0x01;  // bit0, right

// The coprocessor swallows roughly 100-150 ms at the start of every playback
// session, so a freshly opened session gets this much lead-in silence before
// any real content.
constexpr int kStreamLeadInMs = 240;
// Shortest single clip that reliably becomes audible on this speaker.
constexpr int kMinSfxTotalMs = 340;

}  // namespace board
