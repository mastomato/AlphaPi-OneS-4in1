#pragma once
// v5c — 全页面 LVGL 界面
//
// 视觉与本地 v16 固件一致：普惠体 14px 中文、21 个真实 64x64 动态表情、
// 圆角卡片 / 进度条 / 图标均走 LVGL 控件，不再逐像素自绘。
// 字体与表情都从 assets 分区 mmap 读取，不占 app 空间。

#include <lvgl.h>
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <memory>
#include <mutex>
#include <string>

#include "assets.h"
#include "desktop_assets.h"
#include "desktop_game.h"
#include "desktop_runtime.h"
#include "esp_heap_caps.h"
#include "esp_system.h"
#include "esp_wifi.h"
#include "esp_wifi.h"
#include "gif/lvgl_gif.h"
#include "lvgl_font.h"
#include "lvgl_image.h"

namespace dui {

enum : uint32_t {
    kBg = 0x0E1420,
    kCard = 0x16233A,
    kCardHi = 0x1E2C46,
    kLine = 0x27395A,
    kInk = 0xF2F5FF,
    kMuted = 0x7186A0,
    kAccent = 0x8FE3F0,
    kWarm = 0xFFD27A,
    // 节拍器未点亮时的"重拍"点：暗暖黄，静止画面里也能一眼看出小节头
    kDotRest = 0x4A3F2E,
};

// Icons ship as 32x32 RGB565 bitmaps and are now drawn 1:1.
//
// v56: they used to be upscaled to 36px with nearest neighbour. 36/32 = 1.125
// is not an integer ratio, so the scaler duplicated a different number of
// source pixels on each edge and every curve came out with a ragged, dirty
// rim. Drawing at the native 32px keeps the pixels exactly as authored, and
// the four columns then fit the 160px panel with real gaps: 4 + 32 + 8 + 32 +
// 8 + 32 + 8 + 32 + 4 = 160. Icons also stay out of PSRAM (no ScaleIcon
// buffer), which removes a malloc that could fail at boot.
constexpr int kIconSrcSize = 32;
constexpr int kIconSize = 32;
// 90 + 32 = 122, same bottom line as before (the old 36px row started at 86).
constexpr int kIconY = 90;
// Evenly distributed: 8px gutters, 4px outer margins, symmetric.
constexpr int kIconX[4] = {4, 44, 84, 124};
// Home icon order. desk_icons[] still ships as [game, smile/voice, radio,
// timer]; only the placement order changes, so the voice icon sits on the A
// key (first column) and the game icon on B.
constexpr int kHomeOrder[4] = {1, 0, 2, 3};
// Column -> page number: the single source of truth for the home
// double-click jump and for the home selection ring.
//   col0 小智 = page2, col1 游戏 = page1, col2 收音机 = page3, col3 计时 = page4
constexpr int kHomePageOfColumn[4] = {2, 1, 3, 4};
inline int HomeColumnOfPage(int page) {
    for (int i = 0; i < 4; ++i) {
        if (kHomePageOfColumn[i] == page) return i;
    }
    return 0;
}

inline lv_color_t C(uint32_t v) { return lv_color_hex(v); }
// lv_canvas 的 RGB565 缓冲是每像素 2 字节紧密排列，lv_color_t 恒为 3 字节，
// 不能直接当缓冲写（v26 花屏根因）。所有 canvas 像素一律先转 packed 565。
inline uint16_t To565(lv_color_t c) {
    return static_cast<uint16_t>(((c.red & 0xF8) << 8) | ((c.green & 0xFC) << 3) | (c.blue >> 3));
}

// Nearest neighbour upscale, dest in PSRAM. Never freed on purpose: four icons
// are a one time ~10 KB and live as long as the UI.
inline const uint8_t* ScaleIcon(const uint16_t* src, int size) {
    auto* dst = static_cast<uint16_t*>(
        heap_caps_malloc(size * size * sizeof(uint16_t), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
    if (!dst) return nullptr;
    for (int y = 0; y < size; y++) {
        const int sy = y * kIconSrcSize / size;
        for (int x = 0; x < size; x++) {
            const int sx = x * kIconSrcSize / size;
            dst[y * size + x] = src[sy * kIconSrcSize + sx];
        }
    }
    return reinterpret_cast<const uint8_t*>(dst);
}

inline lv_obj_t* Box(lv_obj_t* parent, int x, int y, int w, int h, uint32_t color, int radius) {
    lv_obj_t* o = lv_obj_create(parent);
    lv_obj_remove_style_all(o);
    lv_obj_set_pos(o, x, y);
    lv_obj_set_size(o, w, h);
    lv_obj_set_style_bg_color(o, C(color), 0);
    lv_obj_set_style_bg_opa(o, LV_OPA_COVER, 0);
    lv_obj_set_style_radius(o, radius, 0);
    lv_obj_clear_flag(o, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_clear_flag(o, LV_OBJ_FLAG_CLICKABLE);
    return o;
}

inline lv_obj_t* Label(lv_obj_t* parent, const lv_font_t* font, uint32_t color, int x, int y, int w,
                       const char* text, int align = LV_TEXT_ALIGN_LEFT) {
    lv_obj_t* l = lv_label_create(parent);
    lv_obj_set_pos(l, x, y);
    if (w > 0) lv_obj_set_width(l, w);
    lv_obj_set_style_text_font(l, font, 0);
    lv_obj_set_style_text_color(l, C(color), 0);
    lv_obj_set_style_text_align(l, static_cast<lv_text_align_t>(align), 0);
    lv_obj_set_style_text_letter_space(l, 0, 0);
    lv_obj_clear_flag(l, LV_OBJ_FLAG_SCROLLABLE);
    lv_label_set_long_mode(l, LV_LABEL_LONG_MODE_WRAP);
    lv_label_set_text(l, text);
    return l;
}

struct PlayerUi {
    lv_obj_t* root = nullptr;
    lv_obj_t* index = nullptr;
    lv_obj_t* name = nullptr;
    lv_obj_t* state = nullptr;
    lv_obj_t* bars[12] = {};
    uint32_t accent = kAccent;
};

// 复刻本地独立版收音机的 M2b「日期色版」深色界面。
// 色值来自设计稿「三、色值对照」表，与桌面主题同源：
//   kBg=0x0E1420 / kAccent=0x8FE3F0 / kWarm=0xFFD27A / kMuted=0x7186A0
// 布局坐标沿用独立版 ui_home.cc（160×128 实机布局），只换配色与按键框。
enum : uint32_t {
    rBg    = 0x0E1420,  // 背景 / 按键字
    rInk   = 0x93AAC6,  // 主文字 / 时钟 / 计数 / 整屏 2px 外框
    rDate  = 0x7186A0,  // 首页日期色：电台名 + 按键框
    rFocus = 0xFFD27A,  // LIVE / 收音机图标 / NET RADIO
    rCyan  = 0x8FE3F0,  // 频谱亮条 / 列表选中行 / STOP / 断网
    rBrown = 0x5C4834,  // 5 条 1px 分隔线 / 频谱低条 / 音量暗格
};
// v30：按用户建议把音柱从 23 根缩到 12 根，进一步降低每帧像素写与
// invalidate 面积。柱距 7px、柱宽 5px，总宽 84px，视觉仍是完整一排频谱。
constexpr int kRadioBars = 12;
constexpr int kRadioBarMax = 16;
constexpr int kMeterW = 84;
constexpr int kMeterPitch = 7;
constexpr int kRadioGain[kRadioBars] = {5, 11, 16, 12, 7, 15, 10, 6, 13, 9, 16, 6};

struct RadioUi {
    lv_obj_t* root = nullptr;
    lv_obj_t* frame = nullptr;
    lv_obj_t* wifi = nullptr;
    lv_obj_t* wifi_slash = nullptr;
    lv_obj_t* live = nullptr;
    lv_obj_t* live_text = nullptr;
    lv_obj_t* counter = nullptr;
    lv_obj_t* clock = nullptr;
    lv_obj_t* title = nullptr;
    lv_obj_t* subtitle = nullptr;
    lv_obj_t* brand = nullptr;
    lv_obj_t* meter = nullptr;
    uint16_t* meter_buf = nullptr;  // 92x16 RGB565，波形直接写像素
    lv_obj_t* vol_icon = nullptr;
    lv_obj_t* vol_ticks[5] = {};
    lv_obj_t* keys[4] = {};
    lv_obj_t* key_text[4] = {};
    int bar_h[kRadioBars] = {};
    // 电台列表是 root 的常驻子层，打开时提到最前；切页时随 root 一起隐藏。
    lv_obj_t* list = nullptr;
    lv_obj_t* list_count = nullptr;
    lv_obj_t* list_rows[4] = {};
    lv_obj_t* list_labels[4] = {};
    bool list_open = false;
    int list_selected = 0;
};

// 独立版用 lv_line 画的天线/电波。点数组必须是静态存储，LVGL 只保存指针。
inline lv_obj_t* RadioLine(lv_obj_t* parent, int x, int y,
                           const lv_point_precise_t* pts, int count,
                           uint32_t color, int width) {
    lv_obj_t* l = lv_line_create(parent);
    lv_obj_remove_style_all(l);
    lv_line_set_points(l, pts, count);
    lv_obj_set_pos(l, x, y);
    lv_obj_set_style_line_color(l, C(color), 0);
    lv_obj_set_style_line_width(l, width, 0);
    lv_obj_set_style_line_rounded(l, true, 0);
    return l;
}

class Ui {
public:
    bool Build(DesktopRuntime* rt) {
        rt_ = rt;
        lv_obj_t* scr = lv_screen_active();
        lv_obj_set_style_bg_color(scr, C(kBg), 0);
        lv_obj_set_style_bg_opa(scr, LV_OPA_COVER, 0);
        lv_obj_set_style_pad_all(scr, 0, 0);
        lv_obj_set_style_border_width(scr, 0, 0);
        lv_obj_clear_flag(scr, LV_OBJ_FLAG_SCROLLABLE);

        auto& assets = Assets::GetInstance();
        void* fp = nullptr;
        size_t fs = 0;
        if (assets.GetAssetData("font_puhui_deepseek_14_1.bin", fp, fs)) {
            font_ = std::make_unique<LvglCBinFont>(fp);
            if (font_->font()) {
                zh_ = font_->font();
                font_->SetFallback(&lv_font_montserrat_14);
            }
        }
        if (zh_ == nullptr) zh_ = LV_FONT_DEFAULT;
        big_ = &lv_font_montserrat_28;
        mid_ = &lv_font_montserrat_20;
        for (int i = 0; i < 4; i++) {
            lv_image_dsc_t& d = icon_[i];
            std::memset(&d, 0, sizeof(d));
            d.header.magic = LV_IMAGE_HEADER_MAGIC;
            d.header.cf = LV_COLOR_FORMAT_RGB565;
            // Column i shows desk_icons[kHomeOrder[i]]: 小智, 游戏, 收音机, 计时器.
            const uint16_t* src = desk_icons[kHomeOrder[i]];
            // v56: kIconSize == kIconSrcSize now, so point straight at the flash
            // bitmap. The branch is constant-folded away; ScaleIcon only comes
            // back if someone changes kIconSize again.
            const uint8_t* scaled = (kIconSize == kIconSrcSize) ? nullptr : ScaleIcon(src, kIconSize);
            const int size = scaled ? kIconSize : kIconSrcSize;
            d.header.w = size;
            d.header.h = size;
            d.header.stride = size * 2;
            d.data_size = size * size * 2;
            d.data = scaled ? scaled : reinterpret_cast<const uint8_t*>(src);
        }

        BuildHome(scr);
        game_.Build(scr, zh_, rt_);
        BuildVoice(scr);
        BuildRadio(scr);
        BuildTimer(scr);
        // v47：计时页变成一个目录，四层都装在 timer_ 里，由 SyncTimerView 显隐。
        BuildTimerMenu(timer_);
        BuildMetro(timer_);
        BuildStopwatch(timer_);
        BuildConfig(scr);
        BuildVolume(scr);

        page_ = -1;
        SetPage(0);
        // 40 ms：独立版的波形刷新节奏，真实电平的快升慢降靠它；游戏页也靠它驱动。
        anim_ = lv_timer_create(&Ui::AnimCb, 40, this);
        ready_ = true;
        return true;
    }

    // 游戏页独立占用 4 键；board.cc 的 Key() 在 page==1 时调用它。
    void RouteGame(int idx, int gesture) { game_.Key(idx, gesture); }
    // 离开游戏页：清掉四局状态与画布像素，不给后台留半局
    void GameLeave() { game_.LeaveCleanup(); }

    // v28：波形改由 UiTask 主循环直接驱动。以前只挂在 LVGL 的 40ms timer 上，
    // timer 一旦被卡住，画面就整屏冻结（声音是独立解码任务，所以照常响）。
    // 主循环只要还在跑，波形就一定会更新。
    // 离开收音机页：波形数据归零、画布像素清成背景色，不留残留缓存
    void OnLeaveRadio() {
        RadioUi& p = radio_;
        for (int i = 0; i < kRadioBars; ++i) p.bar_h[i] = 2;
        if (p.meter_buf) {
            const uint16_t bg = To565(C(rBg));
            for (int i = 0; i < kMeterW * kRadioBarMax; ++i) p.meter_buf[i] = bg;
            lv_obj_invalidate(p.meter);
        }
    }

    void PumpRadioMeter(int64_t now_ms) {
        if (!ready_ || page_ != 3 || radio_.list_open) return;
        // v34：40ms -> 60ms。波形 16fps 已经看不出卡顿，但每帧都要重画
        // 84x16 画布并触发一次 DMA 提交，收一收能给按钮/时钟让出余量。
        if (now_ms - last_meter_ms_ < 60) return;
        last_meter_ms_ = now_ms;
        RadioMeter();
    }

    // 电台列表：由 board.cc 的长按 A 打开，列表内部键位也在那里分发。
    bool RadioListOpen() const { return radio_.list_open; }
    int RadioListSelection() const { return radio_.list_selected; }

    void RadioListToggle(bool open) {
        if (!ready_) return;
        radio_.list_open = open;
        if (open) {
            radio_.list_selected = std::clamp(
                rt_->radio.station_index(), 0,
                std::max(0, rt_->radio.station_count() - 1));
            RefreshRadioList();
            lv_obj_remove_flag(radio_.list, LV_OBJ_FLAG_HIDDEN);
            lv_obj_move_foreground(radio_.list);
        } else {
            lv_obj_add_flag(radio_.list, LV_OBJ_FLAG_HIDDEN);
        }
        page_dirty_ = true;
    }

    void RadioListMove(int delta) {
        const int count = std::max(1, rt_->radio.station_count());
        radio_.list_selected = (radio_.list_selected + delta + count) % count;
        RefreshRadioList();
    }

    void RefreshRadioList() {
        RadioUi& p = radio_;
        const int count = std::max(1, rt_->radio.station_count());
        p.list_selected = std::clamp(p.list_selected, 0, count - 1);
        char buf[48];
        std::snprintf(buf, sizeof(buf), "%02d/%02d", p.list_selected + 1, count);
        Set(p.list_count, buf);
        const int first = (p.list_selected / 4) * 4;
        for (int i = 0; i < 4; ++i) {
            const int index = first + i;
            const bool visible = index < count;
            lv_obj_set_flag(p.list_rows[i], LV_OBJ_FLAG_HIDDEN, !visible);
            if (!visible) continue;
            const bool sel = index == p.list_selected;
            lv_obj_set_style_bg_opa(p.list_rows[i],
                                    sel ? LV_OPA_COVER : LV_OPA_TRANSP, 0);
            lv_obj_set_style_bg_color(p.list_rows[i], C(sel ? rCyan : rBg), 0);
            lv_obj_set_style_text_color(p.list_labels[i], C(sel ? rBg : rInk), 0);
            std::snprintf(buf, sizeof(buf), "%d  %s", index + 1,
                          rt_->radio.station_name_at(index));
            Set(p.list_labels[i], buf);
        }
    }

    void Refresh(int page, int64_t now) {
        if (!ready_) return;
        if (page != page_) SetPage(page);
        switch (page_) {
            case 0: RefreshHome(now); break;
            case 1: break;  // 游戏页由 Animate() 的 40ms 定时器持续刷新画布
            case 2: RefreshVoice(now); break;
            case 3: RefreshRadio(now); break;
            case 4:
                // v47：计时页 = 目录 + 三个子视图（定时器 / 节拍器 / 计时器），
                // 同一页切换、共用键位表的不同行，不占新的主页入口。
                SyncTimerView(rt_->timer_view);
                switch (rt_->timer_view) {
                    case 1: RefreshTimer(now); break;
                    case 2: RefreshMetro(now); break;
                    case 3: RefreshStopwatch(now); break;
                    default: RefreshTimerMenu(now); break;
                }
                break;
            case 5: RefreshConfig(now); break;
            default: break;
        }
        bool vol = now < rt_->volume_overlay_until;
        if (vol != vol_shown_) {
            vol_shown_ = vol;
            if (vol) {
                lv_obj_remove_flag(vol_, LV_OBJ_FLAG_HIDDEN);
                lv_obj_move_foreground(vol_);
            } else {
                lv_obj_add_flag(vol_, LV_OBJ_FLAG_HIDDEN);
            }
        }
        if (vol) {
            char buf[24];
            int v = rt_->codec.audio.volume();
            std::snprintf(buf, sizeof(buf), "音量 %d%%", v);
            lv_label_set_text(vol_label_, buf);
            lv_obj_set_width(vol_bar_, std::max(1, 84 * v / 100));
        }
    }

private:
    // ---------------- build ----------------
    void BuildHome(lv_obj_t* scr) {
        home_ = Box(scr, 0, 0, 160, 128, kBg, 0);
        clock_ = Label(home_, big_, kInk, 6, 0, 108, "--:--");
        for (int i = 0; i < 4; i++) {
            sig_[i] = Box(home_, 138 + i * 4, 13 - (i + 1) * 3, 3, (i + 1) * 3, kLine, 1);
        }
        date_ = Label(home_, zh_, kMuted, 6, 33, 118, "");
        place_ = Label(home_, zh_, kMuted, 6, 51, 148, "");
        lv_label_set_long_mode(place_, LV_LABEL_LONG_MODE_DOTS);
        status_ = Label(home_, zh_, kAccent, 6, 67, 148, "");
        lv_label_set_long_mode(status_, LV_LABEL_LONG_MODE_DOTS);

        // No selection frame: four icons, four keys, press and go. The outline
        // read as a stray rectangle on a 160px panel.
        for (int i = 0; i < 4; i++) {
            lv_obj_t* img = lv_image_create(home_);
            lv_obj_set_pos(img, kIconX[i], kIconY);
            lv_image_set_src(img, &icon_[i]);
        }
    }

    void BuildPlayer(lv_obj_t* scr, PlayerUi& p, const char* title, uint32_t accent) {
        p.accent = accent;
        p.root = Box(scr, 0, 0, 160, 128, kBg, 0);
        Label(p.root, zh_, accent, 7, 2, 90, title);
        p.index = Label(p.root, zh_, kMuted, 93, 2, 60, "--/--", LV_TEXT_ALIGN_RIGHT);
        Box(p.root, 7, 22, 146, 1, kLine, 0);
        p.name = Label(p.root, zh_, kInk, 7, 27, 146, "");
        lv_label_set_long_mode(p.name, LV_LABEL_LONG_MODE_DOTS);
        p.state = Label(p.root, zh_, kWarm, 7, 50, 146, "");
        // Colour is fixed per bar at build time; the animation only moves and
        // resizes them. Restyling every frame churned the style lists and the
        // 48 KB LVGL pool for no visual difference.
        for (int i = 0; i < 12; i++) {
            p.bars[i] = Box(p.root, 7 + i * 12, 116, 7, 4, (i % 3 == 0) ? kWarm : accent, 3);
        }
    }

    // 23 根音量柱，沿用独立版的 LV_EVENT_DRAW_MAIN 自绘：不建 23 个对象，
    // 不每帧改样式，48 KB 的 LVGL 内存池完全不受影响。
    // 独立版 MakeRadio 的天线 / 电波 / 机身，颜色换成 M2b 的暖黄。
    void RadioIcon(lv_obj_t* parent) {
        lv_obj_t* g = Box(parent, 8, 28, 36, 30, rBg, 0);
        static const lv_point_precise_t antenna[] = {{4, 11}, {23, 1}};
        static const lv_point_precise_t ray1[] = {{0, 3}, {4, 0}};
        static const lv_point_precise_t ray2[] = {{0, 0}, {5, 0}};
        RadioLine(g, 0, 0, antenna, 2, rFocus, 2);
        RadioLine(g, 31, 8, ray1, 2, rFocus, 1);
        RadioLine(g, 31, 14, ray2, 2, rFocus, 1);
        Box(g, 0, 11, 30, 18, rFocus, 3);
        for (int row = 0; row < 4; ++row) Box(g, 3, 15 + row * 3, 11, 1, rBg, 0);
        Box(g, 17, 14, 10, 10, rBg, LV_RADIUS_CIRCLE);
        Box(g, 19, 16, 6, 6, rFocus, LV_RADIUS_CIRCLE);
        Box(g, 21, 18, 2, 2, rBg, LV_RADIUS_CIRCLE);
    }

    // 底部按键框：v28 把 2px 粗边改成 1px 细边、框高 18→16，文字一律用单字
    //（「暂停→停」「上台→上」），14px 中文字在 35px 框里不再顶格甚至溢出。
    lv_obj_t* RadioKey(lv_obj_t* parent, int x, const char* text) {
        lv_obj_t* k = Box(parent, x, 104, 35, 16, rBg, 2);
        lv_obj_set_style_border_width(k, 1, 0);
        lv_obj_set_style_border_color(k, C(rBrown), 0);
        lv_obj_set_style_border_opa(k, LV_OPA_COVER, 0);
        lv_obj_t* t = Label(k, zh_, rInk, 0, 0, 35, text, LV_TEXT_ALIGN_CENTER);
        lv_label_set_long_mode(t, LV_LABEL_LONG_MODE_CLIP);
        return t;
    }

    // M2b 深色播放页，坐标沿用独立版 ui_home.cc 的 160×128 实机布局。
    void BuildRadio(lv_obj_t* scr) {
        RadioUi& p = radio_;
        p.root = Box(scr, 0, 0, 160, 128, rBg, 8);
        p.frame = Box(p.root, 1, 1, 158, 126, rBg, 8);
        lv_obj_set_style_border_width(p.frame, 2, 0);
        lv_obj_set_style_border_color(p.frame, C(rInk), 0);
        lv_obj_set_style_border_opa(p.frame, LV_OPA_COVER, 0);
        for (int y : {23, 60, 78, 99}) Box(p.root, 7, y, 146, 1, rBrown, 0);

        p.wifi = Label(p.root, zh_, rInk, 8, 5, 18, LV_SYMBOL_WIFI);
        static const lv_point_precise_t slash[] = {{0, 0}, {13, 11}};
        p.wifi_slash = RadioLine(p.root, 9, 7, slash, 2, rFocus, 1);
        // v28 顶部一行重新排宽：原来 counter 只有 34px，装不下 14px 字体的
        // "01/54"（约 43px），WRAP 模式直接换行压到分隔线上；STOP 同理撑破
        // 34px 的 LIVE 框。现在全部加宽并改成 CLIP + 负字距，绝不越框。
        p.live = Box(p.root, 26, 5, 38, 14, rFocus, 2);
        p.live_text = Label(p.live, zh_, rBg, 0, 1, 38, "LIVE", LV_TEXT_ALIGN_CENTER);
        lv_label_set_long_mode(p.live_text, LV_LABEL_LONG_MODE_CLIP);
        lv_obj_set_style_text_letter_space(p.live_text, -1, 0);
        Box(p.root, 66, 7, 1, 12, rInk, 0);
        p.counter = Label(p.root, zh_, rInk, 69, 5, 44, "01/22");
        lv_label_set_long_mode(p.counter, LV_LABEL_LONG_MODE_CLIP);
        lv_obj_set_style_text_letter_space(p.counter, -1, 0);
        Box(p.root, 115, 7, 1, 12, rInk, 0);
        p.clock = Label(p.root, zh_, rInk, 118, 5, 38, "--:--", LV_TEXT_ALIGN_RIGHT);
        lv_label_set_long_mode(p.clock, LV_LABEL_LONG_MODE_CLIP);
        lv_obj_set_style_text_letter_space(p.clock, -1, 0);

        RadioIcon(p.root);
        // 电台名称：v28 去掉 SCROLL_CIRCULAR —— 循环滚动标签每帧都在 invalidate
        // 整块区域，叠加 23 根波形柱的逐帧重绘，播放久了会把 UI 任务拖死
        //（现象就是「波纹不跳了但声音还在」）。改用静态省略号，长台名也不越框。
        p.title = Label(p.root, zh_, rDate, 47, 32, 106, "");
        lv_label_set_long_mode(p.title, LV_LABEL_LONG_MODE_DOTS);
        p.subtitle = Label(p.root, zh_, rInk, 8, 63, 46, "");
        lv_label_set_long_mode(p.subtitle, LV_LABEL_LONG_MODE_DOTS);
        // v35：右侧恢复成装饰文案 "RADIO"。上一版在这里显示电台域名，但
        // 域名长度不一，小屏上挤得难看不说，还和状态行抢位置。地址放到
        // 网页里看（那里有完整 URL 和电台列表）。
        p.brand = Label(p.root, zh_, rFocus, 110, 63, 46, "RADIO", LV_TEXT_ALIGN_RIGHT);
        lv_label_set_long_mode(p.brand, LV_LABEL_LONG_MODE_CLIP);

        // v29：波形改 lv_canvas 直接写像素。以前用 LV_EVENT_DRAW_MAIN 里的
        // 23 次 lv_draw_rect，每帧要向 LVGL 申请 23 个 draw unit（PSRAM 堆），
        // 40ms 一次 = 575 次/秒，连续播放十几分钟后堆碎片 / draw queue 积压，
        // 整屏就冻住而音频解码任务照常跑。canvas 每帧只有 1 个 image draw unit。
        constexpr int kMeterH = kRadioBarMax;   // kMeterW 见文件顶部
        static uint16_t* mbuf = static_cast<uint16_t*>(
            heap_caps_malloc(kMeterW * kMeterH * sizeof(uint16_t),
                             MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
        if (!mbuf) mbuf = static_cast<uint16_t*>(
            heap_caps_malloc(kMeterW * kMeterH * sizeof(uint16_t), MALLOC_CAP_DEFAULT));
        p.meter_buf = mbuf;
        if (p.meter_buf) {
            p.meter = lv_canvas_create(p.root);
            lv_obj_set_pos(p.meter, 8, 81);
            lv_canvas_set_buffer(p.meter, p.meter_buf, kMeterW, kMeterH,
                                 LV_COLOR_FORMAT_RGB565);
            const uint16_t bg = To565(C(rBg));
            for (int i = 0; i < kMeterW * kMeterH; ++i) p.meter_buf[i] = bg;
        } else {
            p.meter = Box(p.root, 8, 81, kMeterW, kMeterH, rBg, 0);
        }
        for (int i = 0; i < kRadioBars; ++i) p.bar_h[i] = 2;

        Box(p.root, 103, 84, 1, 12, rBrown, 0);
        p.vol_icon = Label(p.root, zh_, rInk, 107, 84, 14, LV_SYMBOL_VOLUME_MAX);
        for (int i = 0; i < 5; ++i)
            p.vol_ticks[i] = Box(p.root, 123 + i * 6, 94 - i * 2, 4, 3 + i * 2, rBrown, 0);

        p.key_text[0] = RadioKey(p.root, 7, "停");
        p.key_text[1] = RadioKey(p.root, 44, "上");
        p.key_text[2] = RadioKey(p.root, 81, "下");
        p.key_text[3] = RadioKey(p.root, 118, "静");

        // 电台列表页（独立版 CreateList 的深色版）。建在 root 内、默认隐藏，
        // 打开时提到最前覆盖播放页；切页时随 root 一起被 SetPage 隐藏。
        p.list = Box(p.root, 0, 0, 160, 128, rBg, 8);
        lv_obj_set_style_border_width(p.list, 2, 0);
        lv_obj_set_style_border_color(p.list, C(rInk), 0);
        lv_obj_set_style_border_opa(p.list, LV_OPA_COVER, 0);
        Label(p.list, zh_, rInk, 8, 5, 80, "电台列表");
        p.list_count = Label(p.list, zh_, rFocus, 100, 5, 52, "01/22",
                             LV_TEXT_ALIGN_RIGHT);
        lv_label_set_long_mode(p.list_count, LV_LABEL_LONG_MODE_CLIP);
        lv_obj_set_style_text_letter_space(p.list_count, -1, 0);
        Box(p.list, 7, 23, 146, 1, rBrown, 0);
        for (int i = 0; i < 4; ++i) {
            p.list_rows[i] = Box(p.list, 7, 27 + i * 18, 146, 17, rBg, 2);
            lv_obj_set_style_bg_opa(p.list_rows[i], LV_OPA_TRANSP, 0);
            p.list_labels[i] = Label(p.list_rows[i], zh_, rInk, 4, 1, 138, "");
            lv_label_set_long_mode(p.list_labels[i], LV_LABEL_LONG_MODE_DOTS);
        }
        RadioKey(p.list, 7, "放");
        RadioKey(p.list, 44, "上");
        RadioKey(p.list, 81, "下");
        RadioKey(p.list, 118, "返");
        lv_obj_add_flag(p.list, LV_OBJ_FLAG_HIDDEN);
    }

    void BuildVoice(lv_obj_t* scr) {
        voice_ = Box(scr, 0, 0, 160, 128, kBg, 0);
        Box(voice_, 0, 0, 160, 22, kCard, 0);
        vstatus_ = Label(voice_, zh_, kInk, 7, 2, 100, "");
        lv_label_set_long_mode(vstatus_, LV_LABEL_LONG_MODE_DOTS);
        vclock_ = Label(voice_, zh_, kWarm, 108, 2, 46, "", LV_TEXT_ALIGN_RIGHT);

        vimg_ = lv_image_create(voice_);
        lv_obj_set_pos(vimg_, 48, 26);
        lv_obj_add_flag(vimg_, LV_OBJ_FLAG_HIDDEN);

        vtitle_ = Label(voice_, zh_, kAccent, 0, 30, 160, "设备验证码", LV_TEXT_ALIGN_CENTER);
        vcode_ = Label(voice_, big_, kInk, 0, 52, 160, "", LV_TEXT_ALIGN_CENTER);
        vchat_ = Label(voice_, zh_, kInk, 7, 94, 146, "");
        lv_label_set_long_mode(vchat_, LV_LABEL_LONG_MODE_WRAP);
        lv_obj_add_flag(vtitle_, LV_OBJ_FLAG_HIDDEN);
        lv_obj_add_flag(vcode_, LV_OBJ_FLAG_HIDDEN);
    }

    // 方案 B：分 / 秒各一张卡片，正在编辑的那张整体点亮（亮底 + 青色描边）。
    // 数字保持 28px，远看也清楚；下面一条进度条表示剩余比例。
    // v47：这一层是「定时器」子视图，装在 count_ 里，由 SyncTimerView 显隐。
    void BuildTimer(lv_obj_t* scr) {
        timer_ = Box(scr, 0, 0, 160, 128, kBg, 0);
        count_ = Box(timer_, 0, 0, 160, 128, kBg, 0);
        Label(count_, zh_, kAccent, 8, 1, 70, "定时器");
        tstate_ = Label(count_, zh_, kMuted, 86, 1, 66, "设定", LV_TEXT_ALIGN_RIGHT);

        // No 分/秒 sub-labels: the two cards read as minutes and seconds on their
        // own, and dropping them frees the middle of the card for a bigger number.
        tcard_[0] = Box(count_, 15, 24, 60, 56, kCard, 10);
        tcard_[1] = Box(count_, 85, 24, 60, 56, kCard, 10);
        // montserrat_28 has no bold face, so the "bold" is a second copy of the
        // digits painted one pixel to the right. Same text, same metrics, so the
        // pair stays centred in the card.
        tmin_ = Label(count_, big_, kInk, 15, 35, 60, "05", LV_TEXT_ALIGN_CENTER);
        tmin2_ = Label(count_, big_, kInk, 16, 35, 60, "05", LV_TEXT_ALIGN_CENTER);
        tsec_ = Label(count_, big_, kInk, 85, 35, 60, "00", LV_TEXT_ALIGN_CENTER);
        tsec2_ = Label(count_, big_, kInk, 86, 35, 60, "00", LV_TEXT_ALIGN_CENTER);

        // 6 px read as a slab under the cards; 3 px with a 2 px radius keeps the
        // same 130 px track and reads as a hairline progress bar.
        Box(count_, 15, 93, 130, 3, kCard, 2);
        tbar_ = Box(count_, 15, 93, 0, 3, kAccent, 2);
        thint_ = Label(count_, zh_, kMuted, 0, 105, 160, "", LV_TEXT_ALIGN_CENTER);
    }

    // v47：计时目录。照游戏启动器那样摆卡片：2×2 网格，选中的那格加暖黄描边。
    // 三项（定时器 / 节拍器 / 计时器）+ 右下角一块说明，正好填满一屏。
    void BuildTimerMenu(lv_obj_t* parent) {
        static const char* kNames[3] = {"定时器", "节拍器", "计时器"};
        static const char* kDesc[3] = {"倒数", "BPM", "秒表"};
        menu_ = Box(parent, 0, 0, 160, 128, kBg, 0);
        lv_obj_add_flag(menu_, LV_OBJ_FLAG_HIDDEN);
        Label(menu_, zh_, kAccent, 8, 1, 70, "计时");
        Label(menu_, zh_, kMuted, 96, 1, 56, "3 项", LV_TEXT_ALIGN_RIGHT);
        Box(menu_, 7, 20, 146, 1, kLine, 0);

        const int cx[3] = {7, 83, 7};
        const int cy[3] = {26, 26, 64};
        for (int i = 0; i < 3; ++i) {
            mcard_[i] = Box(menu_, cx[i], cy[i], 70, 32, kCard, 5);
            mname_[i] = Label(menu_, zh_, kInk, cx[i] + 6, cy[i] + 3, 58, kNames[i]);
            mdesc_[i] = Label(menu_, zh_, kMuted, cx[i] + 6, cy[i] + 17, 58, kDesc[i]);
        }
        // 右下角不是空白卡片，而是操作说明：长按 D 回主页是这个页面唯一的
        // “逃生口”，放在手边比塞进底部一行小字更清楚。
        Box(menu_, 83, 64, 70, 32, kCard, 5);
        lv_obj_t* tip = Label(menu_, zh_, kMuted, 89, 68, 58, "长按D\n回主页");
        lv_label_set_long_mode(tip, LV_LABEL_LONG_MODE_WRAP);
        Label(menu_, zh_, kMuted, 0, 106, 160, "A 进入  B/C 选择  D 返回",
              LV_TEXT_ALIGN_CENTER);
    }

    // v47：计时器（秒表）。正计时，28px 的 MM:SS + 一行百分秒 + 一行计次。
    void BuildStopwatch(lv_obj_t* parent) {
        watch_ = Box(parent, 0, 0, 160, 128, kBg, 0);
        lv_obj_add_flag(watch_, LV_OBJ_FLAG_HIDDEN);
        Label(watch_, zh_, kAccent, 8, 1, 70, "计时器");
        wstate_ = Label(watch_, zh_, kMuted, 86, 1, 66, "归零", LV_TEXT_ALIGN_RIGHT);

        wtime_ = Label(watch_, big_, kInk, 0, 22, 160, "00:00", LV_TEXT_ALIGN_CENTER);
        // 假粗体：同一串数字向右错一像素再画一遍（montserrat_28 没有粗体字）。
        wtime2_ = Label(watch_, big_, kInk, 1, 22, 160, "00:00", LV_TEXT_ALIGN_CENTER);
        wcent_ = Label(watch_, zh_, kMuted, 0, 54, 160, ".00", LV_TEXT_ALIGN_CENTER);
        wlap_ = Label(watch_, zh_, kMuted, 0, 74, 160, "", LV_TEXT_ALIGN_CENTER);
        Box(watch_, 7, 94, 146, 1, kLine, 0);
        whint_ = Label(watch_, zh_, kMuted, 0, 104, 160, "A起停 B计次 C归零 D退",
                       LV_TEXT_ALIGN_CENTER);
    }

    // 节拍器（v39）。沿用倒计时页的"深色卡片 + 28px 数字"，节奏感交给上面
    // 一排拍点和下面一条拍内进度条：静止时也能看出当前是小节第几拍。
    void BuildMetro(lv_obj_t* parent) {
        // 整层盖在倒计时页之上（同为 160×128），切换只是显隐
        metro_ = Box(parent, 0, 0, 160, 128, kBg, 0);
        lv_obj_add_flag(metro_, LV_OBJ_FLAG_HIDDEN);
        Label(metro_, zh_, kWarm, 8, 1, 70, "节拍器");
        mstate_ = Label(metro_, zh_, kMuted, 96, 1, 56, "4/4");
        lv_label_set_long_mode(mstate_, LV_LABEL_LONG_MODE_CLIP);
        Box(metro_, 7, 20, 146, 1, kLine, 0);

        // 和计时页一样，粗体是同一串数字向右再画一遍，montserrat_28 没有粗体字。
        mbpm_ = Label(metro_, big_, kInk, 0, 26, 160, "120", LV_TEXT_ALIGN_CENTER);
        mbpm2_ = Label(metro_, big_, kInk, 1, 26, 160, "120", LV_TEXT_ALIGN_CENTER);
        Label(metro_, zh_, kMuted, 0, 58, 160, "BPM", LV_TEXT_ALIGN_CENTER);

        for (int i = 0; i < 6; ++i) {
            mdot_[i] = Box(metro_, 0, 80, 10, 10, i == 0 ? kDotRest : kLine,
                           LV_RADIUS_CIRCLE);
            lv_obj_add_flag(mdot_[i], LV_OBJ_FLAG_HIDDEN);
        }
        Box(metro_, 30, 98, 100, 3, kCard, 2);
        mbar_ = Box(metro_, 30, 98, 0, 3, kWarm, 2);
        mhint_ = Label(metro_, zh_, kMuted, 0, 110, 160, "A起停 B切换 C减 D增",
                       LV_TEXT_ALIGN_CENTER);
        lv_label_set_long_mode(mhint_, LV_LABEL_LONG_MODE_CLIP);
    }

    // 计时页内切视图：四层同尺寸叠在一起，隐藏/显示即可。
    // v47：0=目录 1=定时器 2=节拍器 3=计时器。
    void SyncTimerView(int view) {
        if (view == view_shown_) return;
        view_shown_ = view;
        lv_obj_t* layers[4] = {menu_, count_, metro_, watch_};
        for (int i = 0; i < 4; i++) {
            if (layers[i] == nullptr) continue;
            if (i == view) {
                lv_obj_remove_flag(layers[i], LV_OBJ_FLAG_HIDDEN);
                lv_obj_move_foreground(layers[i]);
            } else {
                lv_obj_add_flag(layers[i], LV_OBJ_FLAG_HIDDEN);
            }
        }
    }

    void BuildVolume(lv_obj_t* scr) {        vol_ = Box(scr, 28, 2, 104, 32, kCardHi, 9);
        lv_obj_set_style_border_width(vol_, 1, 0);
        lv_obj_set_style_border_color(vol_, C(kLine), 0);
        lv_obj_set_style_border_opa(vol_, LV_OPA_COVER, 0);
        vol_label_ = Label(vol_, zh_, kInk, 10, 2, 84, "音量 60%");
        Box(vol_, 10, 22, 84, 4, kLine, 2);
        vol_bar_ = Box(vol_, 10, 22, 84, 4, kWarm, 2);
        lv_obj_add_flag(vol_, LV_OBJ_FLAG_HIDDEN);
    }

    // 配网页：长按 A 打开热点后自动进入这一页。屏幕上直接给出热点名、网址、
    // 已连设备数和 HTTP 请求计数——这块板子的串口没接到 USB，出问题时只能靠
    // 屏幕自证："请求数在涨但页面打不开" 和 "请求数一直是 0" 是两回事。
    void BuildConfig(lv_obj_t* scr) {
        cfg_ = Box(scr, 0, 0, 160, 128, kBg, 0);
        Box(cfg_, 0, 0, 160, 20, kCard, 0);
        Label(cfg_, zh_, kAccent, 8, 1, 60, "配网");
        Label(cfg_, zh_, kMuted, 82, 1, 72, "长按D返回", LV_TEXT_ALIGN_RIGHT);

        Label(cfg_, zh_, kMuted, 14, 28, 50, "热点");
        tswitch_ = Box(cfg_, 100, 24, 46, 24, kLine, 12);
        tknob_ = Box(tswitch_, 4, 3, 18, 18, kMuted, 9);

        cstate_ = Label(cfg_, zh_, kMuted, 0, 52, 160, "热点已关闭 按A开启", LV_TEXT_ALIGN_CENTER);
        // 中文字体：这一行热点关着时要显示家庭 Wi-Fi 名（可能是中文），
        // montserrat_20 没有中文字形，会整行显示成空白。
        tssid_ = Label(cfg_, zh_, kMuted, 0, 70, 160, "AlphaPi-Desk", LV_TEXT_ALIGN_CENTER);
        lv_label_set_long_mode(tssid_, LV_LABEL_LONG_MODE_DOTS);
        tip_ = Label(cfg_, zh_, kMuted, 0, 96, 160, "192.168.4.1", LV_TEXT_ALIGN_CENTER);
        // Live counters: how many phones are associated and whether the DHCP
        // server is up. "won't connect" is either an association problem (0) or
        // an address problem (1 with D0), and the screen has to tell them apart.
        diag_ = Label(cfg_, zh_, kMuted, 0, 111, 160, "", LV_TEXT_ALIGN_CENTER);
    }

    void SetPage(int page) {
        page_ = std::clamp(page, 0, 5);
        lv_obj_t* all[6] = {home_, game_.root, voice_, radio_.root, timer_, cfg_};
        for (int i = 0; i < 6; i++) {
            if (all[i] == nullptr) continue;
            if (i == page_) {
                lv_obj_remove_flag(all[i], LV_OBJ_FLAG_HIDDEN);
            } else {
                lv_obj_add_flag(all[i], LV_OBJ_FLAG_HIDDEN);
            }
        }
        lv_obj_move_foreground(vol_);
        page_dirty_ = true;
    }

    // ---------------- refresh ----------------
    void RefreshHome(int64_t now) {
        time_t t = time(nullptr);
        tm local = {};
        localtime_r(&t, &local);
        bool valid = local.tm_year + 1900 >= 2024;
        char buf[64];
        if (valid) {
            std::snprintf(buf, sizeof(buf), "%02d:%02d", local.tm_hour, local.tm_min);
        } else {
            std::snprintf(buf, sizeof(buf), "--:--");
        }
        Set(clock_, buf);

        static const char* week[7] = {"日", "一", "二", "三", "四", "五", "六"};
        if (valid) {
            std::snprintf(buf, sizeof(buf), "%d月%d日 星期%s", local.tm_mon + 1, local.tm_mday,
                          week[local.tm_wday % 7]);
        } else {
            std::snprintf(buf, sizeof(buf), "等待网络校时");
        }
        Set(date_, buf);

        std::string place, condition;
        bool have = false;
        double deg = 0;
        {
            std::lock_guard<std::mutex> l(rt_->state_mutex);
            place = rt_->city;
            condition = rt_->description;
            have = rt_->have_weather;
            deg = rt_->temperature;
        }
        if (have) {
            std::snprintf(buf, sizeof(buf), "%s  %.0f°  %s", place.c_str(), deg, condition.c_str());
        } else if (!place.empty()) {
            std::snprintf(buf, sizeof(buf), "%s", place.c_str());
        } else {
            std::snprintf(buf, sizeof(buf), "未配置城市");
        }
        Set(place_, buf);

        wifi_ap_record_t ap = {};
        int sig = 0;
        // Touching the driver while the AP is being switched can block, and this
        // runs once a second inside the UI loop.
        if (!rt_->ap_busy.load() && esp_wifi_sta_get_ap_info(&ap) == ESP_OK) {
            sig = ap.rssi >= -55 ? 4 : ap.rssi >= -67 ? 3 : ap.rssi >= -78 ? 2 : 1;
        }
        for (int i = 0; i < 4; i++) {
            lv_obj_set_style_bg_color(sig_[i], C(i < sig ? kAccent : kLine), 0);
        }

        std::string st;
        // The reset reason gets 12 seconds of air time on the home screen: this
        // board's console is not wired to the USB port, so "it rebooted" has to
        // come back to us as crash / watchdog / brownout from the panel itself.
        if (boot_ms_ == 0) boot_ms_ = now;
        const char* note = ResetNotice(rt_->boot_reset);
        const bool show_note = note && *note && now - boot_ms_ < 12000;
        if (show_note) {
            st = note;
        } else if (rt_->countdown.finished) {
            st = "计时结束";
        } else if (rt_->countdown.running) {
            int left = rt_->countdown.Remaining(now) / 1000;
            std::snprintf(buf, sizeof(buf), "计时 %02d:%02d", left / 60, left % 60);
            st = buf;
        } else if (rt_->ap_busy.load()) {
            st = "正在开启热点";
        } else if (rt_->ap_enabled.load()) {
            st = "配网热点已开启";
        } else if (rt_->ap_advise.load()) {
            st = "长按 A 配网";
        }
        Set(status_, st);
        if (st.empty()) {
            lv_obj_add_flag(status_, LV_OBJ_FLAG_HIDDEN);
        } else {
            lv_obj_remove_flag(status_, LV_OBJ_FLAG_HIDDEN);
            lv_obj_set_style_text_color(
                status_,
                C((show_note || rt_->countdown.finished || rt_->ap_enabled.load()) ? kWarm : kAccent),
                0);
        }
    }

    static const char* ResetNotice(int reason) {
        switch (reason) {
            case ESP_RST_PANIC: return "上次程序崩溃重启";
            case ESP_RST_BROWNOUT: return "上次供电不足重启";
            case ESP_RST_INT_WDT:
            case ESP_RST_TASK_WDT:
            case ESP_RST_WDT: return "上次看门狗重启";
            default: return "";
        }
    }

    void RefreshPlayer(PlayerUi& p, bool music) {
        char buf[32];
        std::snprintf(buf, sizeof(buf), "%02d/%02d", rt_->radio.station_index() + 1,
                      std::max(1, rt_->radio.station_count()));
        Set(p.index, buf);
        Set(p.name, rt_->radio.station_name() ? rt_->radio.station_name() : "未选择");
        const char* st = "等待播放";
        switch (rt_->radio.state()) {
            case radio::PlayerState::kConnecting: st = "正在连接"; break;
            case radio::PlayerState::kBuffering: st = "正在缓冲"; break;
            case radio::PlayerState::kPlaying: st = "正在播放"; break;
            case radio::PlayerState::kPaused: st = "已暂停"; break;
            case radio::PlayerState::kReconnecting: st = "正在重连"; break;
            case radio::PlayerState::kError: st = music ? "暂不可用" : "电台暂不可用"; break;
            default: break;
        }
        Set(p.state, st);
    }

    void RefreshRadio(int64_t now) {
        (void)now;
        RadioUi& p = radio_;
        auto& r = rt_->radio;
        char buf[40];
        std::snprintf(buf, sizeof(buf), "%02d/%02d", r.station_index() + 1,
                      std::max(1, r.station_count()));
        Set(p.counter, buf);
        Set(p.title, r.station_name() ? r.station_name() : "未选择");

        time_t t = time(nullptr);
        tm local = {};
        localtime_r(&t, &local);
        if (local.tm_year + 1900 >= 2024)
            std::snprintf(buf, sizeof(buf), "%02d:%02d", local.tm_hour, local.tm_min);
        else
            std::snprintf(buf, sizeof(buf), "--:--");
        Set(p.clock, buf);

        const auto state = r.state();
        const bool playing = state == radio::PlayerState::kPlaying && !r.paused();
        const bool buffering = state == radio::PlayerState::kConnecting ||
                               state == radio::PlayerState::kBuffering ||
                               state == radio::PlayerState::kReconnecting;
        const bool live = playing && !buffering;
        // LIVE 暖黄、WAIT 日期色、STOP 青色（设计稿：STOP/断网 = #8FE3F0）。
        lv_obj_set_style_bg_color(p.live,
            C(live ? rFocus : (playing ? rDate : rCyan)), 0);
        Set(p.live_text, !playing ? "STOP" : (buffering ? "WAIT" : "LIVE"));

        const char* sub = "收音机";
        switch (state) {
            case radio::PlayerState::kPlaying: sub = "播放中"; break;
            case radio::PlayerState::kConnecting: sub = "连接中"; break;
            case radio::PlayerState::kBuffering: sub = "缓冲中"; break;
            case radio::PlayerState::kReconnecting: sub = "重连中"; break;
            case radio::PlayerState::kPaused: sub = "已暂停"; break;
            case radio::PlayerState::kError: sub = "不可用"; break;
            default: break;
        }
        Set(p.subtitle, sub);

        const bool net_ok = playing || buffering;
        lv_obj_set_style_text_color(p.wifi, C(net_ok ? rInk : rDate), 0);
        lv_obj_set_flag(p.wifi_slash, LV_OBJ_FLAG_HIDDEN, net_ok);

        const int vol = r.volume();
        for (int i = 0; i < 5; ++i)
            lv_obj_set_style_bg_color(p.vol_ticks[i], C(vol > i * 20 ? rCyan : rBrown), 0);
        Set(p.vol_icon, vol == 0 ? LV_SYMBOL_MUTE :
                        (vol <= 50 ? LV_SYMBOL_VOLUME_MID : LV_SYMBOL_VOLUME_MAX));
        Set(p.key_text[0], playing ? "停" : "放");
        Set(p.key_text[3], r.volume() == 0 ? "响" : "静");
        // v34：删掉了这里的整页 invalidate。文本/样式改动本身就会触发重绘，
        // 再叠一次整页脏标记等于每 2 秒白做一次全屏重绘，和 40ms 一帧的波形
        // 抢同一个 UI 任务，长时播放时最容易把刷新链路压垮。
    }

    void RefreshVoice(int64_t now) {
        std::string status, chat, activation, emotion;
        {
            std::lock_guard<std::recursive_mutex> l(rt_->display.mutex);
            status = rt_->display.status;
            chat = rt_->display.chat;
            activation = rt_->display.activation;
            emotion = rt_->display.emotion;
        }
        if (chat != last_chat_) {
            last_chat_ = chat;
            Set(vchat_, chat);
        }
        if (status != last_status_) {
            last_status_ = status;
            Set(vstatus_, status.empty() ? "小智" : status);
        }
        char buf[16];
        time_t t = time(nullptr);
        tm local = {};
        localtime_r(&t, &local);
        if (local.tm_year + 1900 >= 2024) {
            std::snprintf(buf, sizeof(buf), "%02d:%02d", local.tm_hour, local.tm_min);
        } else {
            std::snprintf(buf, sizeof(buf), "--:--");
        }
        Set(vclock_, buf);

        if (!activation.empty()) {
            SyncEmotion("");
            lv_obj_add_flag(vimg_, LV_OBJ_FLAG_HIDDEN);
            lv_obj_remove_flag(vtitle_, LV_OBJ_FLAG_HIDDEN);
            lv_obj_remove_flag(vcode_, LV_OBJ_FLAG_HIDDEN);
            std::string spaced;
            for (char c : activation) {
                if (!spaced.empty()) spaced.push_back(' ');
                spaced.push_back(c);
            }
            Set(vcode_, spaced);
            if (last_chat_.empty()) Set(vchat_, "请在小智网页绑定设备");
        } else {
            lv_obj_add_flag(vtitle_, LV_OBJ_FLAG_HIDDEN);
            lv_obj_add_flag(vcode_, LV_OBJ_FLAG_HIDDEN);
            SyncEmotion(emotion);
        }
    }

    void RefreshTimer(int64_t now) {
        int left = rt_->countdown.Remaining(now);
        int total = (left + 999) / 1000;
        char buf[8];
        std::snprintf(buf, sizeof(buf), "%02d", std::clamp(total / 60, 0, 99));
        Set(tmin_, buf);
        Set(tmin2_, buf);
        std::snprintf(buf, sizeof(buf), "%02d", total % 60);
        Set(tsec_, buf);
        Set(tsec2_, buf);

        bool running = rt_->countdown.running;
        bool finished = rt_->countdown.finished;
        int field = rt_->countdown.field;
        bool editing = !running && !finished;
        int preset = rt_->countdown.preset_ms;
        const bool tick_on = rt_->countdown.tick_sound;

        for (int i = 0; i < 2; i++) {
            bool on = editing && field == i;
            lv_obj_set_style_bg_color(tcard_[i], C(on ? kCardHi : kCard), 0);
            lv_obj_set_style_border_width(tcard_[i], on ? 2 : 0, 0);
            if (on) lv_obj_set_style_border_color(tcard_[i], C(kAccent), 0);
        }
        // v39：跑表时数字和进度条都用暖黄（时间在走 = 暖色），静止灰白、
        // 编辑字段青色、结束闪烁暖黄。
        const uint32_t num_ink = running ? kWarm : kInk;
        lv_color_t cmin = C(finished ? kWarm : (editing && field == 0 ? kAccent : num_ink));
        lv_color_t csec = C(finished ? kWarm : (editing && field == 1 ? kAccent : num_ink));
        lv_obj_set_style_text_color(tmin_, cmin, 0);
        lv_obj_set_style_text_color(tmin2_, cmin, 0);
        lv_obj_set_style_text_color(tsec_, csec, 0);
        lv_obj_set_style_text_color(tsec2_, csec, 0);

        const char* st = finished ? "时间到" : running ? "运行中" : (left < preset ? "已暂停" : "设定");
        Set(tstate_, st);
        lv_obj_set_style_text_color(tstate_, C(finished ? kWarm : kMuted), 0);

        // 设定状态下不画进度，免得看起来像已经走完；运行/暂停按剩余比例。
        int bar = (preset > 0 && !editing)
                      ? std::clamp(static_cast<int>(static_cast<int64_t>(left) * 130 / preset), 0, 130)
                      : 0;
        lv_obj_set_width(tbar_, bar);
        lv_obj_set_style_bg_color(tbar_, C((finished || running) ? kWarm : kAccent), 0);

        if (finished) {
            Set(thint_, "任意键确认");
            lv_obj_set_style_text_color(thint_, C(kWarm), 0);
            bool on = (now / 400) % 2 == 0;
            lv_obj_set_style_bg_opa(tbar_, on ? LV_OPA_COVER : LV_OPA_20, 0);
        } else if (editing && field == 2) {
            // 第三个"字段"就是读秒声开关：不额外占用按键，B 轮到这里、C/D 关/开
            Set(thint_, tick_on ? "读秒声 开  C关 D开" : "读秒声 关  C关 D开");
            lv_obj_set_style_text_color(thint_, C(kAccent), 0);
            lv_obj_set_style_bg_opa(tbar_, LV_OPA_COVER, 0);
        } else if (now < rt_->timer_hint_until) {
            // 刚进页面：先说清怎么回目录（长按 B）
            Set(thint_, "长按B 返回目录");
            lv_obj_set_style_text_color(thint_, C(kAccent), 0);
            lv_obj_set_style_bg_opa(tbar_, LV_OPA_COVER, 0);
        } else {
            // v39：运行中按 B 直接开关读秒声，提示里带上当前状态
            if (running) {
                Set(thint_, tick_on ? "A暂停 B静音 C减 D增" : "A暂停 B开声 C减 D增");
            } else {
                Set(thint_, "A开始 B切换 C减 D增");
            }
            lv_obj_set_style_text_color(thint_, C(kMuted), 0);
            lv_obj_set_style_bg_opa(tbar_, LV_OPA_COVER, 0);
        }
    }

    // v47：计时目录。卡片样式只在选中项变化时改——这一页 250ms 一刷，
    // 每次都重设 bg/border 等于每帧白重绘一次。副标题每次都比一遍文本
    // （Set() 内部会挡住相同的字符串），让"正在跑的定时器/秒表"在目录里
    // 就能看见，不用进去确认。
    void RefreshTimerMenu(int64_t now) {
        const int sel = std::clamp(rt_->timer_menu_sel, 0, 2);
        if (sel != menu_sel_) {
            menu_sel_ = sel;
            for (int i = 0; i < 3; ++i) {
                const bool on = (i == sel);
                lv_obj_set_style_bg_color(mcard_[i], C(on ? kCardHi : kCard), 0);
                lv_obj_set_style_border_width(mcard_[i], on ? 2 : 0, 0);
                if (on) lv_obj_set_style_border_color(mcard_[i], C(kWarm), 0);
                lv_obj_set_style_text_color(mname_[i], C(on ? kWarm : kInk), 0);
            }
        }
        char buf[24];
        if (rt_->countdown.finished) {
            std::snprintf(buf, sizeof(buf), "时间到");
        } else if (rt_->countdown.running) {
            const int left = rt_->countdown.Remaining(now) / 1000;
            std::snprintf(buf, sizeof(buf), "余%02d:%02d", left / 60, left % 60);
        } else {
            std::snprintf(buf, sizeof(buf), "倒数");
        }
        Set(mdesc_[0], buf);
        Set(mdesc_[1], "BPM");
        if (rt_->stopwatch.running) {
            const int64_t ms = rt_->stopwatch.Elapsed(now);
            const int total = static_cast<int>(ms / 1000);
            std::snprintf(buf, sizeof(buf), "%02d:%02d", total / 60, total % 60);
        } else {
            std::snprintf(buf, sizeof(buf), "秒表");
        }
        Set(mdesc_[2], buf);
    }

    // v47：计时器（秒表）。百分秒在跳，80ms 一刷；文本只在数值真变了才写。
    void RefreshStopwatch(int64_t now) {
        auto& w = rt_->stopwatch;
        const int64_t ms = w.Elapsed(now);
        if (ms != w_last_ms_) {
            w_last_ms_ = ms;
            char mmss[16];
            int cent = 0;
            desktop_stopwatch::Clock::Format(ms, mmss, sizeof(mmss), &cent);
            Set(wtime_, mmss);
            Set(wtime2_, mmss);
            char cbuf[8];
            std::snprintf(cbuf, sizeof(cbuf), ".%02d", cent);
            Set(wcent_, cbuf);
            char lbuf[48];
            if (w.lap_count > 0) {
                const int lap_s = static_cast<int>(w.last_lap_ms / 1000);
                std::snprintf(lbuf, sizeof(lbuf), "第%d次计次  本圈 %02d:%02d",
                              w.lap_count, lap_s / 60, lap_s % 60);
            } else {
                std::snprintf(lbuf, sizeof(lbuf), "A 开始 · B 记一圈");
            }
            Set(wlap_, lbuf);
        }
        const int state = w.running ? 2 : (w.HasTime() ? 1 : 0);
        if (state != w_state_) {
            w_state_ = state;
            Set(wstate_, state == 2 ? "计时中" : (state == 1 ? "已暂停" : "归零"));
            lv_obj_set_style_text_color(wstate_, C(state == 2 ? kWarm : kMuted), 0);
            const uint32_t ink = (state == 2) ? kWarm : kInk;
            lv_obj_set_style_text_color(wtime_, C(ink), 0);
            lv_obj_set_style_text_color(wtime2_, C(ink), 0);
        }
    }

    // 节拍器的刷新：拍点用"点亮 140ms 后回落"的方式表达，进度条按拍内时间走。
    // 只在数值真的变了才改样式，避免每 80ms 白刷一遍整页。
    void RefreshMetro(int64_t now) {
        auto& m = rt_->metro;
        const int64_t us = esp_timer_get_time();
        char buf[24];
        std::snprintf(buf, sizeof(buf), "%d", m.bpm);
        Set(mbpm_, buf);
        Set(mbpm2_, buf);
        std::snprintf(buf, sizeof(buf), "%d/4", m.beats);
        Set(mstate_, buf);

        // 正在编辑的那一项亮起来：BPM 数字（青色）或右上角的拍号（暖黄）。
        // 样式只在真的换了编辑目标时改一次——lv_obj_set_style_* 即使写入相同
        // 颜色也会 invalidate，这一页每 80ms 刷一帧，白刷的代价不小。
        if (m.field != mfield_) {
            mfield_ = m.field;
            // 暖黄是这一页的主色：BPM 数字常驻黄色；编辑拍号时数字退成灰白，
            // 把注意力让给右上角的"4/4"。
            const uint32_t bpm_ink = (m.field == 1) ? kInk : kWarm;
            lv_obj_set_style_text_color(mbpm_, C(bpm_ink), 0);
            lv_obj_set_style_text_color(mbpm2_, C(bpm_ink), 0);
            lv_obj_set_style_text_color(mstate_, C(m.field == 1 ? kWarm : kMuted), 0);
        }

        if (m.beats != mbeats_) {
            mbeats_ = m.beats;
            m_lit_ = -1;  // 拍号变了必须重刷一遍颜色，新增的拍点才不是默认灰
            const int x0 = (160 - (m.beats * 20 - 10)) / 2;
            for (int i = 0; i < 6; ++i) {
                const bool vis = i < m.beats;
                lv_obj_set_flag(mdot_[i], LV_OBJ_FLAG_HIDDEN, !vis);
                if (vis) lv_obj_set_x(mdot_[i], x0 + i * 20);
            }
        }
        const int lit = m.LitBeat(us);
        if (lit != m_lit_) {
            m_lit_ = lit;
            for (int i = 0; i < m.beats; ++i) {
                const bool on = (i + 1) == lit;
                // 每小节第一拍是重拍，用暖黄区分；没亮时也留一点暗暖黄做小节头
                const uint32_t rest = (i == 0) ? kDotRest : kLine;
                lv_obj_set_style_bg_color(
                    mdot_[i], C(on ? (i == 0 ? kWarm : kAccent) : rest), 0);
            }
        }
        lv_obj_set_width(mbar_, m.Progress(us));
        if (m.running != mrunning_) {
            mrunning_ = m.running;
            // 走表时进度条是暖黄（和 BPM 数字、重拍点同色），停下来退回底色
            lv_obj_set_style_bg_color(mbar_, C(m.running ? kWarm : kLine), 0);
        }
        // 刚切进来的几秒里先说清怎么回去：v47 起节拍器是目录里的独立一项，
        // 长按 B 一律回目录。
        // 文本没变就不碰样式——这一页 80ms 一刷，白改颜色等于白重绘一条文字。
        const bool hint_mode = now < rt_->timer_hint_until;
        const char* hint = hint_mode ? "长按B 返回目录" : "A起停 B切换 C减 D增";
        const char* cur = lv_label_get_text(mhint_);
        if (cur == nullptr || std::strcmp(cur, hint) != 0) {
            lv_label_set_text(mhint_, hint);
            lv_obj_set_style_text_color(mhint_, C(hint_mode ? kAccent : kMuted), 0);
        }
    }

    void RefreshConfig(int64_t now) {        // The switch follows the REQUEST (ap_desired), so a tap is visible in the
        // next frame instead of after esp_wifi_set_mode() returns. The status line
        // reports what the driver actually achieved.
        bool want = rt_->ap_desired.load();
        bool live = rt_->ap_live.load();
        bool failed = rt_->ap_failed.load();

        lv_obj_set_style_bg_color(tswitch_, C(want ? kAccent : kLine), 0);
        lv_obj_set_x(tknob_, want ? 24 : 4);
        lv_obj_set_style_bg_color(tknob_, C(want ? kInk : kMuted), 0);
        lv_obj_set_style_text_color(tssid_, C(live ? kWarm : kMuted), 0);

        char stbuf[32];
        const char* st = stbuf;
        uint32_t color = kMuted;
        // After 长按B the device has forgotten the stored network; say so for a
        // few seconds instead of silently going quiet.
        const int64_t reset_at = rt_->wifi_reset_at.load();
        const bool just_reset = reset_at > 0 && now - reset_at >= 0 && now - reset_at < 6000;
        const int64_t applied_at = rt_->ap_apply_at.load();
        const bool stalled = want && !live && applied_at > 0 && now - applied_at > 8000;
        const int internal_kb = static_cast<int>(
            heap_caps_get_free_size(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT) / 1024);
        if (!rt_->ap_worker_up.load()) {
            // v18/v19 symptom: ap_desired is set, no worker exists to honour it,
            // so the page would otherwise say "正在开启热点" forever.
            std::snprintf(stbuf, sizeof(stbuf), "后台任务未启动 i%d", internal_kb);
            color = kWarm;
        } else if (just_reset && !live) {
            std::snprintf(stbuf, sizeof(stbuf), "已清除旧网络");
            color = kWarm;
        } else if (!want) {
            std::snprintf(stbuf, sizeof(stbuf), "热点已关闭 按A开启");
            color = kMuted;
        } else if (live) {
            std::snprintf(stbuf, sizeof(stbuf), "热点已开启 按A关闭");
            color = kAccent;
        } else if (failed || stalled) {
            // E = encoded driver failure from OpenAP(): 10+c set_mode,
            // 20+c set_config, 30+c start, 99 = no WIFI_EVENT_AP_START.
            std::snprintf(stbuf, sizeof(stbuf), "启动失败 E%d i%d",
                          rt_->ap_err.load(), internal_kb);
            color = kWarm;
        } else {
            std::snprintf(stbuf, sizeof(stbuf), "正在开启热点 E%d i%d",
                          rt_->ap_err.load(), internal_kb);
            color = kAccent;
        }
        Set(cstate_, st);
        lv_obj_set_style_text_color(cstate_, C(color), 0);
        // 热点关着时这一行显示设备连的家庭 Wi-Fi，配合下面的路由器地址，
        // 一眼就能看出"连着哪个网、拿到了什么地址"。
        Set(tssid_, (!want && !live) ? (rt_->ssid.empty() ? "未配置网络" : rt_->ssid)
                                     : "AlphaPi-Desk");
        char tip[32];
        // Show the address the netif really holds, not the one we wish it had.
        // With the DHCP server down this reads 0.0.0.0, which is the difference
        // between "the phone cannot associate" and "the phone cannot get a lease".
        const uint32_t addr = rt_->ap_ip.load();
        const int o1 = addr & 0xFF, o2 = (addr >> 8) & 0xFF;
        const int o3 = (addr >> 16) & 0xFF, o4 = (addr >> 24) & 0xFF;
        const uint32_t sta = rt_->sta_ip.load();
        bool tip_warm = false;
        if (!want && !live) {
            // v39：热点关着 = 设备只用 STA 连家里路由，这一行改成显示路由器分配
            // 到的地址。以前关掉热点后这里还挂着 192.168.4.1，完全看不出设备
            // 到底有没有联网——而这正是"网页打不开"最需要区分的一件事。
            if (sta != 0) {
                std::snprintf(tip, sizeof(tip), "路由 %u.%u.%u.%u",
                              static_cast<unsigned>(sta & 0xFF),
                              static_cast<unsigned>((sta >> 8) & 0xFF),
                              static_cast<unsigned>((sta >> 16) & 0xFF),
                              static_cast<unsigned>((sta >> 24) & 0xFF));
            } else {
                std::snprintf(tip, sizeof(tip), "未连接路由");
                tip_warm = true;
            }
        } else if (!rt_->server) {
            // Most important line of all: no httpd means nothing is listening
            // on 192.168.4.1:80, and no amount of phone-side tweaking helps.
            // i = free internal heap right now. E1 = ESP_ERR_NO_MEM: the board
            // ran out of internal DRAM, which is what starves httpd_start()'s
            // 8 KB task stack + socket table. That number is the whole diagnosis.
            std::snprintf(tip, sizeof(tip), "服务未启动 E%d i%d",
                          rt_->web_start_err.load() & 0xFF, internal_kb);
            tip_warm = true;
        } else if (failed) {
            // Driver level diagnosis, readable without a console: the mode the
            // radio ended up in, the encoded OpenAP() failure and the free heap.
            wifi_mode_t m = WIFI_MODE_NULL;
            esp_wifi_get_mode(&m);
            std::snprintf(tip, sizeof(tip), "m%d e%d h%dk", static_cast<int>(m),
                          rt_->ap_err.load(), static_cast<int>(esp_get_free_heap_size() / 1024));
            tip_warm = true;
        } else if (addr == 0) {
            std::snprintf(tip, sizeof(tip), "无地址 0.0.0.0");
            tip_warm = true;
        } else {
            std::snprintf(tip, sizeof(tip), "%d.%d.%d.%d", o1, o2, o3, o4);
        }
        Set(tip_, tip);
        lv_obj_set_style_text_color(tip_, C(tip_warm ? kWarm : kMuted), 0);

        int clients = 0;
        if (live && !rt_->ap_busy.load()) {
            wifi_sta_list_t list = {};
            if (esp_wifi_ap_get_sta_list(&list) == ESP_OK) clients = list.num;
        }
        // 设备 = associated phones, C = AP channel, L = a DHCP lease was really
        // handed out, i = free internal heap in KB (PSRAM does not help lwip).
        // When the DHCP server is down the line switches to D0 U<n>: U is whether
        // lwip has the AP netif up, which is the only state that explains a
        // dhcps_start() that reports success but leaves no server behind.
        // S = httpd server handle exists, E = the esp_err_t from httpd_start,
        // W = the board fetched /ping from 192.168.4.1 itself, P = DNS probes
        // answered. S0 (or W0) means the page is simply not being served, which
        // is a different problem from the phone sending its request elsewhere.
        const int srv = rt_->server ? 1 : 0;
        const int e = rt_->web_start_err.load() & 0xFF;
        const int w = rt_->web_self_ok.load() ? 1 : 0;
        char diag[48];
        if (!live && !want) {
            std::snprintf(diag, sizeof(diag), "长按B清除旧网 S%dE%d W%d", srv, e, w);
        } else if (live && !rt_->ap_dhcp.load()) {
            std::snprintf(diag, sizeof(diag), "设备%d D0 P%d S%dE%d W%d", clients,
                          rt_->portal_dns.load(), srv, e, w);
        } else {
            std::snprintf(diag, sizeof(diag), "设备%d C%d L%d P%d S%dE%d W%d", clients,
                          rt_->ap_chan.load(), rt_->ap_lease.load() ? 1 : 0,
                          rt_->portal_dns.load(), srv, e, w);
        }
        Set(diag_, diag);
        lv_obj_set_style_text_color(diag_, C(clients > 0 ? kAccent : kMuted), 0);
    }

    void SyncEmotion(const std::string& emotion) {
        if (emotion == gif_name_) return;
        if (gif_) {
            gif_->Stop();
            gif_.reset();
        }
        gif_name_ = emotion;
        if (emotion.empty()) return;
        auto& assets = Assets::GetInstance();
        std::string file = emotion + ".gif";
        void* ptr = nullptr;
        size_t size = 0;
        if (!assets.GetAssetData(file, ptr, size)) {
            file = "neutral.gif";
            if (!assets.GetAssetData(file, ptr, size)) return;
        }
        raw_ = std::make_unique<LvglRawImage>(ptr, size);
        gif_ = std::make_unique<LvglGif>(raw_->image_dsc());
        if (!gif_->IsLoaded()) {
            gif_.reset();
            lv_obj_add_flag(vimg_, LV_OBJ_FLAG_HIDDEN);
            return;
        }
        gif_->SetFrameCallback([this]() {
            if (vimg_ && gif_) lv_image_set_src(vimg_, gif_->image_dsc());
        });
        lv_image_set_src(vimg_, gif_->image_dsc());
        gif_->Start();
        lv_obj_remove_flag(vimg_, LV_OBJ_FLAG_HIDDEN);
    }

    void Set(lv_obj_t* label, const std::string& value) {
        if (label == nullptr) return;
        const char* cur = lv_label_get_text(label);
        if (cur != nullptr && value == cur) return;
        lv_label_set_text(label, value.c_str());
    }

    // ---------------- animation ----------------
    static void AnimCb(lv_timer_t* t) {
        auto* self = static_cast<Ui*>(lv_timer_get_user_data(t));
        if (self) self->Animate();
    }

    // 真实电平驱动波形：RMS 来自 N32Audio::Write()，快升慢降，
    // 每根柱再乘独立版的增益曲线。暂停 / 静音时自然衰减到底。
    void RadioMeter() {
        RadioUi& p = radio_;
        auto& r = rt_->radio;
        const bool active = r.state() == radio::PlayerState::kPlaying &&
                            !r.paused() && r.volume() > 0;
        const int level = active ? std::clamp(r.Level(), 0, 100) : 0;
        bool changed = false;
        for (int i = 0; i < kRadioBars; ++i) {
            const int h = std::clamp(
                std::max(level * kRadioGain[i] / 100, p.bar_h[i] - 2),
                2, kRadioBarMax);
            changed |= h != p.bar_h[i];
            p.bar_h[i] = h;
        }
        if (!p.meter_buf) return;
        // v34：电平没变化就什么都不做。以前这里还会 invalidate 一次，
        // 等于静止画面也在 16fps 重绘，纯属白烧 UI 任务的时间。
        if (!changed) return;
        const uint16_t bg = To565(C(rBg));
        const uint16_t hi = To565(C(rCyan));
        const uint16_t lo = To565(C(rBrown));
        constexpr int kW = kMeterW, kH = kRadioBarMax;
        for (int i = 0; i < kW * kH; ++i) p.meter_buf[i] = bg;
        for (int b = 0; b < kRadioBars; ++b) {
            const int h = p.bar_h[b];
            const uint16_t col = h >= 8 ? hi : lo;
            for (int y = kH - h; y < kH; ++y) {
                for (int x = b * kMeterPitch; x < b * kMeterPitch + 5 && x < kW; ++x)
                    p.meter_buf[y * kW + x] = col;
            }
        }
        lv_obj_invalidate(p.meter);
    }

    void Animate() {
        if (!ready_) return;
        if (page_ == 1) {
            // 33ms 一帧（约 30fps）：25ms 时全屏 canvas 重绘 + SPI flush 会把
            // UI 任务占满，按键扫描反而被挤慢。按键本身由 Key()::RedrawNow()
            // 立即重画，不依赖这个帧率。
            const int want = game_.InPlay() ? 33 : 40;
            if (anim_ && want != anim_period_) { anim_period_ = want; lv_timer_set_period(anim_, want); }
            game_.Tick();
            return;
        }
        if (anim_ && anim_period_ != 40) { anim_period_ = 40; lv_timer_set_period(anim_, 40); }
        // 收音机波形已移到 UiTask 主循环（PumpRadioMeter），这里不再重复刷新。
    }

    DesktopRuntime* rt_ = nullptr;
    bool ready_ = false;
    int page_ = -1;
    bool page_dirty_ = false;
    int64_t boot_ms_ = 0;
    int64_t last_meter_ms_ = 0;
    bool vol_shown_ = false;

    const lv_font_t* zh_ = nullptr;
    const lv_font_t* big_ = nullptr;
    const lv_font_t* mid_ = nullptr;
    std::unique_ptr<LvglCBinFont> font_;
    lv_image_dsc_t icon_[4] = {};

    lv_obj_t* home_ = nullptr;
    lv_obj_t* clock_ = nullptr;
    lv_obj_t* date_ = nullptr;
    lv_obj_t* place_ = nullptr;
    lv_obj_t* status_ = nullptr;
    lv_obj_t* sig_[4] = {};

    GameUi game_;
    RadioUi radio_;

    lv_obj_t* voice_ = nullptr;
    lv_obj_t* vstatus_ = nullptr;
    lv_obj_t* vclock_ = nullptr;
    lv_obj_t* vimg_ = nullptr;
    lv_obj_t* vtitle_ = nullptr;
    lv_obj_t* vcode_ = nullptr;
    lv_obj_t* vchat_ = nullptr;
    std::unique_ptr<LvglRawImage> raw_;
    std::unique_ptr<LvglGif> gif_;
    std::string gif_name_;
    std::string last_chat_;
    std::string last_status_;

    lv_obj_t* timer_ = nullptr;   // 计时页根容器（承载目录 + 三个子视图）
    lv_obj_t* count_ = nullptr;   // 定时器（倒计时）
    lv_obj_t* tstate_ = nullptr;
    lv_obj_t* tcard_[2] = {};
    lv_obj_t* tmin_ = nullptr;
    lv_obj_t* tmin2_ = nullptr;
    lv_obj_t* tsec_ = nullptr;
    lv_obj_t* tsec2_ = nullptr;
    lv_obj_t* tbar_ = nullptr;
    lv_obj_t* thint_ = nullptr;

    // v47：计时目录（三张卡片：定时器 / 节拍器 / 计时器）
    lv_obj_t* menu_ = nullptr;
    lv_obj_t* mcard_[3] = {};
    lv_obj_t* mname_[3] = {};
    lv_obj_t* mdesc_[3] = {};
    int menu_sel_ = -1;

    // v47：计时器（秒表，正计时）
    lv_obj_t* watch_ = nullptr;
    lv_obj_t* wtime_ = nullptr;
    lv_obj_t* wtime2_ = nullptr;
    lv_obj_t* wcent_ = nullptr;
    lv_obj_t* wstate_ = nullptr;
    lv_obj_t* wlap_ = nullptr;
    lv_obj_t* whint_ = nullptr;
    int64_t w_last_ms_ = -1;
    int w_state_ = -1;
    bool w_running_ = false;

    lv_obj_t* metro_ = nullptr;
    lv_obj_t* mstate_ = nullptr;
    lv_obj_t* mbpm_ = nullptr;
    lv_obj_t* mbpm2_ = nullptr;
    lv_obj_t* mdot_[6] = {};
    lv_obj_t* mbar_ = nullptr;
    lv_obj_t* mhint_ = nullptr;
    int mbeats_ = -1;
    int m_lit_ = -1;
    int mfield_ = -1;
    int mrunning_ = -1;
    int view_shown_ = -1;

    lv_obj_t* vol_ = nullptr;
    lv_obj_t* vol_label_ = nullptr;
    lv_obj_t* vol_bar_ = nullptr;
    lv_timer_t* anim_ = nullptr;
    int anim_period_ = 40;  // 当前动画定时器周期（游戏内 25ms，其余 40ms）

    lv_obj_t* cfg_ = nullptr;
    lv_obj_t* cstate_ = nullptr;
    lv_obj_t* tswitch_ = nullptr;
    lv_obj_t* tknob_ = nullptr;
    lv_obj_t* tssid_ = nullptr;
    lv_obj_t* tip_ = nullptr;
    lv_obj_t* diag_ = nullptr;
};

}  // namespace dui
