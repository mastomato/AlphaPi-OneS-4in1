#pragma once
#include "desktop_aa_font.h"
#include "st7789.h"
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <string>

// Anti-aliased drawing layer for the 160x128 RGB565 framebuffer.
// Glyphs are 2bpp / digits 4bpp alpha; edges are alpha-blended with the
// page background so nothing is drawn as hard 1-bit blocks any more.
namespace gfx {
inline uint16_t Color(int r,int g,int b){return ((r>>3)<<11)|((g>>2)<<5)|(b>>3);}
constexpr uint16_t kBg=0x08a4;
inline uint16_t Mix(uint16_t bg,uint16_t fg,int a){
 int br=(bg>>11)&31,bg_g=(bg>>5)&63,bb=bg&31;
 int fr=(fg>>11)&31,fg_g=(fg>>5)&63,fb=fg&31;
 int r=br+((fr-br)*a+127)/255;
 int g=bg_g+((fg_g-bg_g)*a+127)/255;
 int b=bb+((fb-bb)*a+127)/255;
 return static_cast<uint16_t>((r<<11)|(g<<5)|b);
}
inline void Pixel(radio::Display& lcd,int x,int y,uint16_t fg,int alpha,uint16_t bg=kBg){
 if(x<0||x>=160||y<0||y>=128||alpha<=0)return;
 lcd.DrawPixel(x,y,alpha>=255?fg:Mix(bg,fg,alpha));
}
inline uint32_t Next(const char*& p){
 uint8_t c=*p++;if(c<128)return c;
 int n=(c&0xe0)==0xc0?1:(c&0xf0)==0xe0?2:0;
 uint32_t v=c&(n==1?31:15);
 if(!n)return '?';
 while(n--){if(!*p)return '?';v=(v<<6)|(*p++&63);}
 return v;
}
inline const AaGlyph* Glyph(uint32_t code){
 uint32_t lo=0,hi=sizeof(aa_glyphs)/sizeof(aa_glyphs[0]);
 while(lo<hi){uint32_t mid=(lo+hi)/2;if(aa_glyphs[mid].code<code)lo=mid+1;else hi=mid;}
 return lo<sizeof(aa_glyphs)/sizeof(aa_glyphs[0])&&aa_glyphs[lo].code==code?&aa_glyphs[lo]:nullptr;
}
inline int Width(const std::string& s){
 int w=0;const char* p=s.c_str();
 while(*p){auto* g=Glyph(Next(p));if(g)w+=g->advance;}
 return w;
}
inline int Text(radio::Display& lcd,int x,int y,const std::string& s,uint16_t color,
                int right=159,int bottom=128,bool wrap=false,uint16_t bg=kBg){
 const int start=x;const char* p=s.c_str();
 while(*p){
  uint32_t code=Next(p);
  if(code=='\n'){x=start;y+=14;continue;}
  const auto* g=Glyph(code);if(!g)continue;
  if(x+g->advance>right){if(!wrap)break;x=start;y+=14;}
  if(y+13>bottom)break;
  for(int yy=0;yy<13;yy++){
   const auto& row=g->rows[yy];
   for(int xx=0;xx<9;xx++){
    int shift=(xx*2)%8;
    int a=(row[xx*2/8]>>shift)&3;
    if(a)Pixel(lcd,x+xx,y+yy,color,a*85,bg);
   }
  }
  x+=g->advance;
 }
 return x;
}
inline int Digits(radio::Display& lcd,int x,int y,const char* s,uint16_t color,float scale=1.0f,int spacing=0,uint16_t bg=kBg){
 for(;*s;s++){
  int idx=-1;
  if(*s>='0'&&*s<='9')idx=*s-'0';
  else if(*s==':')idx=10;
  else if(*s=='-')idx=11;
  else if(*s=='C')idx=13;
  if(idx<0||idx>=14){x+=static_cast<int>(9*scale);continue;}
  const auto& d=aa_digits[idx];
  int w=static_cast<int>(24*scale),h=static_cast<int>(40*scale);
  for(int dy=0;dy<h;dy++){
   int sy=static_cast<int>(dy/scale);if(sy>=40)break;
   for(int dx=0;dx<w;dx++){
    int sx=static_cast<int>(dx/scale);if(sx>=24)break;
    int a=(d.rows[sy][sx/2]>>((sx%2)*4))&15;
    if(a)Pixel(lcd,x+dx,y+dy,color,a*17,bg);
   }
  }
  x+=static_cast<int>(d.advance*scale)+spacing;
 }
 return x;
}
inline void Disc(radio::Display& lcd,float cx,float cy,float r,uint16_t color,uint16_t bg=kBg){
 for(int y=static_cast<int>(cy-r-1);y<=static_cast<int>(cy+r+1);y++)
  for(int x=static_cast<int>(cx-r-1);x<=static_cast<int>(cx+r+1);x++){
   float d=std::hypot(x-cx,y-cy);
   int a=static_cast<int>((r-d+0.5f)*255);
   if(a>0)Pixel(lcd,x,y,color,std::min(255,a),bg);
  }
}
inline void Ring(radio::Display& lcd,float cx,float cy,float r,float thick,uint16_t color,uint16_t bg=kBg){
 for(int y=static_cast<int>(cy-r-2);y<=static_cast<int>(cy+r+2);y++)
  for(int x=static_cast<int>(cx-r-2);x<=static_cast<int>(cx+r+2);x++){
   float d=std::hypot(x-cx,y-cy);
   int a=static_cast<int>((thick/2.0f-std::abs(d-r)+0.5f)*255);
   if(a>0)Pixel(lcd,x,y,color,std::min(255,a),bg);
  }
}
inline void RoundRect(radio::Display& lcd,int x,int y,int w,int h,float r,uint16_t color,uint16_t bg=kBg){
 for(int yy=0;yy<=h;yy++)for(int xx=0;xx<=w;xx++){
  float dx=std::max(0.0f,std::max(static_cast<float>(r-xx),static_cast<float>(xx-(w-r))));
  float dy=std::max(0.0f,std::max(static_cast<float>(r-yy),static_cast<float>(yy-(h-r))));
  float d=std::hypot(dx,dy);
  int a=static_cast<int>((r-d+0.5f)*255);
  if(a>0)Pixel(lcd,x+xx,y+yy,color,std::min(255,a),bg);
 }
}
inline void Line(radio::Display& lcd,float x0,float y0,float x1,float y1,float thick,uint16_t color,uint16_t bg=kBg){
 float vx=x1-x0,vy=y1-y0,len2=vx*vx+vy*vy;
 for(int y=static_cast<int>(std::min(y0,y1)-thick-1);y<=static_cast<int>(std::max(y0,y1)+thick+1);y++)
  for(int x=static_cast<int>(std::min(x0,x1)-thick-1);x<=static_cast<int>(std::max(x0,x1)+thick+1);x++){
   float t=len2>0?std::clamp(((x-x0)*vx+(y-y0)*vy)/len2,0.0f,1.0f):0.0f;
   float d=std::hypot(x-(x0+t*vx),y-(y0+t*vy));
   int a=static_cast<int>((thick/2.0f-d+0.5f)*255);
   if(a>0)Pixel(lcd,x,y,color,std::min(255,a),bg);
  }
}
}
