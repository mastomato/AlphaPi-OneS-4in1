#pragma once
#include "desktop_home.h"
#include "desktop_gfx.h"
#include "st7789.h"
#include "settings.h"
#include <algorithm>
#include <cstdint>
#include <cstdio>

namespace desktop_countdown {
inline uint16_t C(int r,int g,int b){return ((r>>3)<<11)|((g>>2)<<5)|(b>>3);}

// Standalone timer. B cycles the editable field (minutes / seconds),
// C / D adjust it, A confirms and starts (or pauses) with the current preset.
struct Timer {
    static constexpr int kMinSec=1;
    static constexpr int kMaxSec=5999;
    int preset_ms=300000;
    int remain_ms=300000;
    int64_t end_ms=0;
    bool running=false;
    bool finished=false;
    int field=0;
    int beep_left=0;
    int64_t beep_next_ms=0;
    // v39：读秒声。走表期间每秒"嗒"一下，最后 3 秒音高抬高；计时过程中
    // 直接按 B 就能开关（跑起来之后还要翻设置页才能关，等于没法关）。
    bool tick_sound=true;
    int last_tick_sec=-1;
    bool tick_event=false;

    void Load(){
        Settings s("desk_timer",true);
        int sec=std::clamp(static_cast<int>(s.GetInt("preset",300)),kMinSec,kMaxSec);
        preset_ms=sec*1000;remain_ms=preset_ms;
        tick_sound=s.GetBool("tick",true);
    }
    void Save(){
        Settings s("desk_timer",true);
        s.SetInt("preset",preset_ms/1000);
        s.SetBool("tick",tick_sound);
    }
    void Reset(){running=false;finished=false;remain_ms=preset_ms;end_ms=0;beep_left=0;
        last_tick_sec=-1;tick_event=false;}
    void SetPreset(int sec){
        sec=std::clamp(sec,kMinSec,kMaxSec);
        preset_ms=sec*1000;remain_ms=preset_ms;
        running=false;finished=false;end_ms=0;beep_left=0;last_tick_sec=-1;tick_event=false;Save();
    }
    int Remaining(int64_t now)const{
        if(finished)return 0;
        if(running)return std::max(0,static_cast<int>(end_ms-now));
        return remain_ms;
    }
    void Start(int64_t now){
        if(finished)Reset();
        if(remain_ms<=0)remain_ms=preset_ms;
        end_ms=now+remain_ms;running=true;finished=false;last_tick_sec=-1;tick_event=false;
    }
    void Pause(int64_t now){
        if(!running)return;
        remain_ms=Remaining(now);running=false;
    }
    void Toggle(int64_t now){if(running)Pause(now);else Start(now);}
    void NextField(){
        // 运行中按 B 直接开关读秒声；停止时才在 分 / 秒 / 读秒声 之间轮换。
        if(running){tick_sound=!tick_sound;Save();return;}
        field=(field+1)%3;
    }
    void Step(int delta,int64_t now){
        if(field==2){tick_sound=(delta>0);Save();return;}
        if(running)Pause(now);
        if(finished){finished=false;beep_left=0;remain_ms=preset_ms;}
        int total=std::clamp(remain_ms/1000+(field==0?delta*60:delta),kMinSec,kMaxSec);
        remain_ms=total*1000;preset_ms=total*1000;
        Save();
    }
    void Tick(int64_t now){
        if(running&&end_ms<=now){
            running=false;finished=true;remain_ms=0;
            beep_left=3;beep_next_ms=now;last_tick_sec=-1;tick_event=false;
        }
        if(!running||!tick_sound){last_tick_sec=-1;return;}
        const int sec=(Remaining(now)+999)/1000;
        if(sec==last_tick_sec)return;
        const bool first=(last_tick_sec<0);
        last_tick_sec=sec;
        // 起拍那一秒不响：刚按下 A 的按键音还没落，再叠一声反而糊
        if(!first&&sec>0)tick_event=true;
    }
    // 一次性取用：board 每轮扫描调用，取到这一次就清掉，不重复发声。
    bool ConsumeTick(){const bool v=tick_event;tick_event=false;return v;}
    void Acknowledge(){if(finished){finished=false;beep_left=0;Reset();}}

    void Draw(radio::Display& lcd,int64_t now,bool blink){
        const auto bg=C(14,20,32),cyan=C(143,227,240),warm=C(255,210,122),
                   ink=C(147,170,198),dim=C(113,134,160);
        int left=Remaining(now),total=left/1000;
        char buf[16];snprintf(buf,sizeof(buf),"%02d:%02d",total/60,total%60);
        desktop_home::Text(lcd,9,6,"计时器",cyan,159);
        const char* state=finished?"时间到":running?"运行中":(left<preset_ms?"已暂停":"设定");
        desktop_home::Text(lcd,112,6,state,finished?warm:dim,159);
        uint16_t big=finished?(blink?warm:bg):(running?cyan:ink);
        gfx::Digits(lcd,20,32,buf,big,1.2f,4,bg);
        if(!running&&!finished&&field<2){
            int fx=field==0?20:20+3*24;
            gfx::RoundRect(lcd,fx,88,46,2,1.0f,warm);
        }
        gfx::RoundRect(lcd,12,100,136,6,3.0f,C(27,39,64));
        int pct=preset_ms>0?std::clamp(static_cast<int>(static_cast<int64_t>(left)*136/preset_ms),0,136):0;
        if(pct>0)gfx::RoundRect(lcd,12,100,pct,6,3.0f,finished?warm:cyan);
        if(finished)desktop_home::Text(lcd,48,112,"任意键确认",warm,159);
    }
};
}
