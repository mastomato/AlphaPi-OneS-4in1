#ifndef AUDIO_SERVICE_H
#define AUDIO_SERVICE_H

#include <atomic>
#include <chrono>
#include <condition_variable>
#include <memory>
#include <mutex>

#include <esp_timer.h>
#include <freertos/FreeRTOS.h>
#include <freertos/event_groups.h>
#include <freertos/task.h>
#include <model_path.h>
#include "esp_ae_rate_cvt.h"
#include "esp_audio_enc.h"
#include "esp_audio_types.h"
#include "esp_opus_dec.h"
#include "esp_opus_enc.h"

#include "audio_codec.h"
#include "audio_debugger.h"
#include "audio_engine.h"
#include "fixed_queue.h"
#include "ogg_demuxer.h"
#include "protocol.h"

/*
 * There are two types of audio data flow:
 * 1. (MIC) -> [Audio Engine] -> {Encode Queue} -> [Opus Encoder] -> {Send Queue} -> (Server)
 * 2. (Server) -> {Decode Queue} -> [Opus Decoder] -> {Playback Queue} -> (Speaker)
 *
 * We use dedicated tasks for input, output, and Opus encoding/decoding.
 *
 * Decode Queue and Send Queue are the main queues, because Opus packets are quite smaller than PCM
 * packets.
 *
 */

#define OPUS_FRAME_DURATION_MS 60
#define MAX_ENCODE_TASKS_IN_QUEUE 2
// OneS desktop v46：2 -> 5（60ms x 5 = 300ms 缓冲）。原来只有 2 帧 120ms，
// 而 Opus 解码 + 16k->24k 重采样跑在 opus_codec 任务里，只要被 UI(5)/
// audio_output(5)/audio_input(8) 压住超过 120ms，播放队列就空了：
// N32 接收缓冲排空 -> 声音断续 / 流间隙。解码队列本身有 20 帧(1.2s)，
// 瓶颈一直在 playback 这一级。多出的 3 帧 PCM 约 8.6KB 堆内存。
#define MAX_PLAYBACK_TASKS_IN_QUEUE 5
#define MAX_DECODE_PACKETS_IN_QUEUE (1200 / OPUS_FRAME_DURATION_MS)
#define MAX_SEND_PACKETS_IN_QUEUE (2400 / OPUS_FRAME_DURATION_MS)
#define AUDIO_TESTING_MAX_DURATION_MS 10000
#define MAX_TIMESTAMPS_IN_QUEUE 3

#define AUDIO_POWER_TIMEOUT_MS 15000
#define AUDIO_POWER_CHECK_INTERVAL_MS 1000

#define AS_EVENT_AUDIO_TESTING_RUNNING (1 << 0)
#define AS_EVENT_WAKE_WORD_RUNNING (1 << 1)
#define AS_EVENT_AUDIO_PROCESSOR_RUNNING (1 << 2)
#define AS_EVENT_AUDIO_INPUT_STOP_REQUEST (1 << 4)

#define AS_OPUS_GET_FRAME_DRU_ENUM(duration_ms)                  \
    ((duration_ms) == 5     ? ESP_OPUS_ENC_FRAME_DURATION_5_MS   \
     : (duration_ms) == 10  ? ESP_OPUS_ENC_FRAME_DURATION_10_MS  \
     : (duration_ms) == 20  ? ESP_OPUS_ENC_FRAME_DURATION_20_MS  \
     : (duration_ms) == 40  ? ESP_OPUS_ENC_FRAME_DURATION_40_MS  \
     : (duration_ms) == 60  ? ESP_OPUS_ENC_FRAME_DURATION_60_MS  \
     : (duration_ms) == 80  ? ESP_OPUS_ENC_FRAME_DURATION_80_MS  \
     : (duration_ms) == 100 ? ESP_OPUS_ENC_FRAME_DURATION_100_MS \
     : (duration_ms) == 120 ? ESP_OPUS_ENC_FRAME_DURATION_120_MS \
                            : -1)

#define AS_OPUS_ENC_CONFIG()                                                                   \
    {                                                                                          \
        .sample_rate = ESP_AUDIO_SAMPLE_RATE_16K,                                              \
        .channel = ESP_AUDIO_MONO,                                                             \
        .bits_per_sample = ESP_AUDIO_BIT16,                                                    \
        .bitrate = ESP_OPUS_BITRATE_AUTO,                                                      \
        .frame_duration =                                                                      \
            (esp_opus_enc_frame_duration_t)AS_OPUS_GET_FRAME_DRU_ENUM(OPUS_FRAME_DURATION_MS), \
        .application_mode = ESP_OPUS_ENC_APPLICATION_AUDIO,                                    \
        .complexity = 0,                                                                       \
        .enable_fec = false,                                                                   \
        .enable_dtx = true,                                                                    \
        .enable_vbr = true,                                                                    \
    }

struct AudioServiceCallbacks {
    std::function<void(void)> on_send_queue_available;
    std::function<void(const std::string&)> on_wake_word_detected;
    std::function<void(bool)> on_vad_change;
    std::function<void(void)> on_audio_testing_queue_full;
    // Fired when the decode/playback queues and their in-flight work are drained.
    std::function<void(void)> on_playback_drained;
    std::function<void(uint32_t playback_id, uint32_t media_position_ms)> on_playback_progress;
};

enum AudioTaskType {
    kAudioTaskTypeEncodeToSendQueue,
    kAudioTaskTypeEncodeToTestingQueue,
    kAudioTaskTypeDecodeToPlaybackQueue,
};

struct AudioTask {
    AudioTaskType type;
    std::vector<int16_t> pcm;
    uint32_t timestamp = 0;
    uint32_t playback_id = 0;
    uint32_t media_position_ms = 0;
};

struct DebugStatistics {
    uint32_t input_count = 0;
    uint32_t decode_count = 0;
    uint32_t encode_count = 0;
    uint32_t playback_count = 0;
    uint32_t encode_drop_count = 0;
};

// v50：把播放链路的可观测计数整体暴露出来，由 /api/status 读取。
// 这块板子的 console 没有接到 USB 口（见 desktop_runtime.h 的说明），
// 串口日志在实机上根本拿不到，v45~v49 打的所有诊断日志都是白发。
// 全部是累计值（odometer），调用方隔一段时间读两次做差即可得到窗口量。
struct AudioDiag {
    uint32_t frames = 0;          // 累计写出的播放帧
    uint32_t slow = 0;            // 累计单帧写流 >60ms 的帧数
    uint32_t starve_ms = 0;       // 累计等待播放队列的毫秒数
    uint32_t max_ms = 0;          // 单帧写流历史最大耗时
    uint32_t drops = 0;           // 解码队列满导致丢弃的 Opus 包数
    uint32_t decode_ms_max = 0;   // 单帧解码 + 重采样最大耗时
    uint32_t decode_queue = 0;    // 当前解码队列深度
    uint32_t playback_queue = 0;  // 当前播放队列深度
    uint32_t active_tasks = 0;
    AudioCodec::IoStats io;       // ACK 失败 / 流间隙 / 复位 / 背压
};

class AudioService {
public:
    AudioService();
    ~AudioService();

    void Initialize(AudioCodec* codec);
    void Start();
    void Stop();
    int ActiveTasks() const { return active_tasks_.load(); }
    // v50：一次性取走全部播放诊断计数（含当前队列深度）。
    AudioDiag GetDiag();
    bool IsStopped() const { return service_stopped_.load(); }
    void EncodeWakeWord();
    std::unique_ptr<AudioStreamPacket> PopWakeWordPacket();
    const std::string& GetLastWakeWord() const;
    std::vector<std::string> GetWakeWords() const;
    bool IsVoiceDetected() const { return voice_detected_; }
    bool IsIdle();
    bool IsPlaybackIdle();
    bool IsWakeWordRunning() const {
        return xEventGroupGetBits(event_group_) & AS_EVENT_WAKE_WORD_RUNNING;
    }
    bool IsAudioProcessorRunning() const {
        return xEventGroupGetBits(event_group_) & AS_EVENT_AUDIO_PROCESSOR_RUNNING;
    }
    bool IsAfeWakeWord();

    void EnableWakeWordDetection(bool enable);
    void ReleaseWakeWordResources();
    void EnableVoiceProcessing(bool enable);
    void EnableAudioTesting(bool enable);
    void EnableDeviceAec(bool enable);

    void SetCallbacks(AudioServiceCallbacks& callbacks);

    bool PushPacketToDecodeQueue(std::unique_ptr<AudioStreamPacket> packet, bool wait = false);
    std::unique_ptr<AudioStreamPacket> PopPacketFromSendQueue();
    void PlaySound(const std::string_view& sound);
    bool ReadAudioData(std::vector<int16_t>& data, int sample_rate, int samples);
    void ResetDecoder();
    void SetModelsList(srmodel_list_t* models_list);

private:
    AudioCodec* codec_ = nullptr;
    AudioServiceCallbacks callbacks_;
    std::unique_ptr<AudioEngine> audio_engine_;
    std::unique_ptr<AudioDebugger> audio_debugger_;
    void* opus_encoder_ = nullptr;
    void* opus_decoder_ = nullptr;
    std::mutex decoder_mutex_;
    std::mutex input_resampler_mutex_;
    esp_ae_rate_cvt_handle_t input_resampler_ = nullptr;
    esp_ae_rate_cvt_handle_t output_resampler_ = nullptr;

    // Encoder/Decoder state
    int encoder_sample_rate_ = 16000;
    int encoder_duration_ms_ = OPUS_FRAME_DURATION_MS;
    int encoder_frame_size_ = 0;
    int encoder_outbuf_size_ = 0;
    int decoder_sample_rate_ = 0;
    int decoder_duration_ms_ = OPUS_FRAME_DURATION_MS;
    int decoder_frame_size_ = 0;
    DebugStatistics debug_statistics_;
    int64_t last_encode_drop_log_time_ = 0;
    srmodel_list_t* models_list_ = nullptr;

    EventGroupHandle_t event_group_;

    // Audio encode / decode
    TaskHandle_t audio_input_task_handle_ = nullptr;
    TaskHandle_t audio_output_task_handle_ = nullptr;
    TaskHandle_t opus_codec_task_handle_ = nullptr;
    std::mutex audio_queue_mutex_;
    std::condition_variable audio_queue_cv_;
    // Testing records up to AUDIO_TESTING_MAX_DURATION_MS, then swaps into the
    // decode queue. Both queues must share this capacity so swap() is valid.
    static constexpr size_t kAudioTestingPacketCapacity =
        AUDIO_TESTING_MAX_DURATION_MS / OPUS_FRAME_DURATION_MS;
    FixedQueue<std::unique_ptr<AudioStreamPacket>, kAudioTestingPacketCapacity> audio_decode_queue_;
    FixedQueue<std::unique_ptr<AudioStreamPacket>, MAX_SEND_PACKETS_IN_QUEUE> audio_send_queue_;
    FixedQueue<std::unique_ptr<AudioStreamPacket>, kAudioTestingPacketCapacity>
        audio_testing_queue_;
    FixedQueue<AudioTask, MAX_ENCODE_TASKS_IN_QUEUE> audio_encode_queue_;
    FixedQueue<AudioTask, MAX_PLAYBACK_TASKS_IN_QUEUE> audio_playback_queue_;
    bool decode_in_flight_ = false;
    bool output_in_flight_ = false;
    bool playback_drained_notified_ = true;
    uint32_t playback_generation_ = 0;
    // For server AEC
    FixedQueue<uint32_t, MAX_TIMESTAMPS_IN_QUEUE> timestamp_queue_;

    bool audio_engine_initialized_ = false;
    bool voice_detected_ = false;
#if CONFIG_USE_DEVICE_AEC
    bool device_aec_enabled_ = true;
#else
    bool device_aec_enabled_ = false;
#endif
    std::atomic<bool> service_stopped_{true};
    std::atomic<int> active_tasks_{0};
    std::atomic<bool> audio_input_need_warmup_{false};

    // v46：小智播放链路的可观测计数。只在一次播放排空时汇总打印一条，
    // **没有周期性日志**（v44 的每 10s ESP_LOGI 曾自己制造 8.7ms 抖动）。
    // starve_ms 高 = 解码/网络供不上；slow 帧多 = UART 写流太慢，两者可区分。
    std::atomic<uint32_t> output_frames_{0};
    std::atomic<uint32_t> output_slow_frames_{0};  // 单帧写流超过 60ms
    std::atomic<uint32_t> output_max_ms_{0};
    std::atomic<uint32_t> output_starve_ms_{0};   // 等 playback 队列累计
    // v48：上一轮汇总时 codec 的底层 I/O 计数基线，用来打印本轮增量。
    AudioCodec::IoStats io_stat_base_{};
    // v49：播放心跳。`playback done` 只在整轮播放**排空**时打印一次，小智播
    // 长音乐时流一直不断，那条日志永远不出现 —— 上一版抓了 90 秒串口一个
    // 字节都没有就是这个原因。这里改成「只要在播放，每 5 秒一条累计值」，
    // 靠相邻两条做差就能看到本窗口的帧数/慢帧/饥饿/丢包。
    // 全部是累计值（odometer），不做窗口复位，逻辑最简单也最不容易出错。
    std::atomic<uint32_t> hb_frames_{0};     // 累计写出的播放帧
    std::atomic<uint32_t> hb_slow_{0};       // 累计 >60ms 的慢帧
    std::atomic<uint32_t> hb_starve_ms_{0};  // 累计等待播放队列的毫秒数
    std::atomic<uint32_t> hb_max_ms_{0};     // 单帧写流耗时历史最大值
    std::atomic<uint32_t> decode_drops_{0};  // 解码队列满导致的丢包数
    std::atomic<uint32_t> decode_ms_max_{0}; // 单帧 Opus 解码+重采样最大耗时

    esp_timer_handle_t audio_power_timer_ = nullptr;
    std::chrono::steady_clock::time_point last_input_time_;
    std::chrono::steady_clock::time_point last_output_time_;

    void AudioInputTask();
    void AudioOutputTask();
    void OpusCodecTask();
    void PushTaskToEncodeQueue(AudioTaskType type, std::vector<int16_t>&& pcm);
    bool InitializeAudioEngine();
    void SetDecodeSampleRate(int sample_rate, int frame_duration);
    void CheckAndUpdateAudioPowerState();
    bool IsPlaybackDrainedLocked() const;
    bool MarkPlaybackDrainedLocked();
};

#endif
