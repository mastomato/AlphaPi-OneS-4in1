#include <esp_log.h>
#include <esp_err.h>
#include <nvs_flash.h>
#include <driver/gpio.h>
#include <esp_event.h>
#include <esp_heap_caps.h>
#include <esp_psram.h>
#include <esp_system.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>

#include "application.h"

#define TAG "main"

// v38：启动阶段的自检输出。
//
// 之前完全没有这一层，导致"别人机器刷完无限重启、我这台正常"这种问题只能靠猜。
// 现在 app 一进来就把最容易有差异的硬件事实打出来：复位原因、assets 分区、
// PSRAM 是否可用与大小、内部堆余量。任何人贴一张串口截图就能定位到哪一环。
static const char* ResetReasonName(esp_reset_reason_t r) {
    switch (r) {
        case ESP_RST_POWERON:   return "POWERON";
        case ESP_RST_EXT:       return "EXT_PIN";
        case ESP_RST_SW:        return "SW";
        case ESP_RST_PANIC:     return "PANIC";
        case ESP_RST_INT_WDT:   return "INT_WDT";
        case ESP_RST_TASK_WDT:  return "TASK_WDT";
        case ESP_RST_WDT:       return "WDT";
        case ESP_RST_DEEPSLEEP: return "DEEPSLEEP";
        case ESP_RST_BROWNOUT:  return "BROWNOUT";
        case ESP_RST_SDIO:      return "SDIO";
        default:                return "UNKNOWN";
    }
}

static void LogBootFacts() {
    ESP_LOGI(TAG, "==== OneS boot ====");
    ESP_LOGI(TAG, "reset reason : %s", ResetReasonName(esp_reset_reason()));

    const esp_partition_t* assets =
        esp_partition_find_first(ESP_PARTITION_TYPE_ANY, ESP_PARTITION_SUBTYPE_ANY, "assets");
    if (assets != nullptr) {
        ESP_LOGI(TAG, "assets part  : @0x%08lx size %lu KB",
                 (unsigned long)assets->address, (unsigned long)(assets->size / 1024));
    } else {
        // 没有 assets 分区不代表要停机：UI 会自动退回默认字体（中文显示为方块）。
        // 但必须能看见，否则用户只会把现象描述成"开不了机"。
        ESP_LOGE(TAG, "assets part  : NOT FOUND (UI will fall back to built-in font)");
    }

    if (esp_psram_is_initialized()) {
        ESP_LOGI(TAG, "psram        : OK, %u KB free of %u KB",
                 (unsigned)(heap_caps_get_free_size(MALLOC_CAP_SPIRAM) / 1024),
                 (unsigned)(esp_psram_get_size() / 1024));
    } else {
        ESP_LOGE(TAG, "psram        : NOT AVAILABLE (degraded mode, UI may stay blank)");
    }
    ESP_LOGI(TAG, "internal heap: %u KB free, largest %u KB",
             (unsigned)(heap_caps_get_free_size(MALLOC_CAP_INTERNAL) / 1024),
             (unsigned)(heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL) / 1024));
    ESP_LOGI(TAG, "===================");
}

// 原因：`esp_restart()` 之后 ROM 只会留下 ESP_RST_SW；真实 panic/brownout/WDT
// 会在下一次 `app_main` 被覆盖，用户刚好看不到。RAM 复位后 NVS 也保留，
// 用它把“上一次复位原因”带过重启线，屏幕才能显示故障现场。
static void SaveBootSnapshot() {
    nvs_handle_t nvs = 0;
    if (nvs_open("bootdiag", NVS_READWRITE, &nvs) != ESP_OK) {
        return;
    }
    const esp_reset_reason_t reason = esp_reset_reason();
    const uint32_t psram_kb = esp_psram_is_initialized() ? (uint32_t)(esp_psram_get_size() / 1024) : 0;
    // v55：先读出上一次留下的值，才能回答「上一次是怎么结束的」。这两项
    // （prev / reason）只经 /api/status 读出：屏幕与串口都不再承载它们。
    uint8_t previous = 0;
    uint32_t boots = 0;
    const bool had_previous = nvs_get_u8(nvs, "prev_reason", &previous) == ESP_OK;
    const bool had_boots = nvs_get_u32(nvs, "seq", &boots) == ESP_OK;
    nvs_set_u8(nvs, "prev_reason", had_previous ? previous : static_cast<uint8_t>(reason));
    nvs_set_u8(nvs, "reason", static_cast<uint8_t>(reason));
    nvs_set_u32(nvs, "psram", psram_kb);
    nvs_set_u32(nvs, "seq", had_boots ? boots + 1 : 1);
    if (nvs_commit(nvs) != ESP_OK) {
        ESP_LOGW(TAG, "boot snapshot commit failed");
    }
    nvs_close(nvs);
}

extern "C" void app_main(void)
{
    LogBootFacts();

    // Initialize NVS flash for WiFi configuration.
    //
    // v38：这里原来是 ESP_ERROR_CHECK(ret)，任何一次失败都是 abort + 重启，
    // 于是"NVS 分区读不出来"这种小问题会表现成无限重启。NVS 只存配网信息，
    // 丢了顶多重新配网，绝不该让整机起不来。改成记录后继续。
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_LOGW(TAG, "Erasing NVS flash to fix corruption");
        esp_err_t err = nvs_flash_erase();
        if (err != ESP_OK) {
            ESP_LOGE(TAG, "nvs_flash_erase failed: %s", esp_err_to_name(err));
        }
        ret = nvs_flash_init();
    }
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "nvs_flash_init failed (%s); continuing without saved config",
                 esp_err_to_name(ret));
    }
    // v54：**必须放在 nvs_flash_init() 之后**。原来这段在 init 之前调用，
    // nvs_open 只会返回 ESP_ERR_NVS_NOT_INITIALIZED 然后静默返回 —— 快照永远没写进去。
    SaveBootSnapshot();

    // Initialize and run the application
    auto& app = Application::GetInstance();
    app.Initialize();
    app.Run();  // This function runs the main event loop and never returns
}
